#include <iostream>

#include "Pole.h"


int pole[pocetPrvkov];

void Pole::priradHodnoty(int hornaHranica) {


	for (pole = p; p - pole < pocetPrvkov; p++)
	{
		*p = 0; //pole naplnene nulami;
	}
}

void Pole::vypis() {
	for (int i = 0; i < pocetPrvkov; i++)
	{
		std::cout << pole[i] << std::endl;
	}
}