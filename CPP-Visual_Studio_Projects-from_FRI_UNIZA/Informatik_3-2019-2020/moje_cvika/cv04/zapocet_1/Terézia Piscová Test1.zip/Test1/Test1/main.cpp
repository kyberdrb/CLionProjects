#include "Pole.h"

int main() {
	Pole pole;

	pole.priradHodnoty();
	pole.vypis();

	return 0;

}