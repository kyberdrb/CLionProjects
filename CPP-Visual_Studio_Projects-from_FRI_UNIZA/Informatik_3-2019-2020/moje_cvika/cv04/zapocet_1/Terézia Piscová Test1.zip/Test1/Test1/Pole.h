#pragma once
class Pole
{
private:
	int const pocetPrvkov;
	int* p;
public:
	Pole(int pocetPrvkov);

	void priradHodnoty(int hornaHranica);
	void vypis();

	~Pole();
};

