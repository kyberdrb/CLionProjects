#ifndef POLE_H
#define POLE_H

#include <iostream>

class Pole {
private:
    int * const pole;
    int velkost;

public:
    Pole(int);
    ~Pole();
    void priradNahodnuHodnotu(int);
    void toString();

/*  lepsi toString()
    friend std::ostream &operator<<(std::ostream &os, const Pole &mojePole) {
        os << "Velkost pola: " << mojePole.velkost << "\n";
        for (int i = 0; i < mojePole.velkost; i++) {
            os << mojePole.pole[i] << ", ";
        }
        os << "\n";
        return os;
    }   */
};

#endif // POLE_H
