#include "pole.h"

#include <ctime>
#include <cstdlib>

Pole::Pole(int size) : velkost(size), pole(new int[size]) {
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
}

void Pole::priradNahodnuHodnotu(int hornaHranica) {
    for (int i = 0; i < this->velkost; i++) {
        this->pole[i] = std::rand() % (hornaHranica + 1);
    }
}

void Pole::toString() {
    std::cout << "Velkost pola: " << this->velkost << std::endl;
    for (int i = 0; i < this->velkost; i++) {
        std::cout << this->pole[i] << ", ";
    }
    std::cout << std::endl;
}

Pole::~Pole() {
    delete []pole;
}
