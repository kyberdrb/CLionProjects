#include "pole.h"

int main() {

    Pole poleStack(10);
    poleStack.priradNahodnuHodnotu(10);
    poleStack.toString();

    Pole *poleHeap = new Pole(20);
    poleHeap->priradNahodnuHodnotu(100);
    poleHeap->toString();
    delete poleHeap;

    return 0;
}
