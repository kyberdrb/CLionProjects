#pragma once

class Field
{
private:
	int arraySize;
	int* field;
public:
	Field(int maxElements);
	void generate(int maxLimit);
	void toString();
	~Field();
};