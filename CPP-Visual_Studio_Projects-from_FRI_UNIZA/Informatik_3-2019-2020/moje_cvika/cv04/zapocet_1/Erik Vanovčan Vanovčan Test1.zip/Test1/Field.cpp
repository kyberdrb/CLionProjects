#include "Field.h"
#include <iostream>
#include <stdlib.h>
#include <malloc.h>
#include <time.h>

using namespace std;

Field::Field(int size) {
	arraySize = size;
	field = (int*)malloc(sizeof(int) * arraySize);
}

void Field::generate(int maxLimit) {
	
	for (int i = 0; i < Field::arraySize; i++) {
		field[i] = rand() % maxLimit;
	}
}

void Field::toString() {
	for (int i = 0; i < arraySize; i++) {
		cout << "element:" << i + 1 << ":" << field[i] << endl;
	}

	cout << "Field size:" << arraySize << endl;

}

Field::~Field() {
	
}