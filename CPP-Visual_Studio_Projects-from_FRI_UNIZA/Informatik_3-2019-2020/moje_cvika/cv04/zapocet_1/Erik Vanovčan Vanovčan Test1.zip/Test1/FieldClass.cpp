#include "Field.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

Field::Field(int maxElements) {
	arraySize = maxElements;
}
