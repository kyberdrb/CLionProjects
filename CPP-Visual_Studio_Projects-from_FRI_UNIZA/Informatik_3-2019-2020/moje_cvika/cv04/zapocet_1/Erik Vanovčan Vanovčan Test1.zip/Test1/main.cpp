#include <iostream>
#include "FieldClass.cpp"



int main() {

	Field fieldOnStack(3);

	fieldOnStack.generate(50);

	fieldOnStack.toString();

	Field* fieldOnHeap;
	fieldOnHeap = new Field(3);

	fieldOnHeap->generate(50);
	
	fieldOnHeap->toString();
	return 0;
	




}