//
//  Pole.h
//  Zapocet1
//
//  Created by Ján Kluka on 16/10/2019.
//  Copyright © 2019 Ján Kluka. All rights reserved.
//

#ifndef Pole_h
#define Pole_h

class Pole {
private:
    int* pole;
    int pocetPrvkov;
public:
    Pole(int pocetPrvkov);
    ~Pole();
    void napln(int hornaHranica);
    void toString();
};


#endif /* Pole_h */
