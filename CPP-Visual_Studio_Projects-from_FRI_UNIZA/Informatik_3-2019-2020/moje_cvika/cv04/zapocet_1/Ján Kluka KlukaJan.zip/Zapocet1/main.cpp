//
//  main.cpp
//  Zapocet1
//
//  Created by Ján Kluka on 16/10/2019.
//  Copyright © 2019 Ján Kluka. All rights reserved.
//
#include "Pole.h"

int main(int argc, const char * argv[]) {
    
    Pole pole1{20};
    pole1.napln(100);
    pole1.toString();
    
    
    
    Pole* pole = new Pole(20);
    pole->napln(100);
    pole->toString();
    
    delete pole;
    
    return 0;
}
