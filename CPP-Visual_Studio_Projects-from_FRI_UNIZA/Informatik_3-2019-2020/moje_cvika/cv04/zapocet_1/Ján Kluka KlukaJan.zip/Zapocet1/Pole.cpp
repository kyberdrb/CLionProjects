//
//  Pole.c
//  Zapocet1
//
//  Created by Ján Kluka on 16/10/2019.
//  Copyright © 2019 Ján Kluka. All rights reserved.
//

#include "Pole.h"
#include <iostream>

using namespace std;

Pole::Pole(int pocet) {
    pocetPrvkov = pocet;
    pole = new int[pocet];
};

Pole::~Pole() {
    delete pole;
}

void Pole::napln(int hornaHranica) {
    srand((unsigned) time(NULL));
    for (int i = 0; i < pocetPrvkov; i++) {
        int nahodneCislo = rand() % hornaHranica;
        cout << "Nahodne cislo: " << nahodneCislo << "\n";
        pole[i] = nahodneCislo;
    };
};

void Pole::toString() {
    int* aktualny = pole;
    cout << "Pocet Prvkov: \n" << pocetPrvkov << "\nPole:\n";
    cout << "[";
    for (int i = 0; i < pocetPrvkov; i++) {
        cout << *aktualny << ",";
        aktualny++;
    }
    cout << "]";
};
