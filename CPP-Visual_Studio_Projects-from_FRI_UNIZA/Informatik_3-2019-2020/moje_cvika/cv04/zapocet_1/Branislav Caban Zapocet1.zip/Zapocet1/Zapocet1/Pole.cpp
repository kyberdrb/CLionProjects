#include "Pole.h"
#include <iostream>
#include <string>

using namespace std;

void Pole::priradHodnotu(int hornaHranica)
{
	int randomCislo = rand();
	for (int i = 0; i < pocetPrvkov; i++)
	{
		if (rand() <= hornaHranica) {
			*pole[i] = randomCislo;
		}
		else {
			*pole[i] =  hornaHranica % randomCislo;
		}
	}
}

void Pole::vypis()
{
	cout << "Pocet prvkov: " << pocetPrvkov << endl;
	vsetkyPrvky();
}

void Pole::vsetkyPrvky()
{
	for (int i = 0; i < pocetPrvkov; i++) {
		cout << "Prvky pola su: " << &pole[i] << endl;
	}
}

Pole::~Pole()
{
	delete []pole;
}
