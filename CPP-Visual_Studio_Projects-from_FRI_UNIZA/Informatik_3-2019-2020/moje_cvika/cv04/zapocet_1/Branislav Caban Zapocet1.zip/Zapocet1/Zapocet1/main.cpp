#include "Pole.h"

using namespace std;

int main() {
	Pole* pole;
	pole->priradHodnotu(rand());
	pole->vypis;


	Pole* pole2;
	pole2 = new Pole(50);
	pole2->priradHodnotu(rand());
	pole2->vypis;


	return 0;
}