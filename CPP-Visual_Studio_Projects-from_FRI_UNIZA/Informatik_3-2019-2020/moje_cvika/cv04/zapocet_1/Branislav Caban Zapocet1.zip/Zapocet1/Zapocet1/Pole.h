#pragma once

using namespace std;
class Pole
{
private:
	int pocetPrvkov{};
	int* pole[];

public:
	Pole(int parPocetPrv)
	{
		pocetPrvkov = parPocetPrv;
		int* pole = new int[pocetPrvkov];
	}

	void priradHodnotu(int hornaHranica);

	void vypis();

	int getPocetPrvkov() {
		return pocetPrvkov;
	}

	void vsetkyPrvky(); 

	~Pole();
};

