enum class ShapeType
{
	CIRCLE,
	SQUARE
};