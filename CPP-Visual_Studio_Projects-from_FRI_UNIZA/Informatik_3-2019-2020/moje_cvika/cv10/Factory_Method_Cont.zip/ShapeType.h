namespace ShapeCreation {
	enum class ShapeType
	{
		CIRCLE,
		SQUARE
	};
}