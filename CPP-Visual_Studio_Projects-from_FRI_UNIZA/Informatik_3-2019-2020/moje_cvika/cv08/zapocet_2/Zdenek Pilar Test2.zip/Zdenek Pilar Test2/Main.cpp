#include <iostream>
#include <fstream>
#include "Matica.h"

using std::cout;
using std::endl;
using std::ws;

int main() {

	std::ifstream inputMatrixFile;
	inputMatrixFile.open("Matica.txt");

	uint32_t pocetRiadkov{};
	uint32_t pocetStlpcov{};

	inputMatrixFile >> pocetRiadkov;
	inputMatrixFile >> ws;
	inputMatrixFile >> pocetStlpcov;
	inputMatrixFile >> ws;

	Matica nacitanaMatica(pocetRiadkov, pocetStlpcov);
	inputMatrixFile >> nacitanaMatica;

	Matica podelena = nacitanaMatica;
	podelena /= 2;

	std::ofstream podelenaOutputFile;
	podelenaOutputFile.open("Vydelena_Matica.txt");
	podelenaOutputFile << podelena;

	Matica& scitana = podelena + nacitanaMatica;
	
	std::ofstream odcitanaOutputFile;
	odcitanaOutputFile.open("scitana_Matica.txt");
	odcitanaOutputFile << scitana;

	cout << "Vydelena_Matica.txt\n" << podelena << endl;
	cout << "Matica.txt" << nacitanaMatica << endl;
	cout << "scitana_Matica.txt\n" << scitana << endl;

	delete& scitana;

	return 0;
}