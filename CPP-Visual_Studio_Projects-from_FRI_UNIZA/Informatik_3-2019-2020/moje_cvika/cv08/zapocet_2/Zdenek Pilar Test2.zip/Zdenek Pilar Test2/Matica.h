#pragma once
#include <iostream>
#include <cstdint>


class Matica
{
private :
	double** pole2D;
	uint32_t pocetRiadkov;
	uint32_t pocetStlpcov;

	
	void setPrvok(uint32_t x, uint32_t y, double hodnota);

public:
	double getPrvok(uint32_t x, uint32_t y) const;

	Matica(uint32_t riadky, uint32_t stlpce);

	Matica(const Matica& vzorovaMatica);

	~Matica();

	friend std::istream& operator>>(std::istream& in, Matica& alokovana);
	friend std::ostream& operator<<(std::ostream& out, const Matica& matica);

	Matica& operator/=(double skalar);

	friend Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica);

	friend bool majuRozneRozmery(const Matica& prvaMatica, const Matica& druhaMatica);
};

