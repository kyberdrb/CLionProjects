#include "Matica.h"
#include <cstdint>
#include <iostream>


double Matica::getPrvok(uint32_t x, uint32_t y) const {
	double temp = pole2D[x][y];
	return temp;
}

void Matica::setPrvok(uint32_t x, uint32_t y, double hodnota){
	pole2D[x][y] = hodnota;
}

Matica::Matica(uint32_t riadky, uint32_t stlpce){
	this->pocetStlpcov = stlpce;
	this->pocetRiadkov = riadky;

	this->pole2D = new double* [riadky];

	for (uint32_t i = 0; i < riadky; ++i) {
		this->pole2D[i] = new double[stlpce] {0};
	} 
	
}

Matica::Matica(const Matica& vzorovaMatica){
	this->pocetRiadkov = vzorovaMatica.pocetRiadkov;
	this->pocetStlpcov = vzorovaMatica.pocetStlpcov;

	this->pole2D = new double* [vzorovaMatica.pocetRiadkov];

	for (uint32_t i = 0; i < this->pocetRiadkov ; ++i)	{
		this->pole2D[i] = new double[vzorovaMatica.pocetStlpcov];

		for (uint32_t k = 0; k < this->pocetStlpcov; k++)
		{
			this->pole2D[i][k] = vzorovaMatica.getPrvok(i,k);
		}

	}
}

Matica::~Matica(){
	for (uint32_t x = 0; x < this->pocetRiadkov; ++x) {
			delete[] this->pole2D[x];
			this->pole2D[x] = nullptr;
	}
	delete[] this->pole2D;
	this->pole2D = nullptr;
}

Matica& Matica::operator/=(double skalar){
	
	for (uint32_t i = 0; i < this->pocetRiadkov; ++i) {
		for (uint32_t k = 0; k < this->pocetStlpcov; k++)
		{
			double temp = this->pole2D[i][k];
			this->pole2D[i][k] = temp / skalar;
		}
	}
	return *this;
}

std::istream& operator>>(std::istream& in, Matica& alokovana){

	for (uint32_t i = 0; i < alokovana.pocetRiadkov; ++i) {
		for (uint32_t k = 0; k < alokovana.pocetStlpcov; k++)
		{
			double temp{};
			in >> temp;
			alokovana.setPrvok(i, k, temp);
			in >> std::ws;
		}
	}
	return in;
}

std::ostream& operator<<(std::ostream& out, const Matica& matica){

	out << matica.pocetRiadkov << "\n";
	out << matica.pocetStlpcov << "\n";


	for (uint32_t i = 0; i < matica.pocetRiadkov; ++i) {
		for (uint32_t k = 0; k < matica.pocetStlpcov; k++)
		{
			out << matica.getPrvok(i, k) << " ";
		}
		out << "\n";
	}
	return out;
}

Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica){
	Matica* const rozdielovaMatica = new Matica(prvaMatica.pocetRiadkov, druhaMatica.pocetStlpcov);
	Matica& nulovaMatica = *rozdielovaMatica;

	if (!majuRozneRozmery(prvaMatica,druhaMatica)){
		return nulovaMatica;
	}
	for (uint32_t i = 0; i < druhaMatica.pocetRiadkov; ++i) {
		for (uint32_t k = 0; k < prvaMatica.pocetStlpcov; k++)
		{
			double temp = prvaMatica.getPrvok(i, k) + druhaMatica.getPrvok(i, k);
			rozdielovaMatica->pole2D[i][k] = temp;
		}
	}
	return *rozdielovaMatica;
}

bool majuRozneRozmery(const Matica& prvaMatica, const Matica& druhaMatica)
{
	if (prvaMatica.pocetRiadkov == druhaMatica.pocetRiadkov && prvaMatica.pocetStlpcov == druhaMatica.pocetStlpcov){
		return true;
	}
	return false;
}

