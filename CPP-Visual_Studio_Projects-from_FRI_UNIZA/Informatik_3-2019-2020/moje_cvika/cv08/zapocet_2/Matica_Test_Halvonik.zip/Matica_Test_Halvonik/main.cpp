#include <fstream>
#include "matica.h"


int main() {
    std::ifstream fin("matica.txt");
    std::ofstream fout("matica_delenie.txt");
    int riadkov, stlpcov;
    fin >> riadkov;
    fin >> std::ws;
    fin >> stlpcov;
    fin >> std::ws;

    Matica matica1(riadkov, stlpcov);
    fin >> matica1;
    std::cout << matica1 << std::endl;

    Matica matica2;
    matica2 = matica1;
    std::cout << matica2 << std::endl;

    matica2 /= 2;
    std::cout << matica2 << std::endl;
    fout << matica2;

    Matica &matica3 = matica1 + matica2;
    std::cout << matica3 << std::endl;
    fout.close();
    fout.open("matica_sucet.txt");
    fout << matica3;

    delete &matica3;

    fin.close();


    return 0;
}
