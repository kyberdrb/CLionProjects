#pragma once

#include <iostream>

class Matica {
public:
    Matica(int riadok = 0, int stlpec = 0);
    ~Matica();
    Matica(const Matica &);
    Matica &operator=(const Matica &);
    Matica &operator/=(int);

    friend Matica &operator+(const Matica &, const Matica &);
    friend std::ostream &operator<<(std::ostream &, const Matica &);
    friend std::istream &operator>>(std::istream &, Matica &);
private:
    double **prvky;
    int pocetRiadkov;
    int pocetStlpcov;
};
