#include "matica.h"

Matica::Matica(int riadkov, int stlpcov) : pocetRiadkov(riadkov), pocetStlpcov(stlpcov) {
    this->prvky = new double*[riadkov];
    for (int i = 0; i < riadkov; ++i) {
        this->prvky[i] = new double[stlpcov] {0};
    }
}

Matica::Matica(const Matica &druha) : pocetRiadkov(druha.pocetRiadkov), pocetStlpcov(druha.pocetStlpcov) {
    this->prvky = new double*[druha.pocetRiadkov];
    for (int i = 0; i < druha.pocetRiadkov; ++i) {
        this->prvky[i] = new double[druha.pocetStlpcov] {0};
        for (int j = 0; j < this->pocetStlpcov; ++j) {
            this->prvky[i][j] = druha.prvky[i][j];
        }
    }
}

Matica &Matica::operator=(const Matica &druha) {
    if (this == &druha) {
        return *this;
    }
    for (int i = 0; i < this->pocetRiadkov; ++i) {
        delete []this->prvky[i];
        this->prvky[i] = nullptr;
    }
    delete []this->prvky;
    this->prvky = nullptr;

    this->pocetRiadkov = druha.pocetRiadkov;
    this->pocetStlpcov = druha.pocetStlpcov;
    this->prvky = new double*[druha.pocetRiadkov];
    for (int i = 0; i < druha.pocetRiadkov; ++i) {
        this->prvky[i] = new double[druha.pocetStlpcov] {0};
        for (int j = 0; j < this->pocetStlpcov; ++j) {
            this->prvky[i][j] = druha.prvky[i][j];

        }
    }

    return *this;
}

Matica &Matica::operator/=(int cislo) {
    for (int i = 0; i < this->pocetRiadkov; ++i) {
        for (int j = 0; j < this->pocetStlpcov; ++j) {
            this->prvky[i][j] /= cislo;
        }
    }
    return *this;
}

//friend funckie + destruktor

Matica &operator+(const Matica &prva, const Matica &druha) {
    Matica *vysledna = new Matica(prva.pocetRiadkov, prva.pocetStlpcov);
    if (prva.pocetRiadkov != druha.pocetRiadkov || prva.pocetStlpcov != druha.pocetStlpcov) {
        return *vysledna;
    }

    for (int i = 0; i < prva.pocetRiadkov; ++i) {
        for (int j = 0; j < prva.pocetStlpcov; ++j) {
            vysledna->prvky[i][j] = prva.prvky[i][j] + druha.prvky[i][j];
        }
    }
    return *vysledna;
}

std::ostream &operator<<(std::ostream &os, const Matica &matica) {
    os << matica.pocetRiadkov << "\n" << matica.pocetStlpcov << "\n";
    for (int i = 0; i < matica.pocetRiadkov; ++i) {
        for (int j = 0; j < matica.pocetStlpcov; ++j) {
            os << matica.prvky[i][j] << " ";
        }
        os << "\n";
    }
    return os;
}

std::istream &operator>>(std::istream &is, Matica &matica) {
    for (int i = 0; i < matica.pocetRiadkov; ++i) {
        for (int j = 0; j < matica.pocetStlpcov; ++j) {
            is >> matica.prvky[i][j];
            is >> std::ws;
        }
    }
    return is;
}

Matica::~Matica() {
    for (int i = 0; i < this->pocetRiadkov; i++) {
        delete []this->prvky[i];
        this->prvky[i] = nullptr;
    }
    delete []this->prvky;
    this->prvky = nullptr;
}
