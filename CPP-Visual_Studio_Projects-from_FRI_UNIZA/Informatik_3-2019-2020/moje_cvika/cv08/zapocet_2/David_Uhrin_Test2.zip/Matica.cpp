#include "Matica.h"

Matica::Matica(uint32_t pocetRiadkov, uint32_t pocetStlpcov)
{
	this->pocetRiadkov = pocetRiadkov;
	this->pocetStlpcov = pocetStlpcov;

	this->matrix = new double* [pocetRiadkov];

	for (uint32_t i = 0; i < pocetRiadkov; ++i) {
		this->matrix[i] = new double [pocetStlpcov] {0};
	}
}

Matica::Matica(Matica& vzorovaMatica)
{
	this->pocetRiadkov = vzorovaMatica.pocetRiadkov;
	this->pocetStlpcov = vzorovaMatica.pocetStlpcov;

	this->matrix = new double* [this->pocetRiadkov];

	for (uint32_t i = 0; i < this->pocetRiadkov; ++i) {
		this->matrix[i] = new double[pocetStlpcov];
		for (uint32_t j = 0; j < this->pocetStlpcov; ++j) {
			this->matrix[i][j] = vzorovaMatica.matrix[i][j];
		}
	}
}

Matica::~Matica()
{
	for (uint32_t i = 0; i < this->pocetRiadkov; ++i) {
		delete[] this->matrix[i];
		this->matrix[i] = nullptr;
	}

	delete[] this->matrix;
	this->matrix = nullptr;
}

bool majuRovnakeRozmery(Matica& matica1, Matica& matica2)
{
	return majuRovnakyPocetRiadkov(matica1, matica2) && majuRovnakyPocetStlpcov(matica1, matica2);
}

bool majuRovnakyPocetRiadkov(Matica& matica1, Matica& matica2)
{
	return matica1.pocetRiadkov == matica2.pocetRiadkov;
}

bool majuRovnakyPocetStlpcov(Matica& matica1, Matica& matica2)
{
	return matica1.pocetStlpcov == matica2.pocetStlpcov;
}

Matica& Matica::operator/=(double delitel)
{
	for (uint32_t i = 0; i < this->pocetRiadkov; ++i) {
		for (uint32_t j = 0; j < this->pocetStlpcov; ++j) {
			this->matrix[i][j] /= delitel;
		}
	}
	return *this;
}


Matica& operator+(Matica& matica1, Matica& matica2)
{
	Matica* rozdielovaMatica = new Matica (matica1.pocetRiadkov, matica1.pocetStlpcov);
	if (!majuRovnakeRozmery(matica1, matica2)) {
		return *rozdielovaMatica;
	}

	for (uint32_t i = 0; i < rozdielovaMatica->pocetRiadkov; ++i) {
		for (uint32_t j = 0; j < rozdielovaMatica->pocetStlpcov; ++j) {
			rozdielovaMatica->matrix[i][j] = matica1.matrix[i][j] + matica2.matrix[i][j];
		}
	}

	return *rozdielovaMatica;
}

std::istream& operator>>(std::istream& citac, Matica& matica)
{
	for (uint32_t i = 0; i < matica.pocetRiadkov; ++i) {
		for (uint32_t j = 0; j < matica.pocetStlpcov; ++j) {
			citac >> matica.matrix[i][j];
			citac >> std::ws;
		}
		citac >> std::ws;
	}
	return citac;
}

std::ostream& operator<<(std::ostream& out, const Matica& matica)
{
	out << matica.pocetRiadkov << std::endl;
	out << matica.pocetStlpcov << std::endl;
	for (uint32_t i = 0; i < matica.pocetRiadkov; ++i) {
		for (uint32_t j = 0; j < matica.pocetStlpcov; ++j) {
			out << matica.matrix[i][j];
			out << " ";
		}
		out << std::endl;
	}
	out << std::endl;
	return out;
}


