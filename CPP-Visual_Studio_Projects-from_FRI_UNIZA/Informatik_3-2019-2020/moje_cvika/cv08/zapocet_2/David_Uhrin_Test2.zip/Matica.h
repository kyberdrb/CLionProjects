#pragma once
#include <cstdint>
#include <istream>

class Matica
{
private:
	uint32_t pocetRiadkov;
	uint32_t pocetStlpcov;
	double** matrix;
	
public:
	Matica(uint32_t pocetRiadkov = 0, uint32_t pocetStlpcov = 0 );
	Matica(Matica& vzorovaMatica);
	~Matica();
	
	
	Matica& operator/=(double delitel);
	
	friend Matica& operator+(Matica& matica1, Matica& matica2);
	friend std::istream& operator>>(std::istream& citac, Matica& matica);
	friend std::ostream& operator<<(std::ostream& out, const Matica& matica);

	friend bool majuRovnakeRozmery(Matica& matica1, Matica& matica2);
	friend bool majuRovnakyPocetRiadkov(Matica& matica1, Matica& matica2);
	friend bool majuRovnakyPocetStlpcov(Matica& matica1, Matica& matica2);

};

