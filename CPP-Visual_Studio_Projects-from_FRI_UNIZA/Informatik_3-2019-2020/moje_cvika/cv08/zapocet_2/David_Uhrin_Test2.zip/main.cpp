#include <fstream>
#include <iostream>
#include "Matica.h"


int main(){

	std::ifstream citac;
	citac.open("matica.txt");

	uint32_t pocetRiadkov;
	uint32_t pocetStlpcov;

	citac >> pocetRiadkov;
	citac >> std::ws;
	citac >> pocetStlpcov;
	citac >> std::ws;

	Matica matica(pocetRiadkov, pocetStlpcov);
	citac >> matica;

	std::cout << "Matica1: \n" << matica << std::endl;

	Matica delenaMatica(matica);
	delenaMatica /= 2;
	std::cout << "Matica delena: \n" << delenaMatica << std::endl;

	std::ofstream pisac;
	pisac.open("delenaMatica.txt");
	pisac << delenaMatica;

	Matica &scitanaMatica = matica + delenaMatica;
	std::cout << "Matica vysledok 2 scitanych: \n" << scitanaMatica << std::endl;
	std::ofstream pisac2;
	pisac2.open("scitanaMatica.txt");
	pisac2 << scitanaMatica;
	delete &scitanaMatica;

	return 0;
}