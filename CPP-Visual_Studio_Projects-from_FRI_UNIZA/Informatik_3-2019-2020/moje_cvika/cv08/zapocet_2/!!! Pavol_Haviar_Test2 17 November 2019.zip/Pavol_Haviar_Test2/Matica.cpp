#include "Matica.h"

int Matica::getPrvok(int riadok, int stlpec) const
{

	return this->pole[riadok][stlpec];
}

void Matica::setPrvok(int riadok, int stlpec, int hodnota)
{
	this->pole[riadok][stlpec] = hodnota;
}

Matica::Matica(int pocetRiadkov, int pocetStlpcov)
{
	this->riadky = pocetRiadkov;
	this->stlpce = pocetStlpcov;

	this->pole = new int* [pocetRiadkov];
	for (int riadky = 0; riadky < pocetRiadkov; ++riadky)
	{
		this->pole[riadky] = new int[pocetStlpcov] {0};
	}

}



Matica& Matica::operator=(const Matica& vzorovaMatica)
{
	if (this == &vzorovaMatica) {
		return *this;
	}

	for (int riadok = 0; riadok < this->riadky; ++riadok) {
		delete[] this->pole[riadok];
		this->pole[riadok] = nullptr;
	}

	delete[] this->pole;
	this->pole = nullptr;

	this->riadky = vzorovaMatica.riadky;
	this->stlpce = vzorovaMatica.stlpce;

	this->pole = new int* [this->riadky];
	for (int riadok = 0; riadok < this->riadky; ++riadok) {
		this->pole[riadok] = new int[this->stlpce];
		for (int stlpec = 0; stlpec < this->riadky; ++stlpec) {
			setPrvok(riadok, stlpec, vzorovaMatica.pole[riadok][stlpec]);
		}
	}
	return *this;
}

Matica& Matica::operator/=(int delitel)
{
	for (int riadok = 0; riadok < this->riadky; ++riadok)
	{
		for (int stlpec = 0; stlpec < this->stlpce; ++stlpec)
		{
			int podiel = this->getPrvok(riadok, stlpec) / delitel;
			this->setPrvok(riadok, stlpec, podiel);
		}
	}
	return *this;
}


std::istream& operator>>(std::istream& in, Matica& matica)
{
	for (int riadok = 0; riadok < matica.riadky; ++riadok)
	{
		for (int stlpec = 0; stlpec < matica.stlpce; ++stlpec)
		{
			int prvok{};
			in >> prvok;
			matica.setPrvok(riadok, stlpec, prvok);
			in >> std::ws;
		}
	}
	return in;
}

std::ostream& operator<<(std::ostream& out, const Matica& matica)
{
	out << matica.riadky << std::endl;
	out << matica.stlpce << std::endl;

	for (int riadky = 0; riadky < matica.riadky; ++riadky)
	{
		for (int stlpec = 0; stlpec < matica.stlpce; ++stlpec)
		{
			out << matica.getPrvok(riadky,stlpec) << " ";
		}
		out << "\n";
	}
	return out;
}

Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica)
{
	Matica* const scitanaMatica = new Matica(prvaMatica.riadky, prvaMatica.stlpce);

	for (int riadok = 0; riadok < prvaMatica.riadky; ++riadok)
	{
		for (int stlpec = 0; stlpec < prvaMatica.stlpce; ++stlpec)
		{
			int sucet = prvaMatica.getPrvok(riadok, stlpec) + druhaMatica.getPrvok(riadok, stlpec);
			scitanaMatica->setPrvok(riadok, stlpec, sucet);
		}
	}

	return *scitanaMatica;
}
