#pragma once
#include <istream>
class Matica
{

private:
	int riadky;
	int stlpce;
	int** pole;

	int getPrvok(int riadok, int stlpec) const;
	void setPrvok(int riadok, int stlpec, int hodnota);

public:

	
	Matica(int pocetRiadkov = 0, int pocetStlpcov = 0);
	Matica& operator=(const Matica&);
	Matica& operator/=(int delitel);

	friend std::istream& operator>> (std::istream& in, Matica& matica);
	friend std::ostream& operator<< (std::ostream& out, const Matica& matica);
	friend Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica);
	

};

