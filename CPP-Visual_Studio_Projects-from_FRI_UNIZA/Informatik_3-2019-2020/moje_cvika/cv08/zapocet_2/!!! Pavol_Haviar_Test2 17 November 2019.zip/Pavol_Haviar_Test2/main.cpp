#include <fstream>
#include <iostream>
#include "Matica.h"

int main() {

	std::ifstream nacitanieMatice;
	nacitanieMatice.open("matica.txt");

	int pocetRiadkov{};
	int pocetStlpcov{};

	
	nacitanieMatice >> pocetRiadkov;
	nacitanieMatice >> std::ws;
	nacitanieMatice >> pocetStlpcov;
	nacitanieMatice >> std::ws;

	Matica mojaMatica(pocetRiadkov, pocetStlpcov);

	nacitanieMatice >> mojaMatica;

	std::cout << "Moja nacitana matica: \n" << mojaMatica << std::endl;

	Matica skopirovanaMatica;
	skopirovanaMatica = mojaMatica;
	std::cout << "Moja skopirovana matica: \n" << skopirovanaMatica << std::endl;
	skopirovanaMatica /= 2;
	std::cout << "Vydelena matica: \n" << skopirovanaMatica << std::endl;
	
	std::ofstream vlozVydelenuDoSuboru;
	vlozVydelenuDoSuboru.open("vydelena.txt");
	vlozVydelenuDoSuboru << skopirovanaMatica;


	Matica& scitanaMatica = mojaMatica + skopirovanaMatica;
	std::cout << "Moja scitana matica: \n" << scitanaMatica << std::endl;

	std::ofstream vlozScitanuMaticuDoSuboru;
	vlozScitanuMaticuDoSuboru.open("scitana.txt");
	vlozScitanuMaticuDoSuboru << scitanaMatica;

	delete& scitanaMatica;
	

	return 0;
}