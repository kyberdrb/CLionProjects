//
//  main.cpp
//  Jan_Kluka_Test2
//
//  Created by Ján Kluka on 13/11/2019.
//  Copyright © 2019 Ján Kluka. All rights reserved.
//

#include <fstream>
#include "Matica.hpp"

int main(int argc, const char * argv[]) {
    std::ifstream loadStream;
    std::ofstream saveStream;
    
    loadStream.open("matica.txt");

    uint32_t pocetRiadkov{0};
    uint32_t pocetStlpcov{0};
    
    loadStream >> pocetRiadkov;
    loadStream >> std::ws;
    loadStream >> pocetStlpcov;
    loadStream >> std::ws;
    
    
    Matica nacitanaMatica{pocetRiadkov,pocetStlpcov};
    
    loadStream >> nacitanaMatica;
    std::cout << "Nacitana Matica:\n";
    std::cout << nacitanaMatica << "\n";
    
    Matica skopirovana = nacitanaMatica;
    std::cout << "Skopirovana matica:\n";
    std::cout << skopirovana << "\n";
    
    skopirovana /= 2;

    std::cout << "Skopirovana matica deleno 2:\n";
    std::cout << skopirovana << "\n";
    
    saveStream.open("matica2.txt");
    saveStream << skopirovana;
    
    saveStream.close();
    
    Matica& scitana = nacitanaMatica + skopirovana;
    std::cout << "Scitana matica:\n";
    std::cout << scitana << "\n";
    
    saveStream.open("matica3.txt");
    saveStream << scitana;
    saveStream.close();
    
    delete &scitana;
    loadStream.close();
    return 0;
}
