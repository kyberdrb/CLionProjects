//
//  Matica.hpp
//  Jan_Kluka_Test2
//
//  Created by Ján Kluka on 13/11/2019.
//  Copyright © 2019 Ján Kluka. All rights reserved.
//

#ifndef Matica_hpp
#define Matica_hpp

#include <stdio.h>
#include <iostream>

class Matica {
private:
    double** prvkyMatice;
    u_int32_t pocetRiadkov;
    u_int32_t pocetStlpcov;
public:
    Matica(u_int32_t riadky, u_int32_t stlpce);
    Matica(const Matica& vzor);
    ~Matica();
    void setPrvok(u_int32_t riadok, u_int32_t stlpec, double prvok);
    double getPrvok(u_int32_t riadok, u_int32_t stlpec) const;
    
    Matica& operator=(const Matica& matica);
    Matica& operator/=(const int delitel);
    
    friend std::istream& operator >>(std::istream& stream, Matica& matica);
    friend std::ostream& operator <<(std::ostream& stream, const Matica& matica);
    friend Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica);
    friend bool majuRovnakeRozmery(const Matica& prvaMatica, const Matica& druhaMatica);
};

#endif /* Matica_hpp */
