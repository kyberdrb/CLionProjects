//
//  Matica.cpp
//  Jan_Kluka_Test2
//
//  Created by Ján Kluka on 13/11/2019.
//  Copyright © 2019 Ján Kluka. All rights reserved.
//

#include "Matica.hpp"

Matica::Matica(u_int32_t riadky, u_int32_t stlpce) {
    this->pocetRiadkov = riadky;
    this->pocetStlpcov = stlpce;
    
    this->prvkyMatice = new double*[riadky];
    for (u_int32_t riadok = 0; riadok < riadky; ++riadok) {
        this->prvkyMatice[riadok] = new double[stlpce];
    };
};

Matica::Matica(const Matica& vzor) {
    this->pocetRiadkov = vzor.pocetRiadkov;
    this->pocetStlpcov = vzor.pocetStlpcov;
    
    this->prvkyMatice = new double*[vzor.pocetRiadkov];
    
    for (u_int32_t riadok = 0; riadok < vzor.pocetRiadkov; ++riadok) {
        this->prvkyMatice[riadok] = new double[vzor.pocetStlpcov];
        for (uint32_t stlpec = 0; stlpec < vzor.pocetStlpcov; ++stlpec) {
            this->setPrvok(riadok, stlpec, vzor.getPrvok(riadok, stlpec));
        }
    };
}

Matica& Matica::operator=(const Matica& matica) {
    this->pocetRiadkov = matica.pocetRiadkov;
    this->pocetStlpcov = matica.pocetStlpcov;
    
    for (u_int32_t riadok = 0; riadok < pocetRiadkov; ++riadok) {
        delete[]this->prvkyMatice[riadok];
        this->prvkyMatice[riadok] = nullptr;
    }
    
    delete[]this->prvkyMatice;
    this->prvkyMatice = nullptr;
    
    this->prvkyMatice = new double*[matica.pocetRiadkov];
    for (u_int32_t riadok = 0; riadok < matica.pocetRiadkov; ++riadok) {
        this->prvkyMatice[riadok] = new double[matica.pocetStlpcov];
        for (uint32_t stlpec = 0; stlpec < matica.pocetStlpcov; ++stlpec) {
            this->setPrvok(riadok, stlpec, matica.getPrvok(riadok, stlpec));
        }
    };
    return *this;
};

Matica& Matica::operator/=(const int delitel) {
    for (u_int32_t riadok = 0; riadok < this->pocetRiadkov; ++riadok) {
        for (uint32_t stlpec = 0; stlpec < this->pocetStlpcov; ++stlpec) {
            this->setPrvok(riadok, stlpec, (this->getPrvok(riadok, stlpec) / delitel));
        }
    };
    return *this;
};

Matica::~Matica() {
    
    for (u_int32_t riadok = 0; riadok < pocetRiadkov; ++riadok) {
        delete[]this->prvkyMatice[riadok];
        this->prvkyMatice[riadok] = nullptr;
    }
    
    delete[]this->prvkyMatice;
    this->prvkyMatice = nullptr;
}

double Matica::getPrvok(u_int32_t riadok, u_int32_t stlpec) const {
    return this->prvkyMatice[riadok][stlpec];
}

void Matica::setPrvok(u_int32_t riadok, u_int32_t stlpec, double prvok) {
    this->prvkyMatice[riadok][stlpec] = prvok;
};

std::ostream& operator <<(std::ostream& stream, const Matica& matica) {
    stream << matica.pocetRiadkov;
    stream << "\n";
    stream << matica.pocetStlpcov;
    
    for (uint32_t riadok = 0; riadok < matica.pocetRiadkov; ++riadok) {
        stream << "\n";
        for (uint32_t stlpec = 0; stlpec < matica.pocetStlpcov; ++stlpec) {
            stream << matica.getPrvok(riadok, stlpec) << "\t";
        }
    }
    return stream;
}

std::istream& operator >>(std::istream& stream, Matica& matica) {
    for (uint32_t riadok = 0; riadok < matica.pocetRiadkov; ++riadok) {
        for (uint32_t stlpec = 0; stlpec < matica.pocetStlpcov; ++stlpec) {
            double prvok{0};
            stream >> prvok;
            matica.setPrvok(riadok, stlpec, prvok);
        }
    }
    return stream;
};

bool majuRovnakeRozmery(const Matica& prvaMatica, const Matica& druhaMatica) {
    return (prvaMatica.pocetRiadkov == druhaMatica.pocetRiadkov) && (prvaMatica.pocetStlpcov == druhaMatica.pocetStlpcov);
};

Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica) {
    Matica* suctova = new Matica(prvaMatica.pocetRiadkov, prvaMatica.pocetStlpcov);
    
    if (majuRovnakeRozmery(prvaMatica, druhaMatica)) {
    
        for (uint32_t riadok = 0; riadok < prvaMatica.pocetRiadkov; ++riadok) {
            for (uint32_t stlpec = 0; stlpec < prvaMatica.pocetStlpcov; ++stlpec) {
                suctova->setPrvok(riadok, stlpec, prvaMatica.getPrvok(riadok, stlpec) + druhaMatica.getPrvok(riadok, stlpec));
            }
        }
    }
    
    return *suctova;
}
