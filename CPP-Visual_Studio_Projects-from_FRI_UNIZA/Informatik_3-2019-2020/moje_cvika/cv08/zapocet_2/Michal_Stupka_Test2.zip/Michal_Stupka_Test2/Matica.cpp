#include "Matica.h"

Matica::Matica(int pocetRiadkov, int pocetStlpcov)
{
	this->pocetRiadkov = pocetRiadkov;
	this->pocetStlpcov = pocetStlpcov;

	this->pole = new int* [pocetRiadkov];

	for (int riadok = 0; riadok < pocetRiadkov; ++riadok) {
		this->pole[riadok] = new int[pocetStlpcov] {};
	}
}

Matica::Matica(const Matica& zdrojovaMatica)
{
	this->pocetRiadkov = zdrojovaMatica.pocetRiadkov;
	this->pocetStlpcov = zdrojovaMatica.pocetStlpcov;

	this->pole = new int* [zdrojovaMatica.pocetRiadkov];

	for (int riadok = 0; riadok < pocetRiadkov; ++riadok) {
		this->pole[riadok] = new int[zdrojovaMatica.pocetStlpcov];
		for (int stlpec = 0; stlpec < zdrojovaMatica.pocetStlpcov; ++stlpec)
		{
			setPrvok(riadok, stlpec, zdrojovaMatica.pole[riadok][stlpec]);
			
		}
	}

}

Matica::~Matica()
{
	for (int riadok = 0; riadok < this->pocetRiadkov; ++riadok) {
		delete[] this->pole[riadok];
		this->pole[riadok] = nullptr;
	}
	delete[] this->pole;
	this->pole = nullptr;
}

void Matica::setPrvok(int riadok, int stlpec, int hodnota)
{
	this->pole[riadok][stlpec] = hodnota;
}

int Matica::getPrvok(int riadok, int stlpec) const
{
	return this->pole[riadok][stlpec];
}

Matica& Matica::operator=(Matica& m)
{
	if (this == &m)
	{
		return *this;
	}

	for (int riadok = 0; riadok < this->pocetRiadkov; ++riadok) {
		delete[] this->pole[riadok];
		this->pole[riadok] = nullptr;
	}
	delete[] this->pole;
	this->pole = nullptr;


	this->pocetRiadkov = m.pocetRiadkov;
	this->pocetStlpcov = m.pocetStlpcov;

	this->pole = new int* [pocetRiadkov];

	for (int riadok = 0; riadok < pocetRiadkov; ++riadok) {
		this->pole[riadok] = new int[pocetStlpcov];
		for (int stlpec = 0; stlpec < pocetStlpcov; ++stlpec)
		{
			this->pole[riadok][stlpec] = m.getPrvok(riadok, stlpec);
		}
	}

	return *this;
}

Matica& Matica::operator/=(int cislo)
{
	for (int riadok = 0; riadok < pocetRiadkov; ++riadok) {
		
		for (int stlpec = 0; stlpec < pocetStlpcov; ++stlpec)
		{
			int hodnotaPoDeleni{};
			hodnotaPoDeleni = this->pole[riadok][stlpec] /= cislo;
			setPrvok(riadok,stlpec,hodnotaPoDeleni);
			
			//this->pole[riadok][stlpec] = hodnotaPoDeleni;
		}
	}
	return *this;
}

std::istream& operator>>(std::istream& input, Matica& m)
{
	for (int riadok = 0; riadok < m.pocetRiadkov; ++riadok)
	{
		for (int stlpec = 0; stlpec < m.pocetStlpcov; ++stlpec)
		{
			int hodnota{};
			input >> hodnota;
			m.setPrvok(riadok,stlpec,hodnota);
			input >> std::ws;
		}
	}
	return input;
}

std::ostream& operator<<(std::ostream& output, Matica& m)
{
	output << m.pocetRiadkov << "\n";
	output << m.pocetStlpcov << "\n";

	for (int riadok = 0; riadok < m.pocetRiadkov; ++riadok)
	{
		for (int stlpec = 0; stlpec < m.pocetStlpcov; ++stlpec)
		{
			output << m.getPrvok(riadok, stlpec) << " ";

		}
		output << "\n";
	}
	return output;
}

Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica)
{
	Matica* const scitanaMatica = new Matica(prvaMatica.pocetRiadkov, prvaMatica.pocetStlpcov);

	for (int riadok = 0; riadok < prvaMatica.pocetRiadkov; ++riadok)
	{
		for (int stlpec = 0; stlpec < prvaMatica.pocetStlpcov; ++stlpec)
		{
			scitanaMatica->setPrvok(riadok, stlpec, prvaMatica.getPrvok(riadok, stlpec) + druhaMatica.getPrvok(riadok, stlpec));
			
		}
		
	}
	return *scitanaMatica;
}
