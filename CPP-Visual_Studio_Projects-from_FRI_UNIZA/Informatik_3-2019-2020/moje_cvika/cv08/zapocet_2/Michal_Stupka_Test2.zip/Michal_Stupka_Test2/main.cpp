#include <fstream>
#include "Matica.h"
#include <iostream>


int main() {
	std::ifstream inputMatica;
	inputMatica.open("matica.txt");
	int pocetRiadkov{};
	int pocetStlpcov{};

	inputMatica >> pocetRiadkov;
	inputMatica >> std::ws;
	inputMatica >> pocetStlpcov;
	inputMatica >> std::ws;

	Matica m1(pocetRiadkov, pocetStlpcov);
	inputMatica >> m1;
	Matica kopirovanaMatica = m1;

	std::cout<<"nacitana matica \n" << m1;
	std::cout <<"kopirovana matica \n" << kopirovanaMatica;

	Matica vydelenaMatica = kopirovanaMatica;
	vydelenaMatica /= 2;

	std::cout << "vydelena matica \n" << vydelenaMatica;

	std::ofstream outputMatica;
	outputMatica.open("skopirovana_matica.txt");
	outputMatica << kopirovanaMatica;

	Matica& suctovaMatica = kopirovanaMatica + vydelenaMatica;

	std::cout << "suctova matica \n" << suctovaMatica;

	std::ofstream outputMatica2;
	outputMatica2.open("suctova_matica.txt");
	outputMatica2 << suctovaMatica;

	delete& suctovaMatica;

	return 0;
}