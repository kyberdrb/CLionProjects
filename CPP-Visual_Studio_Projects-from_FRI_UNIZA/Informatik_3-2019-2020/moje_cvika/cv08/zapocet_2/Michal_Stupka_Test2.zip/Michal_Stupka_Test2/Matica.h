#pragma once
#include <istream>

class Matica {
private: 
	int pocetRiadkov;
	int pocetStlpcov;
	int** pole;

public:
	Matica(int pocetRiadkov, int pocetStlpcov);
	Matica(const Matica& zdrojovaMatica);
	~Matica();
	
	void setPrvok(int riadok, int stlpec, int hodnota);
	int getPrvok(int riadok, int stlpec) const ;

	friend std::istream& operator>>(std::istream& input, Matica& m);
	friend std::ostream& operator<<(std::ostream& output, Matica& m);
	friend Matica& operator+(const Matica& prvaMatica, const Matica& druhaMatica);
	Matica& operator=(Matica& m);
	Matica& operator/=(int cislo);
};