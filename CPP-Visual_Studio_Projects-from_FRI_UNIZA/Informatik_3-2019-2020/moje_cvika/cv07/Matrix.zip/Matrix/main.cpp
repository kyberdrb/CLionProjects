#include <iostream>
#include <fstream>

#include "Matica.h"

using std::cout;
using std::endl;

int main() {
	std::ifstream inputMatrixFile;
	inputMatrixFile.open("matrix.txt");

	uint32_t pocetRiadkov{};
	uint32_t pocetStlpcov{};

	// nacitanie matice zo subotu - deserializacia
	inputMatrixFile >> pocetRiadkov;
	inputMatrixFile >> std::ws;
	inputMatrixFile >> pocetStlpcov;
	inputMatrixFile >> std::ws;
	
	Matica nacitanaMatica(pocetRiadkov, pocetStlpcov);
	inputMatrixFile >> nacitanaMatica;

	// Kopirovaci konstruktor
	Matica maticaVynasobenaSkalarom = nacitanaMatica;

	// Kopirovaci operator priradenia
	/*Matica maticaVynasobenaSkalarom;
	maticaVynasobenaSkalarom = nacitanaMatica;*/
	
	maticaVynasobenaSkalarom *= 3;
	
	// ulozit maticu do suboru - serializacia
	std::ofstream matrixMultipliedByScalarOutputFile;
	matrixMultipliedByScalarOutputFile.open("matrix_multiplied_with_scalar.txt");
	matrixMultipliedByScalarOutputFile << maticaVynasobenaSkalarom;
	
	Matica& rozdielovaMatica = maticaVynasobenaSkalarom - nacitanaMatica;

	std::ofstream subtractedMatrixOutputFile;
	subtractedMatrixOutputFile.open("subtracted_matrix.txt");
	subtractedMatrixOutputFile << rozdielovaMatica;

	cout << "maticaVynasobenaSkalarom\n" << maticaVynasobenaSkalarom << endl;
	cout << "nacitanaMatica\n" << nacitanaMatica << endl;
	cout << "rozdielovaMatica\n" << rozdielovaMatica << endl;

	delete& rozdielovaMatica;
	
	return 0;
}
