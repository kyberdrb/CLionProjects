#include "Matica.h"

Matica::Matica(uint32_t riadky, uint32_t stlpce)
{
	this->pocetRiadkov = riadky;
	this->pocetStlpcov = stlpce;

	this->pole2d = new double* [riadky];	// aky vyznam ma hviezdicka '*' v tomto pripade?
	// Rozdiel medzi 'riadok++' a '++riadok'
	for (uint32_t riadok = 0; riadok < riadky; ++riadok)
	{
		this->pole2d[riadok] = new double[stlpce] {0};
	}
}

Matica::Matica(const Matica& vzorovaMatica)
{
	this->pocetRiadkov = vzorovaMatica.pocetRiadkov;
	this->pocetStlpcov = vzorovaMatica.pocetStlpcov;

	this->pole2d = new double* [vzorovaMatica.pocetRiadkov];
	for (uint32_t riadok = 0; riadok < vzorovaMatica.pocetRiadkov; ++riadok)
	{
		this->pole2d[riadok] = new double[vzorovaMatica.pocetStlpcov];
		for (uint32_t stlpec = 0; stlpec < vzorovaMatica.pocetStlpcov; ++stlpec)
		{
			setPrvok(riadok, stlpec, vzorovaMatica.pole2d[riadok][stlpec]);
		}
	}
}

Matica& Matica::operator=(const Matica& vzorovaMatica) {
	if (this == &vzorovaMatica) {
		return *this;
	}

	for (uint32_t riadok = 0; riadok < this->pocetRiadkov; ++riadok) {
		delete[] this->pole2d[riadok];
		this->pole2d[riadok] = nullptr;
	}

	delete[] this->pole2d;
	this->pole2d = nullptr;

	this->pocetRiadkov = vzorovaMatica.pocetRiadkov;
	this->pocetStlpcov = vzorovaMatica.pocetStlpcov;

	this->pole2d = new double* [this->pocetRiadkov];
	for (uint32_t riadok = 0; riadok < this->pocetRiadkov; ++riadok) {
		this->pole2d[riadok] = new double[this->pocetStlpcov];
		for (uint32_t stlpec = 0; stlpec < this->pocetStlpcov; ++stlpec) {
			setPrvok(riadok, stlpec, vzorovaMatica.pole2d[riadok][stlpec]);
		}
	}
	return *this;
}

Matica::~Matica()
{
	for (uint32_t riadok = 0; riadok < this->pocetRiadkov; ++riadok)
	{
		delete[] this->pole2d[riadok];
		// nastavenim smernika na 'nullptr' osetrime tzv. visiaci smernik - dangling pointer
		this->pole2d[riadok] = nullptr;
	}

	delete[] this->pole2d;
	this->pole2d = nullptr;
}

std::istream& operator>>(std::istream& in, Matica& alokovanaMatica)
{
	for (uint32_t riadok = 0; riadok < alokovanaMatica.pocetRiadkov; ++riadok)
	{
		for (uint32_t stlpec = 0; stlpec < alokovanaMatica.pocetStlpcov; ++stlpec)
		{
			double prvok{};
			in >> prvok;
			alokovanaMatica.setPrvok(riadok, stlpec, prvok);
			in >> std::ws;
		}
	}
	return in;
}

void Matica::setPrvok(uint32_t riadok, uint32_t stlpec, double hodnota)
{
	this->pole2d[riadok][stlpec] = hodnota;
}

std::ostream& operator<<(std::ostream& out, const Matica& matica)
{
	out << matica.pocetRiadkov << "\n";
	out << matica.pocetStlpcov << "\n";
	for (uint32_t riadok = 0; riadok < matica.pocetRiadkov; ++riadok)
	{
		for (uint32_t stlpec = 0; stlpec < matica.pocetStlpcov; ++stlpec)
		{
			out << matica.getPrvok(riadok, stlpec) << " ";
		}
		out << "\n";
	}
	return out;
}

double Matica::getPrvok(uint32_t riadok, uint32_t stlpec) const
{
	return this->pole2d[riadok][stlpec];
}

Matica& Matica::operator*=(double skalar)
{
	for (uint32_t riadok = 0; riadok < this->pocetRiadkov; ++riadok)
	{
		for (uint32_t stlpec = 0; stlpec < this->pocetStlpcov; ++stlpec)
		{
			double sucin = this->getPrvok(riadok, stlpec) * skalar;
			this->setPrvok(riadok, stlpec, sucin);
		}
	}
	return *this;
}

Matica& operator-(const Matica& prvaMatica, const Matica& druhaMatica)
{
	Matica* const rozdielovaMatica = 
		new Matica(prvaMatica.pocetRiadkov, prvaMatica.pocetStlpcov);
	Matica& nulovaMatica = *rozdielovaMatica;

	if (majuMaticeRozneRozmery(prvaMatica, druhaMatica))
	{
		return nulovaMatica;
	}

	for (uint32_t riadok = 0; riadok < prvaMatica.pocetRiadkov; ++riadok)
	{
		for (uint32_t stlpec = 0; stlpec < prvaMatica.pocetStlpcov; ++stlpec)
		{
			double rozdiel =
				prvaMatica.getPrvok(riadok, stlpec) - druhaMatica.getPrvok(riadok, stlpec);
			rozdielovaMatica->setPrvok(riadok, stlpec, rozdiel);
		}
	}

	return *rozdielovaMatica;
}

bool majuMaticeRozneRozmery(const Matica& prvaMatica, const Matica& druhaMatica)
{
	return
		majuMaticeRoznyPocetRiadkov(prvaMatica, druhaMatica) ||
		majuMaticeRoznyPocetStlpcov(prvaMatica, druhaMatica);
}

bool majuMaticeRoznyPocetRiadkov(const Matica& prvaMatica, const Matica& druhaMatica)
{
	return prvaMatica.pocetRiadkov != druhaMatica.pocetRiadkov;
}

bool majuMaticeRoznyPocetStlpcov(const Matica& prvaMatica, const Matica& druhaMatica)
{
	return prvaMatica.pocetStlpcov != druhaMatica.pocetStlpcov;
}
