#pragma once
#include <string>

using namespace std;

class ILogger
{
public:
	virtual void error(string oznam) = 0;
	virtual void warning(string oznam) = 0;
	virtual void info(string oznam) = 0;
	virtual void log(unsigned int typ, string oznam) = 0;
	virtual void nastavTyp(unsigned int typ) = 0;
};

extern ILogger *aLog;
