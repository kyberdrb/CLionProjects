#include <iostream>
#include "Klient.h"

using namespace std;

Klient::Klient(void)
	: aPole(new RealPole(-4, 9, 8, 1.2, 0.7, 6.4, -8.6, 5.1, 4.9, -2.1, 7.3))
{
	int hi(200), di(-100);
	bool opakuj(true);
	do
	{
		try
		{
			aLog->log(0x4, "Vytvaram a nastavujem pole");
			opakuj = false;
			(*aPole)[hi] = (*aPole)[di];
		}
		catch(VynimkaDolnyIndex ex)
		{
			cout << ex.oznam() << ": di=" << di <<" sh: " << ex.index() << endl;
			di = ex.index();
			opakuj = true;
		}
		catch(VynimkaHornyIndex ex)
		{
			cout << ex.oznam() << ": hi=" << hi <<" sh: " << ex.index() << endl;
			hi = ex.index();
			opakuj = true;
		}
	} while(opakuj);
	aLog->log(0x4, "Vyvorene pole");
	aPole->vypis();
	aPole->sort();
	aLog->log(0x4, "Utriedene pole rastuco");
	aPole->vypis();
	aPole->sort(false);
	aLog->log(0x4, "Utriedene pole klesajuco");
	aPole->vypis();
}


Klient::~Klient(void)
{
	delete aPole;
}

