#pragma once
#include <fstream>
#include "ilogger.h"

using namespace std;

class FileLogger :	public ILogger
{
private:
	ofstream *aFlog;
	void writelog(const char *typ, string oznam);
	unsigned int aTyp;
public:
	FileLogger(const char *menosuboru);
	~FileLogger(void);
	virtual void error(string oznam);
	virtual void warning(string oznam);
	virtual void info(string oznam);
	virtual void log(unsigned int typ, string oznam);
	virtual void nastavTyp(unsigned int typ);
};

