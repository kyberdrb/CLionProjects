#pragma once
#include <string>
#include "ILogger.h"

using namespace std;

class VynimkaIndex
{
private:
	int aIndex;
	string aOznam;
public:
	VynimkaIndex(string poznam, int pindex)
		: aOznam(poznam), aIndex(pindex)
	{
	}
	int index() { return aIndex; }
	string oznam() { return aOznam; }
};


class VynimkaDolnyIndex: public VynimkaIndex
{
public:
	VynimkaDolnyIndex(int pindex)
		: VynimkaIndex("Dolny index mimo medze", pindex)
	{
		if(aLog)
			aLog->log(0x01,oznam()); 
	}
};

class VynimkaHornyIndex: public VynimkaIndex
{
public:
	VynimkaHornyIndex(int pindex)
		: VynimkaIndex("Horny index mimo medze", pindex)
	{
		if(aLog)
			aLog->log(0x01,oznam()); 
	}
};
