#include <stdlib.h>
#include <stdarg.h>
#include <iostream>

#include "VynimkaIndex.h"
#include "RealPole.h"

using namespace std;

RealPole::RealPole(int pdolnyindex,unsigned int prozsah, double initval)
	: aRozsah(prozsah), aDolnyIndex(pdolnyindex), 
	aData(aRozsah!=0 ? new double[aRozsah] : NULL)
{
	for(int i=0;i<aRozsah;i++)
		aData[i] = initval;
}

RealPole::RealPole(int pdolnyindex,unsigned int prozsah, unsigned pocetnastavenych, ...)
	: aRozsah(prozsah), aDolnyIndex(pdolnyindex), 
	aData(aRozsah!=0 ? new double[aRozsah] : NULL)
{
	va_list argptr;
	va_start(argptr,pocetnastavenych);

	for(int i=0;i<aRozsah;i++)
	{
		if(i<pocetnastavenych)
			aData[i] = va_arg(argptr, double);
		else
			aData[i] = 0.0;
	}
	va_end(argptr);
}

RealPole::~RealPole(void)
{
	zmaz();
}

void RealPole::zmaz()
{
	if(aData)
		delete[] aData;
	aData = NULL;
	aRozsah = 0;
}

void RealPole::copy(const RealPole &zdroj)
{
	aRozsah = zdroj.aRozsah;
	aDolnyIndex = zdroj.aDolnyIndex;
	aData = NULL;
	if(aRozsah!=0)
	{
		aData = new double[aRozsah];
		for(int i=0;i<aRozsah;i++)
			aData[i] = zdroj.aData[i];
	}
}

double &RealPole::operator [](int index)
{
	if(index < aDolnyIndex)
		throw VynimkaDolnyIndex(aDolnyIndex);
	int hornyindex = aDolnyIndex+aRozsah-1;
	if(index > hornyindex)
		throw VynimkaHornyIndex(hornyindex);
	return aData[index - aDolnyIndex];
}

int sortRastuco(const void *ar1, const void *ar2) 
{
	double *dar1((double *)ar1), *dar2((double *)ar2);
	if(*dar1  == *dar2)
		return 0;
	else
	{
		if(*dar1  < *dar2)
			return -1;
	}
	return 1;
}

int sortKlesajuco(const void *ar1, const void *ar2) 
{
	return sortRastuco(ar1,ar2) * -1;
}

void RealPole::sort(bool rastuco)
{
	qsort(aData, aRozsah, sizeof(double), rastuco ? sortRastuco : sortKlesajuco);
}


void RealPole::vypis()
{
	for(int i=0;i<aRozsah;i++)
		cout << aData[i] << endl;
	cout << endl;
}

