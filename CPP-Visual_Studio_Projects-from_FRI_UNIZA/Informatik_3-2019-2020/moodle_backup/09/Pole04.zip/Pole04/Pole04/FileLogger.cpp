#include <time.h>
#include "FileLogger.h"


FileLogger::FileLogger(const char *menosuboru)
	: aTyp(0x7)
{
	aFlog = new ofstream(menosuboru, ios_base::app | ios_base::out);
}


FileLogger::~FileLogger(void)
{
	delete aFlog;
}

void FileLogger::writelog(const char *typ, string oznam)
{
	time_t cas(time(NULL));
	char *scas = ctime(&cas);
	scas[24] = 0;
	*aFlog << typ << " [" << scas <<"]: " << oznam << endl;
}

void FileLogger::error(string oznam)
{
	writelog("ERROR", oznam);
}

void FileLogger::warning(string oznam)
{
	writelog("WARNING", oznam);
}

void FileLogger::info(string oznam)
{
	writelog("INFO", oznam);
}


void FileLogger::log(unsigned int typ, string oznam)
{
	if((aTyp & typ) == 0x01)
		error(oznam);
	if((aTyp & typ) == 0x02)
		warning(oznam);
	if((aTyp & typ) == 0x04)
		info(oznam);
}

void FileLogger::nastavTyp(unsigned int typ)
{
	aTyp = typ;
}
