#pragma once
#include "RealPole.h"
#include "VynimkaIndex.h"

class Klient
{
private:
	RealPole *aPole;
public:
	Klient(void);
	~Klient(void);
};

