#pragma once
class RealPole
{
private:
	unsigned int aRozsah;
	int aDolnyIndex;
	double *aData;
	void zmaz();
	void copy(const RealPole &zdroj);
public:
	RealPole(int pdolnyindex,unsigned int prozsah, double initval=0.0);
	RealPole(int pdolnyindex,unsigned int prozsah, unsigned pocetnastavenych, ...);
	RealPole(const RealPole &zdroj)
	{
		copy(zdroj);
	}

	RealPole & operator=(const RealPole &zdroj)
	{
		if(&zdroj != this)
		{
			zmaz();
			copy(zdroj);
		}
		return *this;
	}
	~RealPole(void);
	double &operator [](int index);
	void sort(bool rastuco=true);

	void vypis();
};

