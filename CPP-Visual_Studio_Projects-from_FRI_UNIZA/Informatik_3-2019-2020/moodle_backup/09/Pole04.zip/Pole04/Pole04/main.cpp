#include "Klient.h"
#include "FileLogger.h"
#include <iostream>

ILogger *aLog;

int main()
{
	try 
	{
		aLog = new FileLogger("c:\\student\\Pole04\\log\\klient.log");
		//aLog->nastavTyp(0);
		Klient  klient;
	}
	catch(...)
	{
		std::cerr << "Neznama vynimka!" << endl;
	}	
	return 0;
}