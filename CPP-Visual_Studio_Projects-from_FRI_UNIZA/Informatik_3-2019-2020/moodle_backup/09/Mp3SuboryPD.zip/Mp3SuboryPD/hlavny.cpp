#include "id3reader.h"
#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

void main()
{
	printf("%d\n",  sizeof(struct ID3v1));
	struct ID3v1 id3;
	int kodChyby;
	char * dir="d:\\mp3\\Fallout New Vegas";

	PrintDir(dir);

	//bool jeTag=GetID3v1(subor,&id3, kodChyby);
	//if(kodChyby!=0){
	//	fprintf(stderr, "Chyba otvorenia suboru: %s\n", subor);
	//	perror(strerror(kodChyby));
	//}
	//printf("%s\n",subor);
	//if(jeTag) PrintID3v1(&id3);
}
