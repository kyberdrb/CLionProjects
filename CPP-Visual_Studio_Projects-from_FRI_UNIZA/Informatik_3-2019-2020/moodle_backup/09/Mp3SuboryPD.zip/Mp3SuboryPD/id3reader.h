#pragma once

struct ID3v1 {
	char Tag[3];
	char Title[30];
	char Artist[30];
	char Album[30];
	char Year[4];
	char Comment[30];
	unsigned char Genre;
};

bool GetID3v1(const char* subor, struct ID3v1* p, int &kodChyby);
void PrintID3v1(struct ID3v1* p);
//Vypise obsah adresara s MP3 subormi a ak ja v nom ID3v1 tag, vypise ho
void PrintDir(const char* dir);

void PrintDir(const char* dir);
