#include "id3reader.h"
#include <io.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <windows.h>

bool GetID3v1(const char* subor, struct ID3v1* p, int &kodChyby)
{
	int handler=open(subor,O_RDONLY);
	kodChyby=0;
	if(handler==-1){
		kodChyby=errno;
		//fprintf(stderr, "Chyba otvorenia suboru: %s\n", subor);
		//perror(strerror(errno));
		return false;
	}
	//posun
	int pozicia=lseek(handler, -sizeof(ID3v1), SEEK_END);
	if(pozicia==-1){
		close(handler);
		return false;
	}

	read(handler,p,sizeof(struct ID3v1));
	close(handler);

	if('T'==p->Tag[0] && 'A'==p->Tag[1] && 'G'==p->Tag[2]){
		return true;
	}

	return false;
}

char* MakeString(const char* s, int pocZnakov)
{
	static char buf[2000];
	char* dst=buf;
	for(int i=0;i<pocZnakov;i++){
		dst[i] = s[i];
		if(0==dst[i]) break;
	}
	buf[pocZnakov]='\0';
	return buf;
}

void PrintID3v1(struct ID3v1* p)
{
	printf("   Title: %s\n", MakeString(p->Title,30));
}

void PrintDir(const char* dir)
{
	char pattern[2000];
	strcpy(pattern,dir);
	strcat(pattern,"\\*.mp3");

	WIN32_FIND_DATAA data;
	HANDLE hFind = FindFirstFileA(pattern, &data);
	if (hFind != INVALID_HANDLE_VALUE) {
		do {
			printf("%s\n",data.cFileName);
			struct ID3v1 id3;
			int kodChyby;
			char path[2000];
			strcpy(path,dir);
			strcat(path,"\\");
			strcat(path,data.cFileName);
			if(GetID3v1(path, &id3, kodChyby)){
				PrintID3v1(&id3);
			}
		} while (FindNextFileA(hFind, &data));
		FindClose(hFind);
	}
}

