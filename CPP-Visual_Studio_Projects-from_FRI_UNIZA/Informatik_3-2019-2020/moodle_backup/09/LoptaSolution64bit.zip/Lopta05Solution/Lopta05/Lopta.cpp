#include "Lopta.h"
#include "ISystem.h"

Lopta::Lopta(ISystem * phraciaplocha)
	: PohyblivyObjekt(phraciaplocha ? phraciaplocha->Sirka() : 0,
		phraciaplocha ? phraciaplocha->Vyska() : 0),
	lopta(nullptr),
	hraciaPlocha(phraciaplocha)
{
	if (hraciaPlocha)
		lopta = hraciaPlocha->CitajBMP("ball.bmp");
	if (lopta)
	{
		sirka = lopta->Sirka();
		vyska = lopta->Vyska();
		Reset();
	}
}

Lopta::~Lopta()
{
	if (hraciaPlocha && lopta)
		hraciaPlocha->Uvolni(lopta);
}

void Lopta::ZobrazSa()
{
	if (hraciaPlocha && lopta)
		hraciaPlocha->Zobraz(*lopta, x, y);
}

int Lopta::DajBody()
{
	return 1;
}
