#include <cstdlib>
#include "PohyblivyObjekt.h"

const int DELTA = 10;
const int INTERVAL = 20;

int PohyblivyObjekt::Generuj(int zaciatok, int koniec)
{
	if (koniec == zaciatok)
		koniec++;
	if (zaciatok > koniec)
	{
		int pom = zaciatok;
		zaciatok = koniec;
		koniec = pom; 
	}
	return rand() % (koniec - zaciatok) + zaciatok;
}

void PohyblivyObjekt::Reset()
{
	x = Generuj(0, sirkaPlocha - sirka);
	y = Generuj(0, vyskaPlocha - vyska);
	deltaX = Generuj(-DELTA / 2, DELTA / 2);
	deltaY = Generuj(-DELTA / 2, DELTA / 2);
	interval = Generuj(INTERVAL, 5 * INTERVAL);
}

PohyblivyObjekt::PohyblivyObjekt(int psirkaplocha, int pvyskaplocha)
	: sirkaPlocha(psirkaplocha), vyskaPlocha(pvyskaplocha),
	x(0), y(0),
	sirka(0), vyska(0),
	deltaX(0), deltaY(0),
	interval(0), casPoslednejZmeny(0)
{
}

PohyblivyObjekt::~PohyblivyObjekt()
{
}

bool PohyblivyObjekt::AktualizujSa(int pcas)
{
	if ((pcas - casPoslednejZmeny) > interval)
	{
		x += deltaX;
		if (x <= 0 || x >= (sirkaPlocha - sirka))
		{
			deltaX = -deltaX;
			x += deltaX;
		}
		y += deltaY;
		if (y <= 0 || y >= (vyskaPlocha - vyska))
		{
			deltaY = -deltaY;
			y += deltaY;
		}
		casPoslednejZmeny = pcas;
		return true;
	}
	return false;
}


bool PohyblivyObjekt::Zasah(int px, int py)
{
	bool trafil = px >= x && px <= (x + sirka) &&
		py >= y && py <= (y + vyska);
	if (trafil)
		Reset();
	return trafil;
}
