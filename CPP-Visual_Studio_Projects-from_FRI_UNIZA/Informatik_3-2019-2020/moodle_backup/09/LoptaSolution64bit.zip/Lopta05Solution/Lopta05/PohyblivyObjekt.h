#pragma once
#include "IObjekt.h"

class PohyblivyObjekt : public IObjekt
{
private:
	int casPoslednejZmeny, interval;
	int deltaX, deltaY;
	int sirkaPlocha, vyskaPlocha;
	int Generuj(int zaciatok, int koniec);
protected:
	int x, y;
	int sirka, vyska;
	virtual void Reset();
public:
	PohyblivyObjekt(int psirkaplocha, int pvyskaplocha);
	~PohyblivyObjekt();

	// Inherited via IObjekt
	virtual bool AktualizujSa(int pcas) override;
	virtual bool Zasah(int px, int py) override;
};

