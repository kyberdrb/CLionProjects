#pragma once
#include "IEngine.h"

class IObjekt;
class ISystem;

class Engine : public IEngine
{
private:
	int skore;
	ISystem *hraciaPlocha;
	IObjekt *objekt;

	void ZobrazSkore();
	void Aktualizuj();
	void SpracujVstup(int x, int y);
public:
	Engine(ISystem *phraciaplocha, IObjekt *pobjekt);
	~Engine();

	// Inherited via IEngine
	virtual void Start() override;
};

