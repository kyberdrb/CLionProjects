#include <string>
#include <sstream>

#include "Engine.h"
#include "ISystem.h"
#include "IObjekt.h"

using namespace std;

void Engine::ZobrazSkore()
{
	if (hraciaPlocha)
	{
		stringstream sts;
		sts << skore;
		hraciaPlocha->ZobrazText(string("Skore: ") + sts.str());
	}
}

void Engine::Aktualizuj()
{
	if (objekt && hraciaPlocha)
	{
		if (objekt->AktualizujSa(hraciaPlocha->Cas()))
		{
			hraciaPlocha->Zmaz();
			objekt->ZobrazSa();
			hraciaPlocha->Update();
		}
	}
}

void Engine::SpracujVstup(int x, int y)
{
	if (objekt && x >= 0)
	{
		if (objekt->Zasah(x, y))
		{
			skore += objekt->DajBody();
			ZobrazSkore();
		}
	}
}

Engine::Engine(ISystem * phraciaplocha, IObjekt * pobjekt)
	: hraciaPlocha(phraciaplocha), objekt(pobjekt), skore(0)
{
}

Engine::~Engine()
{
}

void Engine::Start()
{
	if (hraciaPlocha)
	{
		int x(-1), y(-1);
		ZobrazSkore();
		do {
			Aktualizuj();
			SpracujVstup(x, y);
		} while (hraciaPlocha->Vstup(x, y));
	}
}
