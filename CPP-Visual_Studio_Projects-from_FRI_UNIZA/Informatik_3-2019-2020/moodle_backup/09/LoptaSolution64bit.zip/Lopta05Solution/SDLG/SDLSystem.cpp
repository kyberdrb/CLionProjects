#include "SDL.h"

#include "SDLSystem.h"

int SDLSystem::pocetObjektov(0);

SDLSystem::SDLSystem(int sirka, int vyska)
{
	if (pocetObjektov == 0)
		SDL_Init(SDL_INIT_EVERYTHING);
	pocetObjektov++;
	plocha = SDL_SetVideoMode(sirka, vyska, 0, SDL_SWSURFACE);
}

SDLSystem::~SDLSystem()
{
	SDL_FreeSurface(plocha);
	pocetObjektov--;
	if (pocetObjektov == 0)
		SDL_Quit();
}

int SDLSystem::Sirka()
{
	return plocha ? plocha->w : 0;
}

int SDLSystem::Vyska()
{
	return plocha ? plocha->h : 0;
}

ISystem * SDLSystem::CitajBMP(const char * menosuboru)
{
	if (menosuboru && *menosuboru)
	{
		SDL_Surface *obrazok = SDL_LoadBMP(menosuboru);
		return new SDLSystem(obrazok);
	}
	return nullptr;
}

void SDLSystem::Uvolni(ISystem * grafickyobjekt)
{
}

void SDLSystem::Zobraz(ISystem & grafickyobjekt, int x, int y)
{
	SDLSystem &sdlobjekt = (SDLSystem &)grafickyobjekt;
	SDL_Rect rct;
	rct.x = x;
	rct.y = y;
	rct.w = sdlobjekt.Sirka();
	rct.h = sdlobjekt.Vyska();
	SDL_BlitSurface(sdlobjekt.plocha, nullptr, plocha, &rct);
}

bool SDLSystem::Vstup(int & x, int & y)
{
	x = -1;
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE)
				return false;
			break;
		case SDL_MOUSEBUTTONDOWN:
			if (event.button.button == SDL_BUTTON_LEFT)
			{
				x = event.button.x;
				y = event.button.y;
			}
			break;
		case SDL_QUIT:
			return false;
		}
	}
	return true;
}

int SDLSystem::Cas()
{
	return SDL_GetTicks();
}

void SDLSystem::Zmaz()
{
	SDL_FillRect(plocha, nullptr, SDL_MapRGB(plocha->format, 0, 255, 0));
}

void SDLSystem::Update()
{
	SDL_UpdateRect(plocha, 0, 0, 0, 0);
}

void SDLSystem::ZobrazText(string stext)
{
	SDL_WM_SetCaption(stext.c_str(), nullptr);
}
