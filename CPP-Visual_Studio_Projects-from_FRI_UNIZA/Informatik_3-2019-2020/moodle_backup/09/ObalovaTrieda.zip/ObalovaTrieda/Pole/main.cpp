#include "Klient.h"
#include "CompositeLogger.h"

//ILogger *Log = new StreamLogger("c:\\temp\\pole.log");
ILogger *Logger = new CompositeLogger();

int main()
{
	try
	{
		Logger->Log(INFO, "Start programu ...");
		Klient k;
		Logger->Log(INFO, "KONIEC PROGRAMU");
	}
	catch (...)
	{
		cout << "NEZNAMA CHYBA!!!" << endl;
	}
	return 0;
}