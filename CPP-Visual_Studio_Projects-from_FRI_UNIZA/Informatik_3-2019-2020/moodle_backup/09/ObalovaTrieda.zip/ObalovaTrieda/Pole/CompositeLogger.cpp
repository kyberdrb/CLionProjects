#include "CompositeLogger.h"

CompositeLogger::CompositeLogger()
	: slogger(new StreamLogger("c:\\temp\\pole.log")),
	clogger(new StreamLogger(""))
{
}

CompositeLogger::~CompositeLogger()
{
	delete slogger;
	delete clogger;
}

void CompositeLogger::Log(eLogLevel level, const char * text)
{
	if (clogger)
		clogger->Log(level, text);
	if (slogger)
		slogger->Log(level, text);
}
