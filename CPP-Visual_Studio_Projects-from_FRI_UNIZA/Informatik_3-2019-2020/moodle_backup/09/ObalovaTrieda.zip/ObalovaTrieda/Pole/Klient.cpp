#include "Klient.h"
#include "ILogger.h"

Klient::Klient()
	: pole(new Pole<double>(-4, 10, 1.1)),
	aDolnyIndex(-100),
	aHornyIndex(200)
{
	Logger->Log(DEBUG, "Start konstruktora Klient");
	bool ok(true);
	do {
		try
		{
			Logger->Log(DEBUG, "Nastavenie prvku s indexom -4 na hodnotu 10.2");
			(*pole)[-4] = 10.2;
			Logger->Log(DEBUG, "Nastavenie prvku s najvyssim indexom na hodnotu prvku s najnizsim indexom");
			(*pole)[aHornyIndex] = (*pole)[aDolnyIndex];
			Logger->Log(DEBUG, "Vypis prvkov pola");
			pole->Vypis();
			ok = false;
		}
		catch (VynimkaDolnyIndex &ex)
		{
			aDolnyIndex = ex.Index();
			Logger->Log(ERROR, ex.Oznam().c_str());
		}
		catch (VynimkaHornyIndex &ex)
		{
			aHornyIndex = ex.Index();
			Logger->Log(ERROR, ex.Oznam().c_str());
		}
		catch (VynimkaIndex &ex)
		{
			Logger->Log(ERROR, ex.Oznam().c_str());
		}
	} while (ok);
	Logger->Log(DEBUG, "Koniec konstruktora Klient");
}


Klient::~Klient()
{
	Logger->Log(DEBUG, "Dealokacia pola");
	delete pole;
}
