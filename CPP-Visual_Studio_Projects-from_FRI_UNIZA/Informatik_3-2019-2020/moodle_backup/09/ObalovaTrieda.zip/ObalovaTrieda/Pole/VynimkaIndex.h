#pragma once
#include <string>

using namespace std;

class VynimkaIndex
{
private:
	string oznam;
	int index;
public:

	VynimkaIndex(const char *poznam, int pindex)
		: oznam(poznam), index(pindex)
	{
	}
	virtual ~VynimkaIndex() {}

	string Oznam() { return oznam; }
	int Index() { return index; }
};

class VynimkaDolnyIndex : public VynimkaIndex
{
public:
	VynimkaDolnyIndex(int pindex)
		: VynimkaIndex("Dolny index mimo hranicu!", pindex)
	{}
};

class VynimkaHornyIndex : public VynimkaIndex
{
public:
	VynimkaHornyIndex(int pindex)
		:VynimkaIndex("Horny index mimo hranicu!", pindex)
	{}
};

