#pragma once
#include "StreamLogger.h"

class CompositeLogger : public ILogger
{
private:
	ILogger *slogger;
	ILogger *clogger;
public:
	CompositeLogger();
	~CompositeLogger();

	// Inherited via ILogger
	virtual void Log(eLogLevel level, const char * text) override;
};

