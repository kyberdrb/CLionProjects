#include "HraLopta.h"
#include "SDLSystem.h"

HraLopta::HraLopta()
	:aPlocha(new SDLSystem(600, 600)),
	aLopta(new Lopta(aPlocha)),
	aHra(new Engine(aLopta, aPlocha))
{
}


HraLopta::~HraLopta()
{
	delete aHra;
	delete aLopta;
	delete aPlocha;
}
