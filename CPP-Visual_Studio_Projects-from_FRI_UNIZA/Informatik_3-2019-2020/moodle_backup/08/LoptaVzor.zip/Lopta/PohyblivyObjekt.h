#pragma once
#include "IObjekt.h"
class PohyblivyObjekt : public IObjekt
{
private:
	int aDeltaX, aDeltaY;
	int aInterval, aCas;
	int aSirkaPlocha, aVyskaPlocha;
	int generuj(int minval, int maxval);
protected:
	int aX, aY;
	int aSirka, aVyska;
public:
	PohyblivyObjekt(int sirkaPlocha, int vyskaPlocha, int sirka = 0, int vyska = 0);
	~PohyblivyObjekt();

	// Inherited via IObjekt
	virtual bool aktualizujsa(int cas) override;
	virtual int dajBody() override;
	virtual bool zasah(int x, int y) override;

	void reset();
};

