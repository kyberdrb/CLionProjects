#pragma once
#include "ISystem.h"
#include "Lopta.h"
#include "Engine.h"

class HraLopta
{
private:
	ISystem *aPlocha;
	Lopta *aLopta;
	Engine *aHra;
public:
	HraLopta();
	~HraLopta();

	void start()
	{
		if (aHra)
			aHra->start();
	}
};

