#include <cstdio>
#include "Engine.h"

void Engine::zobrazSkore()
{
	if (aHraciaPlocha)
	{
		char buf[200];
		sprintf(buf, "Pocet bodov: %d", aSkore);
		aHraciaPlocha->zobrazdata(buf);
	}
}

void Engine::aktualizuj()
{
	if (aObjekt && aHraciaPlocha)
	{
		if (aObjekt->aktualizujsa(aHraciaPlocha->dajCas()))
		{
			aHraciaPlocha->zmaz();
			aObjekt->zobrazsa();
			aHraciaPlocha->update();
		}
	}
}

void Engine::spracujvstup(int x, int y)
{
	if (aObjekt && x >= 0)
	{
		int body = -aObjekt->dajBody();
		if (aObjekt->zasah(x, y))
			body = -body;
		aSkore += body;
		zobrazSkore();
	}
}

Engine::Engine(IObjekt * objekt, ISystem * plocha)
	: aObjekt(objekt), aHraciaPlocha(plocha), aSkore(0)
{
}

Engine::~Engine()
{
}

void Engine::start()
{
	int x(-1), y(-1);
	zobrazSkore();
	do {
		aktualizuj();
		spracujvstup(x, y);
	} while (aHraciaPlocha->vstup(x, y));
}
