#include "Engine.h"

void Engine::zobrazSkore()
{
	if (hraciaPlocha)
		hraciaPlocha->aktualizujTitulok(skore);
}

void Engine::aktualizujSa()
{
	if (teleso && hraciaPlocha)
	{
		if (teleso->pohniSa(hraciaPlocha->cas()))
		{
			hraciaPlocha->zmaz();
			teleso->zobrazSa();
			hraciaPlocha->update();
		}
	}
}

void Engine::spracujVstup(int x, int y)
{
	if (teleso && x > -1)
	{
		if (teleso->zasah(x, y)) {
			skore += teleso->dajBody();
			zobrazSkore();
		}
	}
}

Engine::~Engine()
{
}

void Engine::start()
{
	int x(-1), y(-1);
	if (hraciaPlocha) 
	{
		zobrazSkore();
		do {
			aktualizujSa();
			spracujVstup(x, y);
		} while (hraciaPlocha->citajXY(x, y));
	}
}
