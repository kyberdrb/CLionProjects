#pragma once
#include "IObjekt.h"

class PohybliveTeleso : public IObjekt
{
protected:
	int sirka, vyska;
	int x, y;
private:
	int deltaX, deltaY;
	int interval, casPoslednehoPosunu;
	int generuj(int a, int b);
public:
	PohybliveTeleso();
	~PohybliveTeleso();

	// Inherited via IObjekt
	virtual bool pohniSa(int cas) override;
	virtual bool zasah(int mysx, int mysy) override;
	virtual void reset(int sirkaPlocha, int vyskaPlocha) override;
	void odrazX()
	{
		deltaX = -deltaX;
		x += deltaX;
	}
	void odrazY()
	{
		deltaY = -deltaY;
		y += deltaY;
	}
};

