#include <cstdlib>

#include "PohybliveTeleso.h"

const int INTERVAL = 5;
const int DELTA = 6;

int PohybliveTeleso::generuj(int a, int b)
{
	if (a > b)
	{
		int c = a;
		a = b;
		b = c;
	}
	return rand() % (b - a + 1) + a;
}

PohybliveTeleso::PohybliveTeleso()
	: x(0), y(0),
	sirka(0), vyska(0),
	deltaX(0), deltaY(0),
	interval(0), casPoslednehoPosunu(0)
{
}


PohybliveTeleso::~PohybliveTeleso()
{
}

bool PohybliveTeleso::pohniSa(int cas)
{
	if ((cas - casPoslednehoPosunu) >= interval)
	{
		x += deltaX;
		y += deltaY;
		casPoslednehoPosunu = cas;
		return true;
	}
	return false;
}

bool PohybliveTeleso::zasah(int mysx, int mysy)
{
	return mysx >= x && mysx <= (x + sirka) && mysy >= y && mysy <= (y + vyska);
}

void PohybliveTeleso::reset(int sirkaPlocha, int vyskaPlocha)
{
	interval = generuj(INTERVAL, INTERVAL * 4);
	deltaX = generuj(-DELTA / 2, DELTA / 2);
	deltaY = generuj(-DELTA / 2, DELTA / 2);
	x = generuj(0, sirkaPlocha - sirka);
	y = generuj(0, vyskaPlocha - vyska);
}
