#pragma once
#include "PohybliveTeleso.h"
#include "ISystem.h"

class Lopta : public PohybliveTeleso
{
private:
	ISystem *hraciaPlocha;
	ISystem *loptaObrazok;
public:
	Lopta(ISystem *phraciaPlocha);
	~Lopta();

	// Inherited via PohybliveTeleso
	virtual int dajBody() override;
	virtual void zobrazSa() override;
	virtual bool zasah(int mysx, int mysy) override;
	virtual bool pohniSa(int cas) override;
};

