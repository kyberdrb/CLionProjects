#pragma once
class ISystem
{
public:
	virtual ISystem *citajBMP(const char *menosuborubmp) = 0;
	virtual int sirka() = 0;
	virtual int vyska() = 0;
	virtual void uvolni(ISystem *teleso) = 0;
	virtual void zobraz(ISystem *teleso, int x, int y) = 0;
	virtual bool citajXY(int &x, int &y) = 0;
	virtual void aktualizujTitulok(int hodnota) = 0;
	virtual int cas() = 0;
	virtual void zmaz() = 0;
	virtual void update() = 0;
	virtual ~ISystem() {}
};

