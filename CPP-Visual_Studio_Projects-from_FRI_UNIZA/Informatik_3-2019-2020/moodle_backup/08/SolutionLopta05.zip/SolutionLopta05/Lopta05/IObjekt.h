#pragma once
class IObjekt
{
public:
	virtual bool pohniSa(int cas) = 0;
	virtual bool zasah(int mysx, int mysy) = 0;
	virtual int dajBody() = 0;
	virtual void zobrazSa() = 0;
	virtual void reset(int sirkaPlocha, int vyskaPlocha) = 0;
	virtual ~IObjekt() { }
};

