#include "Lopta.h"



Lopta::Lopta(ISystem *phraciaPlocha)
	: hraciaPlocha(phraciaPlocha)
{
	if (hraciaPlocha)
	{
		loptaObrazok = hraciaPlocha->citajBMP("ball.bmp");
		if (loptaObrazok)
		{
			sirka = loptaObrazok->sirka();
			vyska = loptaObrazok->vyska();
			reset(hraciaPlocha->sirka(), hraciaPlocha->vyska());
		}
	}
}

Lopta::~Lopta()
{
	if (hraciaPlocha && loptaObrazok)
		hraciaPlocha->uvolni(loptaObrazok);
}

int Lopta::dajBody()
{
	return 1;
}

void Lopta::zobrazSa()
{
	if (hraciaPlocha)
		hraciaPlocha->zobraz(loptaObrazok, x, y);
}

bool Lopta::zasah(int mysx, int mysy)
{
	bool vysledok = PohybliveTeleso::zasah(mysx, mysy);
	if (vysledok)
		reset(hraciaPlocha->sirka(), hraciaPlocha->vyska());
	return vysledok;
}

bool Lopta::pohniSa(int cas)
{
	if (PohybliveTeleso::pohniSa(cas))
	{
		if (x<0 || (x + sirka)>hraciaPlocha->sirka())
			odrazX();
		if (y<0 || (y + vyska)>hraciaPlocha->vyska())
			odrazY();
	}
	return false;
}
