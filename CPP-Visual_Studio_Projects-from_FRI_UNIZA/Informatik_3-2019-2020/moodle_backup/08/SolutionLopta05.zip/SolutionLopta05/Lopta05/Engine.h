#pragma once
#include "IEngine.h"
#include "ISystem.h"
#include "IObjekt.h"

class Engine : public IEngine
{
private:
	ISystem *hraciaPlocha;
	IObjekt *teleso;
	int skore;
	void zobrazSkore();
	void aktualizujSa();
	void spracujVstup(int x, int y);
public:
	Engine(ISystem *phraciaPlocha, IObjekt *pteleso)
		: hraciaPlocha(phraciaPlocha), teleso(pteleso), skore(0) {}

	virtual ~Engine();

	// Inherited via IEngine
	virtual void start() override;
};

