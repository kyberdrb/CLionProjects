#include "IEngine.h"



IEngine::IEngine()
{
}


IEngine::~IEngine()
{
}
