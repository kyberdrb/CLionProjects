#include <cstdlib>
#include "PohyblivyObjekt.h"

using namespace std;

const int DELTA = 8;
const int INTERVAL = 20;

int PohyblivyObjekt::Generuj(int zaciatok, int koniec)
{
	if (zaciatok == koniec)
		koniec++;
	return rand() % abs(koniec - zaciatok) + zaciatok;
}

void PohyblivyObjekt::Reset()
{
	x = Generuj(0, sirkaPlocha - sirka);
	y = Generuj(0, vyskaPlocha - vyska);
	deltaX = Generuj(-DELTA / 2, DELTA / 2);
	deltaY = Generuj(-DELTA / 2, DELTA / 2);
	interval = Generuj(INTERVAL, 5 * INTERVAL);
}

PohyblivyObjekt::PohyblivyObjekt(int psirkaplocha, int pvyskaplocha)
	: sirkaPlocha(psirkaplocha), vyskaPlocha(pvyskaplocha),
	x(0), y(0),
	sirka(0), vyska(0),
	deltaX(0), deltaY(0),
	interval(0), casPoslednejZmeny(0)
{
}

PohyblivyObjekt::~PohyblivyObjekt()
{
}

bool PohyblivyObjekt::Zasah(int px, int py)
{
	bool trafilsom = px >= x && px <= x + sirka && py >= y && py <= y + vyska;
	if (trafilsom)
		Reset();
	return trafilsom;
}

bool PohyblivyObjekt::AktualizujSa(int cas)
{
	if ((cas - casPoslednejZmeny) > interval)
	{
		x += deltaX;
		if (x <= 0 || (x + sirka) >= sirkaPlocha)
		{
			deltaX = -deltaX; // deltaX *= -1;
			x += deltaX;
		}
		y += deltaY;
		if (y <= 0 || (y + vyska) >= vyskaPlocha)
		{
			deltaY = -deltaY; // deltaY *= -1;
			y += deltaY;
		}
		casPoslednejZmeny = cas;
		return true;
	}
	return false;
}
