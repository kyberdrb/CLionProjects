#include "HraLopta.h"

int main()
{
	HraLopta().Start();
	return 0;
}