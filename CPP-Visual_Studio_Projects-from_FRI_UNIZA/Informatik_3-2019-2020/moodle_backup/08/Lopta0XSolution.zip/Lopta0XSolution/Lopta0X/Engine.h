#pragma once
#include "IEngine.h"

class ISystem;
class IObjekt;

class Engine : public IEngine
{
private:
	ISystem *hraciaPlocha;
	IObjekt *objekt;
	int skore;

	void ZobrazSkore();
	void Aktualizuj();
	void SpracujVstup(int x, int y);
public:
	Engine(ISystem *phraciaplocha, IObjekt *pobjekt, int pociatocneskore = 0);
	~Engine();

	// Inherited via IEngine
	virtual void Start() override;
};

