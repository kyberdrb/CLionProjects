#include "IObjekt.h"



IObjekt::IObjekt()
{
}


IObjekt::~IObjekt()
{
}
