#pragma once
#include "PohyblivyObjekt.h"

class ISystem;

class Lopta : public PohyblivyObjekt
{
private:
	ISystem *hraciaPlocha;
	ISystem *lopta;
public:
	Lopta(ISystem *phraciaplocha);
	~Lopta();

	// Inherited via PohyblivyObjekt
	virtual void ZobrazSa() override;
	virtual int DajBody() override;
};

