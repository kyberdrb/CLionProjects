#pragma once
#include "IObjekt.h"

class PohyblivyObjekt : public IObjekt
{
private:
	int deltaX, deltaY;
	int sirkaPlocha, vyskaPlocha;
	int interval, casPoslednejZmeny;
	int Generuj(int zaciatok, int koniec);
protected:
	int x, y;
	int sirka, vyska;
	virtual void Reset();
public:
	PohyblivyObjekt(int psirkaplocha, int pvyskaplocha);
	~PohyblivyObjekt();

	// Inherited via IObjekt
	virtual bool Zasah(int px, int py) override;
	virtual bool AktualizujSa(int cas) override;
};

