#pragma once
#include <cstdarg>

#include "IntPole.h"

template <class T>
class Mnozina
{
private:
	IntPole<T> pole;
public:
	Mnozina(int pocetprvkov = 0);
	Mnozina(int kapacita, int pocetprvkov, ...);
	Mnozina(const Mnozina &zdroj) : pole(zdroj.pole) {}
	Mnozina &operator =(const Mnozina &zdroj)
	{
		if (this != &zdroj) {
			pole = zdroj.pole;
		}
		return *this;
	}
	~Mnozina();
	int GetPocetPrvkov() { return pole.GetObsadene(); }
	void pridaj(T cislo);
	Mnozina operator &(Mnozina &m2);
};

template <class T>
Mnozina<T>::Mnozina(int pocetprvkov)
	: pole(pocetprvkov)
{
}
template <class T>
Mnozina<T>::Mnozina(int kapacita, int pocetprvkov, ...)
	: pole(kapacita)
{
	if (pocetprvkov > 0)
	{
		va_list vl;
		va_start(vl, pocetprvkov);
		for (int i = 0; i < pocetprvkov; i++)
		{
			pridaj(va_arg(vl, T));
		}
		va_end(vl);
	}
}


template <class T>
Mnozina<T>::~Mnozina()
{
}

template <class T>
void Mnozina<T>::pridaj(T cislo)
{
	if (!pole.najdi(cislo))
		pole.pridaj(cislo);
}

template <class T>
Mnozina<T> Mnozina<T>::operator&(Mnozina<T> & m2)
{
	Mnozina<T> &m1 = *this;
	int m1pocet(m1.GetPocetPrvkov()),
		m2pocet(m2.GetPocetPrvkov());
	Mnozina<T> ciel(m1pocet < m2pocet ? m1pocet : m2pocet);
	int im1 = 0, im2 = 0;
	while (true)
	{
		if (im1 >= m1pocet || im2 >= m2pocet)
			break;
		int m1val = m1.pole.GetInt(im1);
		int m2val = m2.pole.GetInt(im2);
		if (m1val == m2val)
		{
			ciel.pridaj(m1val);
			im1++;
			im2++;
		}
		if (m1val < m2val)
			im1++;
		if (m1val > m2val)
			im2++;
	}
	return ciel;
}
