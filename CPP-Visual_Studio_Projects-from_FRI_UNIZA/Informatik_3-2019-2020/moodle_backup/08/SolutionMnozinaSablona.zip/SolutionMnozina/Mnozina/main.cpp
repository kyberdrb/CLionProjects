#include "Mnozina.h"

int main()
{
	Mnozina<int> m1(4, 3, 9, 3, 7), m2, m3;

	m2.pridaj(9);
	m2.pridaj(1);
	m2.pridaj(9);
	m2.pridaj(7);
	m3 = m1&m2;
	return 0;
}