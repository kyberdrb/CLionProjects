#pragma once
#include <cstring>
#include <cstdlib>

template <class T>
class IntPole
{
private:
	int kapacita;
	int obsadene;
	T *data;
	void utried();
public:
	IntPole(int kapacita = 0);
	IntPole(const IntPole &zdroj);
	IntPole &operator = (const IntPole &zdroj);
	void pridaj(T cislo);
	void vymaz(T cislo);
	bool najdi(T cislo);
	T GetObsadene() { return obsadene; }
	T GetInt(int index) { return data[index]; }
	~IntPole();
};

typedef int (*fcompare)(const void *, const void *);

template <class P>
int porovnajInt(const void *p1, const void *p2)
{
	
	P *i1((int *)p1), *i2((int *)p2);
	return (*i1) <= (*i2) ? ((*i1) == (*i2) ? 0 : -1) : 1;
}

template <class T>
void IntPole<T>::utried()
{
	qsort(data, obsadene, sizeof(T), porovnajInt<T>);
}

template <class T>
IntPole<T>::IntPole(int pkapacita)
	: kapacita(pkapacita), obsadene(0),
	data(kapacita > 0 ? new T[kapacita] : nullptr)
{
	if (kapacita)
		memset(data, 0, kapacita * sizeof(T));
}

template <class T>
IntPole<T>::IntPole(const IntPole & zdroj)
	: kapacita(zdroj.kapacita), obsadene(zdroj.obsadene),
	data(kapacita > 0 ? new T[kapacita] : nullptr)
{
	if (kapacita)
		memmove(data, zdroj.data, kapacita * sizeof(T));
}

template <class T>
IntPole<T> & IntPole<T>::operator=(const IntPole & zdroj)
{
	if (this != &zdroj)
	{
		kapacita = zdroj.kapacita;
		obsadene = zdroj.obsadene;
		data = nullptr;
		if (kapacita)
		{
			data = new T[kapacita];
			memmove(data, zdroj.data, kapacita * sizeof(T));
		}
	}
	return *this;
}

template <class T>
void IntPole<T>::pridaj(T cislo)
{
	if (obsadene == kapacita) {
		obsadene++;
		kapacita++;
		int *novedata = new T[kapacita];
		if (kapacita > 1)
			memmove(novedata, data, (kapacita - 1) * sizeof(T));
		novedata[kapacita - 1] = cislo;
		delete[] data;
		data = novedata;
	}
	else
		data[obsadene++] = cislo;
	utried();
}

template <class T>
void IntPole<T>::vymaz(T cislo)
{
	int i;
	for (i = 0; i < kapacita; i++)
	{
		if (data[i] == cislo)
		{
			kapacita--;
			obsadene--;
			if (kapacita > 1) {
				memmove(data, data, i * sizeof(T));
				memmove(&data[i], data, (kapacita - i) * sizeof(T));
			}
		}
	}
}

template <class T>
bool IntPole<T>::najdi(T cislo)
{
	for (int i = 0; i < kapacita; i++)
	{
		if (data[i] == cislo)
			return true;
	}
	return false;
}


template <class T>
IntPole<T>::~IntPole()
{
	delete[] data;
}
