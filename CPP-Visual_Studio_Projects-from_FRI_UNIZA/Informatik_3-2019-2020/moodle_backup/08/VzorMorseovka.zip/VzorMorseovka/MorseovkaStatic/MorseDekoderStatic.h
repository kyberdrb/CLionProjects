#pragma once
#include "MorseNodeStatic.h"

class MorseDekoderStatic
{
private:
	static int pocet;
	static MorseNodeStatic *start;
	void ZmazStrom(MorseNodeStatic  *node);
public:
	MorseDekoderStatic();
	MorseDekoderStatic(const MorseDekoderStatic &zdroj) { pocet++; }
	~MorseDekoderStatic();

	void Morse2Latin(const char *zdrojfilename, const char *cielfilename);
};

