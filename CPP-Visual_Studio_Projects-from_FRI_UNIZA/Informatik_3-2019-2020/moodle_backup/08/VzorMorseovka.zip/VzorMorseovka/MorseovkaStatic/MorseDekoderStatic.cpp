#include <cstdio>
#include <cctype>
#include "MorseDekoderStatic.h"

int MorseDekoderStatic::pocet = 0;
MorseNodeStatic *MorseDekoderStatic::start = nullptr;

MorseDekoderStatic::MorseDekoderStatic()
{
	if (pocet == 0) {
		start = new MorseNodeStatic(" ",
			new MorseNodeStatic("e",
				new MorseNodeStatic("i",
					new MorseNodeStatic("s",
						new MorseNodeStatic("h", nullptr, nullptr),
						new MorseNodeStatic("v", nullptr, nullptr)),
					new MorseNodeStatic("u",
						new MorseNodeStatic("f", nullptr, nullptr),
						nullptr)),
				new MorseNodeStatic("a",
					new MorseNodeStatic("r",
						new MorseNodeStatic("l", nullptr, nullptr),
						nullptr),
					new MorseNodeStatic("w",
						new MorseNodeStatic("p", nullptr, nullptr),
						new MorseNodeStatic("j", nullptr, nullptr)))),
			new MorseNodeStatic("t",
				new MorseNodeStatic("n",
					new MorseNodeStatic("d",
						new MorseNodeStatic("b", nullptr, nullptr),
						new MorseNodeStatic("x", nullptr, nullptr)),
					new MorseNodeStatic("k",
						new MorseNodeStatic("c", nullptr, nullptr),
						new MorseNodeStatic("y", nullptr, nullptr))),
				new MorseNodeStatic("m",
					new MorseNodeStatic("g",
						new MorseNodeStatic("z", nullptr, nullptr),
						new MorseNodeStatic("q", nullptr, nullptr)),
					new MorseNodeStatic("o",
						nullptr,
						new MorseNodeStatic("ch", nullptr, nullptr)))));
	}
	pocet++;
}


MorseDekoderStatic::~MorseDekoderStatic()
{
	pocet--;
	if (pocet == 0)
		ZmazStrom(start);
}

void MorseDekoderStatic::ZmazStrom(MorseNodeStatic  *node)
{
	if (!node) return;
	if (node->getLavy())  // ak existuje lavy uzol
	{
		ZmazStrom(node->getLavy());
		printf("%s\n", node->getLavy()->getZnak());
		delete node->getLavy();
	}
	if (node->getPravy()) // ak existuje pravy uzol
	{
		ZmazStrom(node->getPravy());
		printf("%s\n", node->getPravy()->getZnak());
		delete node->getPravy();
	}
}

void MorseDekoderStatic::Morse2Latin(const char * zdrojfilename, const char * cielfilename)
{
	char buf[1000];
	int i = 0;
	const char *pismeno;
	FILE *fzdroj = fopen(zdrojfilename, "rt");
	if (fzdroj)
	{
		FILE *fciel = fopen(cielfilename, "wt");
		if (fciel) {
			MorseNodeStatic *node = start;
			while (!feof(fzdroj)) {
				char c = fgetc(fzdroj);
				switch (c) {
				default:
					break;
				case '\/':
					pismeno = node->getZnak();
					fputs(pismeno, fciel);
					for (int j = 0; j < strlen(pismeno); j++)
						buf[i++] = pismeno[j];
					buf[i] = 0;
					node = start;
					break;
				case '.':
					node = node->getLavy();
					break;
				case '-':
					node = node->getPravy();
					break;
				}
			}
			fclose(fciel);
		}
		fclose(fzdroj);
	}
}
