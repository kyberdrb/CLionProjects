#include "MorseDekoderStatic.h"

int main()
{
	MorseDekoderStatic d,e,f(d);
	d.Morse2Latin("text.mrs", "text.lat");
	e.Morse2Latin("text.mrs", "text.lt2");
	f.Morse2Latin("text.mrs", "text.lt3");
	return 0;
}