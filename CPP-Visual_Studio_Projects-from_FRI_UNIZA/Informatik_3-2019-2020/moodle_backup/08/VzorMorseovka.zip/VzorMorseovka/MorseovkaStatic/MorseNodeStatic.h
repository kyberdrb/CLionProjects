#pragma once
#include <cstring>

class MorseNodeStatic
{
private:
	char znak[3];
	MorseNodeStatic *lavy;
	MorseNodeStatic *pravy;
public:

	MorseNodeStatic(const char *pznak, MorseNodeStatic *plavy, MorseNodeStatic *ppravy)
	{
		strcpy(znak, pznak);
		lavy = plavy;
		pravy = ppravy;
	}
	const char *getZnak() { return znak; }
	MorseNodeStatic *getLavy() { return lavy; }
	MorseNodeStatic *getPravy() { return pravy; }
};

