#pragma once
#include "Latin2MorseNode.h"

class MorseKoder
{
private:
	static int pocet;
	static Latin2MorseNode *L2MTabulka;
	const char *najdiMorse(const char *latin);
public:
	MorseKoder();
	~MorseKoder();
	void Latin2Morse(const char *zdrojfilename, const char *cielfilename);
};

