#include "MorseKoder.h"

int main()
{
	MorseKoder k;
	k.Latin2Morse("testtext.lat", "testtext.mrs");
	return 0;
}