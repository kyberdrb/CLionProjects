#pragma once
#include <cstring>

class Latin2MorseNode
{
private:
	char morse[10];
	char latin[3];
public:

	Latin2MorseNode(const char *pmorse, const char *platin)
	{
		strcpy(morse, pmorse);
		strcpy(latin, platin);
	}
	const char *getMorse() { return morse; }
	const char *getLatin() { return latin; }

};

