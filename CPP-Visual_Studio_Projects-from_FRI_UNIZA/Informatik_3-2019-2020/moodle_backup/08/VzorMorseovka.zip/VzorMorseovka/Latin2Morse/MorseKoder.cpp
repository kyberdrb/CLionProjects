#include <fstream>
#include "MorseKoder.h"

using namespace std;
const int DLZKA_TABULKY = 28;
int MorseKoder::pocet = 0;
Latin2MorseNode *MorseKoder::L2MTabulka = nullptr;


const char * MorseKoder::najdiMorse(const char * latin)
{
	for (int i = 0; i < DLZKA_TABULKY; i++)
	{
		if (strcmp(latin, L2MTabulka[i].getLatin()) == 0)
			return L2MTabulka[i].getMorse();
	}
	return L2MTabulka[0].getMorse();
}

MorseKoder::MorseKoder()
{
	if (pocet == 0) {
		L2MTabulka = new Latin2MorseNode[DLZKA_TABULKY]{
			Latin2MorseNode(""," "),
			Latin2MorseNode(".-","a"),
			Latin2MorseNode("-...","b"),
			Latin2MorseNode("-.-.","c"),
			Latin2MorseNode("-..","d"),
			Latin2MorseNode(".","e"),
			Latin2MorseNode("..-.","f"),
			Latin2MorseNode("--.","g"),
			Latin2MorseNode("....","h"),
			Latin2MorseNode("----","ch"),
			Latin2MorseNode("..","i"),
			Latin2MorseNode(".---","j"),
			Latin2MorseNode("-.-","k"),
			Latin2MorseNode(".-..","l"),
			Latin2MorseNode("--","m"),
			Latin2MorseNode("-.","n"),
			Latin2MorseNode("---","o"),
			Latin2MorseNode(".--.","p"),
			Latin2MorseNode("--.-","q"),
			Latin2MorseNode(".-.","r"),
			Latin2MorseNode("...","s"),
			Latin2MorseNode("-","t"),
			Latin2MorseNode("..-","u"),
			Latin2MorseNode("...-","v"),
			Latin2MorseNode(".--","w"),
			Latin2MorseNode("-..-","x"),
			Latin2MorseNode("-.--","y"),
			Latin2MorseNode("--..","z")
		};
	}
	pocet++;
}


MorseKoder::~MorseKoder()
{
	pocet--;
	if (pocet == 0)
		delete[] L2MTabulka;
}

void MorseKoder::Latin2Morse(const char * zdrojfilename, const char * cielfilename)
{
	char buf[1000];
	int i = 0;
	const char *pismeno;
	ifstream  zdroj(zdrojfilename);
	if (zdroj.is_open())
	{
		ofstream ciel(cielfilename);
		if (ciel.is_open()) {
			char c[3]{};
			char dalsic[2]{};
			while (!zdroj.eof()) {
				if (!*c)
					zdroj.read(c, 1);
				switch (*c) {
				default:
				{
					c[1] = '\0';
					const char *morseznak = najdiMorse(c);
					if (*morseznak)
						ciel.write(morseznak, strlen(morseznak));
					ciel.write("\/", 1);
					*c = '\0';
				}
				break;
				case 'c':
					zdroj.read(dalsic, 1);
					if (strcmp(dalsic, "h") == 0) {
						const char *morseznak = najdiMorse("ch");
						ciel.write(morseznak, strlen(morseznak));
						ciel.write("\/", 1);
					}
					else
						strcpy(c, dalsic);
					break;
				}
			}
		}
	}
}
