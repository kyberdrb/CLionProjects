#include "MorseDekoderS.h"



MorseDekoderS::MorseDekoderS()
{
}


MorseDekoderS::~MorseDekoderS()
{
}
