#include <cstdio>
#include <cctype>
#include "MorseDekoder.h"



MorseDekoder::MorseDekoder()
{
	start = new MorseNode(" ",
		new MorseNode("e",
			new MorseNode("i",
				new MorseNode("s",
					new MorseNode("h", nullptr, nullptr),
					new MorseNode("v", nullptr, nullptr)),
				new MorseNode("u",
					new MorseNode("f", nullptr, nullptr),
					nullptr)),
			new MorseNode("a",
				new MorseNode("r",
					new MorseNode("l", nullptr, nullptr),
					nullptr),
				new MorseNode("w",
					new MorseNode("p", nullptr, nullptr),
					new MorseNode("j", nullptr, nullptr)))),
		new MorseNode("t",
			new MorseNode("n",
				new MorseNode("d",
					new MorseNode("b", nullptr, nullptr),
					new MorseNode("x", nullptr, nullptr)),
				new MorseNode("k",
					new MorseNode("c", nullptr, nullptr),
					new MorseNode("y", nullptr, nullptr))),
			new MorseNode("m",
				new MorseNode("g",
					new MorseNode("z", nullptr, nullptr),
					new MorseNode("q", nullptr, nullptr)),
				new MorseNode("o",
					nullptr,
					new MorseNode("ch", nullptr, nullptr)))));
}


MorseDekoder::~MorseDekoder()
{
	ZmazStrom(start);
}

void MorseDekoder::ZmazStrom(MorseNode  *node)
{
	if (!node) return;
	if (node->getLavy())  // ak existuje lavy uzol
	{
		ZmazStrom(node->getLavy());
		printf("%s\n", node->getLavy()->getZnak());
		delete node->getLavy();
	}
	if (node->getPravy()) // ak existuje pravy uzol
	{
		ZmazStrom(node->getPravy());
		printf("%s\n", node->getPravy()->getZnak());
		delete node->getPravy();
	}
}

void MorseDekoder::Morse2Latin(const char * zdrojfilename, const char * cielfilename)
{
	char buf[1000];
	int i = 0;
	const char *pismeno;
	FILE *fzdroj = fopen(zdrojfilename, "rt");
	if (fzdroj)
	{
		FILE *fciel = fopen(cielfilename, "wt");
		if (fciel) {
			MorseNode *node = start;
			while (!feof(fzdroj)) {
				char c = fgetc(fzdroj);
				switch (c) {
				default:
					break;
				case '\/':
					pismeno = node->getZnak();
					fputs(pismeno, fciel);
					for (int j = 0; j < strlen(pismeno); j++)
						buf[i++] = pismeno[j];
					buf[i] = 0;
					node = start;
					break;
				case '.':
					node = node->getLavy();
					break;
				case '-':
					node = node->getPravy();
					break;
				}
			}
			fclose(fciel);
		}
		fclose(fzdroj);
	}
}
