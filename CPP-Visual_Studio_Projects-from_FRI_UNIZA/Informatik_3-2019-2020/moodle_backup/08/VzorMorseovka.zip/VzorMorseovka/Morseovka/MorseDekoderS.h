#pragma once
#include "MorseNode.h"

class MorseDekoderS
{
private:
	MorseNode *start;
	void ZmazStrom(MorseNode  *node);
public:
	MorseDekoderS();
	~MorseDekoderS();

	void Morse2Latin(const char *zdrojfilename, const char *cielfilename);
};

