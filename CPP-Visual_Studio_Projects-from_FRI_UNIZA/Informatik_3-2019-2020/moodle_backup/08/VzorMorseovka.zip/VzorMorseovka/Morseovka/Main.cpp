#include "MorseDekoder.h"

int main()
{
	MorseDekoder d,e(d);
	d.Morse2Latin("text.mrs", "text.lat");
//	e.Morse2Latin("text.mrs", "text.lat");
	return 0;
}