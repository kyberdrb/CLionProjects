#pragma once
#include <cstring>

class MorseNode
{
private:
	char znak[3];
	MorseNode *lavy;
	MorseNode *pravy;
public:

	MorseNode(const char *pznak,MorseNode *plavy,MorseNode *ppravy)
	{
		strcpy(znak, pznak);
		lavy = plavy;
		pravy = ppravy;
	}
	const char *getZnak() { return znak; }
	MorseNode *getLavy() { return lavy; }
	MorseNode *getPravy() { return pravy; }
};

