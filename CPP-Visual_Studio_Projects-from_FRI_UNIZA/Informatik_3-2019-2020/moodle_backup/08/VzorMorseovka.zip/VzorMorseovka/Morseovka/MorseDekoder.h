#pragma once
#include "MorseNode.h"

class MorseDekoder
{
private:
	MorseNode *start;
	void ZmazStrom(MorseNode  *node);
public:
	MorseDekoder();
	MorseDekoder(int x) {}
	MorseDekoder(const MorseDekoder &zdroj) : MorseDekoder() {}
	~MorseDekoder();

	void Morse2Latin(const char *zdrojfilename, const char *cielfilename);
};

