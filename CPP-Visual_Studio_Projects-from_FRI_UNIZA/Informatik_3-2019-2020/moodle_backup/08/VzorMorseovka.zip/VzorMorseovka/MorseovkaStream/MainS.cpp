#include "MorseDekoderS.h"

int main()
{
	MorseDekoderS d;
	d.Morse2Latin("text.mrs", "text.lts");
	return 0;
}