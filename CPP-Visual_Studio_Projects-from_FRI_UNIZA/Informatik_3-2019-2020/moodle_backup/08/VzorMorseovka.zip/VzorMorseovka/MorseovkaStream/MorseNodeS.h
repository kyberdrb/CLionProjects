#pragma once
#include <cstring>

class MorseNodeS
{
private:
	char znak[3];
	MorseNodeS *lavy;
	MorseNodeS *pravy;
public:

	MorseNodeS(const char *pznak, MorseNodeS *plavy, MorseNodeS *ppravy)
	{
		strcpy(znak, pznak);
		lavy = plavy;
		pravy = ppravy;
	}
	const char *getZnak() { return znak; }
	MorseNodeS *getLavy() { return lavy; }
	MorseNodeS *getPravy() { return pravy; }
};

