#pragma once
#include "MorseNodeS.h"

class MorseDekoderS
{
private:
	MorseNodeS *start;
	void ZmazStrom(MorseNodeS  *node);
public:
	MorseDekoderS();
	MorseDekoderS(const MorseDekoderS &zdroj) : MorseDekoderS() {}
	~MorseDekoderS();

	void Morse2Latin(const char *zdrojfilename, const char *cielfilename);
};

