#include <fstream>
#include "MorseDekoderS.h"

using namespace std;

MorseDekoderS::MorseDekoderS()
{
	start = new MorseNodeS(" ",
		new MorseNodeS("e",
			new MorseNodeS("i",
				new MorseNodeS("s",
					new MorseNodeS("h", nullptr, nullptr),
					new MorseNodeS("v", nullptr, nullptr)),
				new MorseNodeS("u",
					new MorseNodeS("f", nullptr, nullptr),
					nullptr)),
			new MorseNodeS("a",
				new MorseNodeS("r",
					new MorseNodeS("l", nullptr, nullptr),
					nullptr),
				new MorseNodeS("w",
					new MorseNodeS("p", nullptr, nullptr),
					new MorseNodeS("j", nullptr, nullptr)))),
		new MorseNodeS("t",
			new MorseNodeS("n",
				new MorseNodeS("d",
					new MorseNodeS("b", nullptr, nullptr),
					new MorseNodeS("x", nullptr, nullptr)),
				new MorseNodeS("k",
					new MorseNodeS("c", nullptr, nullptr),
					new MorseNodeS("y", nullptr, nullptr))),
			new MorseNodeS("m",
				new MorseNodeS("g",
					new MorseNodeS("z", nullptr, nullptr),
					new MorseNodeS("q", nullptr, nullptr)),
				new MorseNodeS("o",
					nullptr,
					new MorseNodeS("ch", nullptr, nullptr)))));
}


MorseDekoderS::~MorseDekoderS()
{
	ZmazStrom(start);
}

void MorseDekoderS::ZmazStrom(MorseNodeS  *node)
{
	if (!node) return;
	if (node->getLavy())  // ak existuje lavy uzol
	{
		ZmazStrom(node->getLavy());
		printf("%s\n", node->getLavy()->getZnak());
		delete node->getLavy();
	}
	if (node->getPravy()) // ak existuje pravy uzol
	{
		ZmazStrom(node->getPravy());
		printf("%s\n", node->getPravy()->getZnak());
		delete node->getPravy();
	}
}

void MorseDekoderS::Morse2Latin(const char * zdrojfilename, const char * cielfilename)
{
	char buf[1000];
	int i = 0;
	const char *pismeno;
	ifstream  zdroj(zdrojfilename);
	if (zdroj.is_open())
	{
		ofstream ciel(cielfilename);
		if (ciel.is_open()) {
			MorseNodeS *node = start;
			while (!zdroj.eof()) {
				char c = zdroj.get();
				switch (c) {
				default:
					break;
				case '\/':
					pismeno = node->getZnak();
					ciel.write(pismeno,strlen(pismeno));
					for (int j = 0; j < strlen(pismeno); j++)
						buf[i++] = pismeno[j];
					buf[i] = 0;
					node = start;
					break;
				case '.':
					node = node->getLavy();
					break;
				case '-':
					node = node->getPravy();
					break;
				}
			}
		}
	}
}
