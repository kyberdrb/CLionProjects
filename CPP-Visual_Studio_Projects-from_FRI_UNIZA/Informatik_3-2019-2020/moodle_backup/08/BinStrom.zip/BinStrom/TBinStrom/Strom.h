#pragma once
#include <iostream>
#include "Uzol.h"

using namespace std;

template <class T>
class Strom
{
private:
	void ZrusStrom(Uzol<T> *list)
	{
		if (list != nullptr)
		{
			ZrusStrom(list->Vlavo());
			ZrusStrom(list->Vpravo());
			delete list;
		}

	}
	void Vloz(T data, Uzol<T> *list) {
		if (data < list->Data())
		{
			if (list->Vlavo() != nullptr)
				Vloz(data, list->Vlavo());
			else
			{
				list->Vlavo(new Uzol<T>);
				list->Vlavo()->Data(data);
				list->Vlavo()->Vlavo(nullptr);    //Sets the Vlavo() child of the child Uzol to null
				list->Vlavo()->Vpravo(nullptr);   //Sets the Vpravo() child of the child Uzol to null
			}
		}
		else if (data >= list->Data())
		{
			if (list->Vpravo() != nullptr)
				Vloz(data, list->Vpravo());
			else
			{
				list->Vpravo(new Uzol<T>);
				list->Vpravo()->Data(data);
				list->Vpravo()->Vlavo(nullptr);  //Sets the Vlavo() child of the child Uzol to null
				list->Vpravo()->Vpravo(nullptr); //Sets the Vpravo() child of the child Uzol to null
			}
		}
	}

	Uzol<T> *Najdi(int data, Uzol<T> *list)
	{
		if (list != nullptr)
		{
			if (data == list->Data())
				return list;
			if (data < list->Data())
				return Najdi(data, list->Vlavo());
			else
				return Najdi(data, list->Vpravo());
		}
		else return nullptr;
	}

	void Vypis(Uzol<T> *uzol)
	{
		if (uzol != nullptr)
		{
			Vypis(uzol->Vlavo());
			cout << uzol->Data() << endl;
			Vypis(uzol->Vpravo());
		}
	}

	Uzol<T> *koren;
public:
	Strom() : koren(nullptr) {}
	~Strom() { ZrusStrom(); }

	void Vloz(T data) {
		if (koren != nullptr)
			Vloz(data, koren);
		else
		{
			koren = new Uzol<T>;
			koren->Data(data);
			koren->Vlavo(nullptr);
			koren->Vpravo(nullptr);
		}

	}
	Uzol<T> *Najdi(T data)
	{
		return Najdi(data, koren);
	}

	void ZrusStrom()
	{
		ZrusStrom(koren);
	}

	void Vypis() {
		Vypis(koren);
	}
};
