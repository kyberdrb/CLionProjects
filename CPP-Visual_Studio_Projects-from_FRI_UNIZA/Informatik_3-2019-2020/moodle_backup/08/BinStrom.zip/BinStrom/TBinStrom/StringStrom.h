#pragma once
#include "Strom.h"
class StringStrom : public Strom<string>
{
public:
	StringStrom() {}
	~StringStrom() {}
};

