#include <string>
#include <iostream>
#include "Strom.h"
#include "StringStrom.h"
using namespace std;

typedef Strom<string> SStrom;

int main()
{
	SStrom bstrom;
	bstrom.Vloz("V");
	bstrom.Vloz("bha");
	bstrom.Vloz("zsda");
	bstrom.Vloz("iop");
	bstrom.Vloz("qwe");
	bstrom.Vloz("asd");
	bstrom.Vloz("opi");
	bstrom.Vypis();
	string x("a");
	return 0;
}