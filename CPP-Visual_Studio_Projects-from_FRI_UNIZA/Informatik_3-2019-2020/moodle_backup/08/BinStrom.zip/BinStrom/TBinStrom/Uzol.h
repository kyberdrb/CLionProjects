#pragma once
template <class T>
class Uzol
{
	T data;
	Uzol *vlavo = nullptr;
	Uzol *vpravo = nullptr;

public:
	Uzol() {}
	~Uzol() {}
	T Data() { return data; }
	Uzol *Vlavo() { return vlavo; }
	Uzol *Vpravo() { return vpravo; };

	void Data(T pdata) { data = pdata; }
	void Vlavo(Uzol *uzol) { vlavo = uzol; }
	void Vpravo(Uzol *uzol) { vpravo = uzol; };
};

