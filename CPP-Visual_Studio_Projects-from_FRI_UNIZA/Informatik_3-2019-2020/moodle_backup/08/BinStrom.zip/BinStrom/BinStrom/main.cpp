#include "Strom.h"

int main()
{
	Strom bstrom;
	bstrom.Vloz(10);
	bstrom.Vloz(100);
	bstrom.Vloz(9);
	bstrom.Vloz(7);
	bstrom.Vloz(20);
	bstrom.Vloz(101);
	bstrom.Vloz(45);
	bstrom.Vypis();
	return 0;
}