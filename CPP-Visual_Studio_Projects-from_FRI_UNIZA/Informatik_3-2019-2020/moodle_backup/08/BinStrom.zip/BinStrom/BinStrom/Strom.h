#pragma once
#include "Uzol.h"

class Strom
{
private:
	void ZrusStrom(Uzol *list);
	void Vloz(int data, Uzol *list);
	Uzol *Najdi(int data, Uzol *list);
	void Vypis(Uzol *uzol);

	Uzol *koren;
public:
	Strom() : koren(nullptr) {}
	~Strom() { ZrusStrom(); }

	void Vloz(int data);
	Uzol *Najdi(int data);
	void ZrusStrom();

	void Vypis();
};

