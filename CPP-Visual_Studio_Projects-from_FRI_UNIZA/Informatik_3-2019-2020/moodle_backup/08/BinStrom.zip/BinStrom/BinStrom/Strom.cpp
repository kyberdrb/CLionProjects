#include <iostream>
#include "Strom.h"
using namespace std;

void Strom::ZrusStrom(Uzol * list)
{

	if (list != nullptr)
	{
		ZrusStrom(list->Vlavo());
		ZrusStrom(list->Vpravo());
		//cout << list->Data() << endl;
		delete list;
	}
}

void Strom::Vloz(int data, Uzol * list)
{
	if (data < list->Data())
	{
		if (list->Vlavo() != nullptr)
			Vloz(data, list->Vlavo());
		else
		{
			list->Vlavo(new Uzol);
			list->Vlavo()->Data(data);
			list->Vlavo()->Vlavo(nullptr);    //Sets the Vlavo() child of the child Uzol to null
			list->Vlavo()->Vpravo(nullptr);   //Sets the Vpravo() child of the child Uzol to null
		}
	}
	else if (data >= list->Data())
	{
		if (list->Vpravo() != nullptr)
			Vloz(data, list->Vpravo());
		else
		{
			list->Vpravo(new Uzol);
			list->Vpravo()->Data(data);
			list->Vpravo()->Vlavo(nullptr);  //Sets the Vlavo() child of the child Uzol to null
			list->Vpravo()->Vpravo(nullptr); //Sets the Vpravo() child of the child Uzol to null
		}
	}
}

Uzol * Strom::Najdi(int data, Uzol * list)
{
	if (list != nullptr)
	{
		if (data == list->Data())
			return list;
		if (data < list->Data())
			return Najdi(data, list->Vlavo());
		else
			return Najdi(data, list->Vpravo());
	}
	else return nullptr;
}

void Strom::Vypis(Uzol * uzol)
{
	if (uzol!= nullptr)
	{
		Vypis(uzol->Vlavo());
		cout << uzol->Data() << endl;
		Vypis(uzol->Vpravo());
	}
}

void Strom::Vloz(int data)
{
	if (koren != nullptr)
		Vloz(data, koren);
	else
	{
		koren = new Uzol;
		koren->Data(data);
		koren->Vlavo(nullptr);
		koren->Vpravo(nullptr);
	}
}

Uzol * Strom::Najdi(int data)
{
	return Najdi(data, koren);
}

void Strom::ZrusStrom()
{
	ZrusStrom(koren);
}

void Strom::Vypis()
{
	Vypis(koren);
}
