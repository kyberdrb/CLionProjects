#pragma once
class Uzol
{
	int data;
	Uzol *vlavo = nullptr;
	Uzol *vpravo = nullptr;

public:
	Uzol() {};
	~Uzol() {};
	int Data() { return data; }
	Uzol *Vlavo() { return vlavo; }
	Uzol *Vpravo() { return vpravo; };

	void Data(int pdata) { data = pdata; }
	void Vlavo(Uzol *uzol) { vlavo = uzol; }
	void Vpravo(Uzol *uzol) { vpravo = uzol; };
};

