#include "Mnozina.h"

Mnozina::Mnozina(int pocetprvkov)
	: pole(pocetprvkov)
{
}


Mnozina::~Mnozina()
{
}

void Mnozina::pridaj(int cislo)
{
	if (!pole.najdi(cislo))
		pole.pridaj(cislo);
}

Mnozina Mnozina::operator&(Mnozina & m2)
{
	Mnozina &m1 = *this;
	int m1pocet(m1.GetPocetPrvkov()),
		m2pocet(m2.GetPocetPrvkov());
	Mnozina ciel(m1pocet < m2pocet ? m1pocet : m2pocet);
	int im1 = 0, im2 = 0;
	while (true)
	{
		if (im1 >= m1pocet || im2 >= m2pocet)
			break;
		int m1val = m1.pole.GetInt(im1);
		int m2val = m2.pole.GetInt(im2);
		if (m1val == m2val)
		{
			ciel.pridaj(m1val);
			im1++;
			im2++;
		}
		if (m1val < m2val)
			im1++;
		if (m1val > m2val)
			im2++;
	}
	return ciel;
}
