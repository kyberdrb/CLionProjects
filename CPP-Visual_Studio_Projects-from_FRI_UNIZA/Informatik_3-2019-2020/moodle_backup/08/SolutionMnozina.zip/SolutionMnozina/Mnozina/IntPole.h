#pragma once
class IntPole
{
private:
	int kapacita;
	int obsadene;
	int *data;
	void utried();
public:
	IntPole(int kapacita = 0);
	IntPole(const IntPole &zdroj);
	IntPole &operator = (const IntPole &zdroj);
	void pridaj(int cislo);
	void vymaz(int cislo);
	bool najdi(int cislo);
	int GetObsadene() { return obsadene; }
	int GetInt(int index) { return data[index]; }
	~IntPole();
};

