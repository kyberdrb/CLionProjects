#pragma once
#include "IntPole.h"

class Mnozina
{
private:
	IntPole pole;
public:
	Mnozina(int pocetprvkov = 0);
	Mnozina(const Mnozina &zdroj) : pole(zdroj.pole) {}
	Mnozina &operator =(const Mnozina &zdroj)
	{
		if (this != &zdroj) {
			pole = zdroj.pole;
		}
		return *this;
	}
	~Mnozina();
	int GetPocetPrvkov() { return pole.GetObsadene(); }
	void pridaj(int cislo);
	Mnozina operator &(Mnozina &m2);
};

