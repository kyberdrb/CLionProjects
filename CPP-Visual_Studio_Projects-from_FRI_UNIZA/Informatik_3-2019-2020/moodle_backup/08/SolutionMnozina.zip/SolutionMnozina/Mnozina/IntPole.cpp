#include <cstring>
#include <cstdlib>
#include "IntPole.h"

int porovnajInt(const void *p1, const void *p2)
{
	int *i1((int *)p1), *i2((int *)p2);
	return *i1 - *i2;
}

void IntPole::utried()
{
	qsort(data, obsadene, sizeof(int), porovnajInt);
}

IntPole::IntPole(int pkapacita)
	: kapacita(pkapacita), obsadene(0),
	data(kapacita > 0 ? new int[kapacita] : nullptr)
{
	if (kapacita)
		memset(data, 0, kapacita * sizeof(int));
}

IntPole::IntPole(const IntPole & zdroj)
	: kapacita(zdroj.kapacita), obsadene(zdroj.obsadene),
	data(kapacita > 0 ? new int[kapacita] : nullptr)
{
	if (kapacita)
		memmove(data, zdroj.data, kapacita * sizeof(int));
}

IntPole & IntPole::operator=(const IntPole & zdroj)
{
	if (this != &zdroj)
	{
		kapacita = zdroj.kapacita;
		obsadene = zdroj.obsadene;
		data = nullptr;
		if (kapacita)
		{
			data = new int[kapacita];
			memmove(data, zdroj.data, kapacita * sizeof(int));
		}
	}
	return *this;
}

void IntPole::pridaj(int cislo)
{
	if (obsadene == kapacita) {
		obsadene++;
		kapacita++;
		int *novedata = new int[kapacita];
		if (kapacita > 1)
			memmove(novedata, data, (kapacita - 1) * sizeof(int));
		novedata[kapacita - 1] = cislo;
		delete[] data;
		data = novedata;
	}
	else
		data[obsadene++] = cislo;
	utried();
}

void IntPole::vymaz(int cislo)
{
	int i;
	for (i = 0; i < kapacita; i++)
	{
		if (data[i] == cislo)
		{
			kapacita--;
			obsadene--;
			if (kapacita > 1) {
				memmove(data, data, i * sizeof(int));
				memmove(&data[i], data, (kapacita - i) * sizeof(int));
			}
		}
	}
}

bool IntPole::najdi(int cislo)
{
	for (int i = 0; i < kapacita; i++)
	{
		if (data[i] == cislo)
			return true;
	}
	return false;
}


IntPole::~IntPole()
{
	delete[] data;
}
