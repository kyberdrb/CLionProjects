#include "Mnozina.h"

int main()
{
	Mnozina m1(2), m2, m3;

	m1.pridaj(9);
	m1.pridaj(3);
	m1.pridaj(7);
	m2.pridaj(9);
	m2.pridaj(1);
	m2.pridaj(9);
	m2.pridaj(7);
	m3 = m1&m2;
	return 0;
}