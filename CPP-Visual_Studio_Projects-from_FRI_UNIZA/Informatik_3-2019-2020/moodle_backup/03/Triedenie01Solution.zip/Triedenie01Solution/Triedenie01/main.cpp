#include "Test.h"

int main()
{
	//Test testy;
	//testy.Start();

	Test *testy;
	testy = new Test();

	testy->Start();

	delete testy;
	return 0;
}