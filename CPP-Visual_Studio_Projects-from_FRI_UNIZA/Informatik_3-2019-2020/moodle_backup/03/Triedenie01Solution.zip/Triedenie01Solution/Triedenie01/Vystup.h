#pragma once
class Vystup
{
};

