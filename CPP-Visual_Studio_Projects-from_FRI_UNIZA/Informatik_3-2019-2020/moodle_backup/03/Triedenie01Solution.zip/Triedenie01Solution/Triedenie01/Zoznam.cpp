#include "Zoznam.h"
#include "Vstup.h"

void Zoznam::Usporiadaj(char* menosuboru, PorovnajPtr porovnavaciaFun)
{
	//	if (menosuboru != nullptr && *menosuboru != 0)
	if (menosuboru && *menosuboru)
	{
		Vstup citac(menosuboru);
		Data* data, * predchadzajuci;
		TYP_HODNOTA cislo = citac.Citaj();
		while (cislo != NEPLATNA_HODNOTA)
		{
			if (aStart == nullptr)
				aStart = new Data(cislo, nullptr);
			else
			{
				predchadzajuci = nullptr;
				data = aStart;
				TYP_HODNOTA datauzol = data->Hodnota();
				while (data != nullptr && porovnavaciaFun(&cislo, &datauzol) > 0)
				{
					predchadzajuci = data;
					data = data->Nasledovnik();
				}
				data = new Data(cislo, data);
				if (predchadzajuci == nullptr)
					aStart = data;
				else
					predchadzajuci->Nasledovnik(data);
			}
			cislo = citac.Citaj();
		}
	}
}

void Zoznam::Zapis(char* menosuboru)
{
}
