#pragma once
class Test
{
public:
	bool Start();
};

