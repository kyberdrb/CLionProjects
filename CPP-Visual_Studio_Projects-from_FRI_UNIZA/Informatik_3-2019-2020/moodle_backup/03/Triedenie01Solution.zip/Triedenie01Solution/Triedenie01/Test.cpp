#include "Test.h"
#include "Vstup.h"
#include "Data.h"
#include "Zoznam.h"

bool Test::Start()
{
	Zoznam z;
	z.Usporiadaj((char*)"data.txt", Porovnaj);

	Vstup citac((char*)"data.txt");
	
	Data uzol(10, nullptr);

	uzol.Nasledovnik();
	TYP_HODNOTA x = citac.Citaj();
	TYP_HODNOTA y = citac.Citaj();
	for (int i = 0; i < 20; i++)
	{
		x = citac.Citaj();
		y = citac.Citaj();
	}
	return true;
}
