#pragma once
#include "Data.h"

class Zoznam
{
private:
	Data* aStart = nullptr;
public:
	void Usporiadaj(char* menosuboru, PorovnajPtr porovnavaciaFun);
	void Zapis(char* menosuboru);
};

