#pragma once
#include <cstdio>
#include "Data.h"

class Vstup
{
private:
	FILE* fDescriptor = NULL;
public:
	Vstup(char* menosuboru);
	TYP_HODNOTA Citaj();
	~Vstup();
};

