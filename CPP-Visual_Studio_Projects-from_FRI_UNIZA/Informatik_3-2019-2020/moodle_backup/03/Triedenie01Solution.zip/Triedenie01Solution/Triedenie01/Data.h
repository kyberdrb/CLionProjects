#pragma once
typedef int TYP_HODNOTA;

const TYP_HODNOTA NEPLATNA_HODNOTA = 0;

int Porovnaj(void* data1, void* data2);
typedef int (*PorovnajPtr)(void* data1, void* data2);

class Data
{
private:
	TYP_HODNOTA aHodnota = NEPLATNA_HODNOTA;
	Data* aNasledovnik = nullptr;

public:
	Data(TYP_HODNOTA phodnota, Data* pdalsi)
	{
		aHodnota = phodnota;
		aNasledovnik = pdalsi;
	}

	TYP_HODNOTA Hodnota()
	{
		return aHodnota;
	}

	Data* Nasledovnik()
	{
		return aNasledovnik;
	}

	void Nasledovnik(Data* pnasledovnik)
	{
		aNasledovnik = pnasledovnik;
	}
};

