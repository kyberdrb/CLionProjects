#include "Data.h"

int Porovnaj(void* data1, void* data2)
{
	TYP_HODNOTA* pdata1 = (TYP_HODNOTA*)data1;
	TYP_HODNOTA* pdata2 = (TYP_HODNOTA*)data2;
	return *pdata1 - *pdata2;
}
