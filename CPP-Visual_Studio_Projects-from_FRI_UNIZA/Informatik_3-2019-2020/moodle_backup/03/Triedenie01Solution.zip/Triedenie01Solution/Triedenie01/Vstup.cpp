#include "Vstup.h"

Vstup::Vstup(char* menosuboru)
{
	//if (menosuboru != NULL && menosuboru[0] != 0)
	//if (menosuboru != NULL && *menosuboru != 0)
	if (menosuboru && *menosuboru)
	{
		fDescriptor = fopen(menosuboru, "rt");
	}
}

TYP_HODNOTA Vstup::Citaj()
{
	if (fDescriptor != nullptr)
	{
		if (!feof(fDescriptor)) 
		{
			TYP_HODNOTA cislo;
			fscanf(fDescriptor, "%d", &cislo);
			return cislo;
		}
	}
	return NEPLATNA_HODNOTA;
}

Vstup::~Vstup()
{
	if (fDescriptor != NULL)
		fclose(fDescriptor);
	fDescriptor = NULL;
}
