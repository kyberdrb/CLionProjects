#include "Vstup.h"

Vstup::Vstup(const char* menoSuboru)
{
	//if (menoSuboru != nullptr && menoSuboru[0] != '\0')
	if (menoSuboru && *menoSuboru)
		fHandle = fopen(menoSuboru, "rt");
}

Vstup::~Vstup()
{
	if (fHandle != nullptr)
		fclose(fHandle);
}

MInt Vstup::Citaj()
{
	if (fHandle != nullptr)
	{
		if (!feof(fHandle))
		{
			int cislo;
			fscanf(fHandle, "%d", &cislo);
			// Pozor do fscanf sa posiela adresa premennej &cislo;
			return cislo;
		}
	}
	return NEPLATNA_HODNOTA;
}

