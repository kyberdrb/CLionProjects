#pragma once
class Testy
{
public:
	bool Start();
};

