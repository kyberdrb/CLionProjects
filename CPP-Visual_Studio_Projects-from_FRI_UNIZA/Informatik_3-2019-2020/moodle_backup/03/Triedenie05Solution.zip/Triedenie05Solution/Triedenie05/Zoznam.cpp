#include "Zoznam.h"
#include "Vstup.h"
#include "Vystup.h"

void Zoznam::Usporiadaj(const char* pmenosuboru,
	PorovnajPtr porovFun)
{
	if (pmenosuboru && *pmenosuboru)
	{
		Vstup citac(pmenosuboru);
		DataUzol* uzol, * predchadzajuci;
		MInt novecislo = citac.Citaj();
		while (novecislo != NEPLATNA_HODNOTA)
		{
			//if (aStart == nullptr)
			if (!aStart)
				aStart = new DataUzol(novecislo, nullptr);
			else
			{
				predchadzajuci = nullptr;
				uzol = aStart;
				while (uzol != nullptr && porovFun(&novecislo, uzol->HodnotaPtr()) > 0)
				{
					predchadzajuci = uzol;
					uzol = uzol->Nasledovnik();
				}
				uzol = new DataUzol(novecislo, uzol);
				if (predchadzajuci == nullptr)
					aStart = uzol;
				else
					predchadzajuci->Nasledovnik(uzol);
			}
			novecislo = citac.Citaj();
		}
	}
}

void Zoznam::Zapis(const char* pmenosuboru)
{
	Vystup zapisovac(pmenosuboru);
	Vystup zobrazovac(nullptr);
	DataUzol* uzol = aStart;
	while (uzol != nullptr)
	{
		MInt hodnota = uzol->Hodnota();
		zapisovac.Zapis(hodnota);
		zobrazovac.Zapis(hodnota);
		uzol = uzol->Nasledovnik();
	}
}
