#pragma once
#include <cstdio>
#include "DataUzol.h"

class Vstup
{
private:
	FILE* fHandle = nullptr;
public:
	Vstup(const char* menoSuboru);
	~Vstup();
	MInt Citaj();
};

