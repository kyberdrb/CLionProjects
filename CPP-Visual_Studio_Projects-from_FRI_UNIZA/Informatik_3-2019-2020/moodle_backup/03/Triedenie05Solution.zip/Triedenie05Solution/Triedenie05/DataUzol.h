#pragma once

typedef int MInt;
typedef int (*PorovnajPtr)(void* cis1ptr, void* cis2ptr);

const MInt	NEPLATNA_HODNOTA = 0;

class DataUzol
{
private:
	MInt aHodnota = NEPLATNA_HODNOTA;
	DataUzol* aNasledovnik = nullptr;
public:

	DataUzol(MInt phodnota, DataUzol* pnasledovnik)
	{
		aHodnota = phodnota;
		aNasledovnik = pnasledovnik;
	}

	int Hodnota() { return aHodnota; }
	int* HodnotaPtr() { return &aHodnota; }

	DataUzol* Nasledovnik()
	{
		return aNasledovnik;
	}

	void Nasledovnik(DataUzol* pnasledvnik)
	{
		aNasledovnik = pnasledvnik;
	}
};

int Porovnaj(void* cis1ptr, void* cis2ptr);
int PorovnajKlesajuco(void* cis1ptr, void* cis2ptr);