#pragma once
#include "DataUzol.h"

class Zoznam
{
private:
	DataUzol* aStart = nullptr;
public:
	void Usporiadaj(const char* pmenosuboru, PorovnajPtr porovFun);
	void Zapis(const char* pmenosuboru);
};

