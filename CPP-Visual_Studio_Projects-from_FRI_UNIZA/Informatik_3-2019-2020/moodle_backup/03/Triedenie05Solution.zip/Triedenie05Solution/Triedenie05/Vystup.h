#pragma once
#include <cstdio>
#include "DataUzol.h"

class Vystup
{
private:
	FILE* fHandle = nullptr;
public:
	Vystup(const char* menoSuboru);
	~Vystup();
	void Zapis(MInt data);
};

