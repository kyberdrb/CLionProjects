#include "DataUzol.h"

int Porovnaj(void* cis1ptr, void* cis2ptr)
{
	MInt* cis1p = (MInt*)cis1ptr;
	MInt* cis2p = (MInt*)cis2ptr;
	return *cis1p - *cis2p;
}

int PorovnajKlesajuco(void* cis1ptr, void* cis2ptr)
{
	return -Porovnaj(cis1ptr, cis2ptr);
}
