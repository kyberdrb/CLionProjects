#include "Testy.h"
#include "Vstup.h"
#include "Vystup.h"
#include "Zoznam.h"

bool Testy::Start()
{
	Zoznam zretazenyzoznam;
	zretazenyzoznam.Usporiadaj("data.txt", PorovnajKlesajuco);
	zretazenyzoznam.Zapis("data.out");
	//Vstup citac("data.txt");
	//MInt x = citac.Citaj();
	//if (x != -5)
	//	return false;
	//MInt y = citac.Citaj();
	//if (y != -10)
	//	return false;
	//MInt z = citac.Citaj();

	//Vystup zapisovac("data.out");
	//Vystup zobrazovac(nullptr);
	//zapisovac.Zapis(x);
	//zobrazovac.Zapis(x);
	//zapisovac.Zapis(y);
	//zobrazovac.Zapis(y);
	//zapisovac.Zapis(z);
	//zobrazovac.Zapis(z);
	return true;
}
