#include "Vystup.h"

Vystup::Vystup(const char* menoSuboru)
{
	//if (menoSuboru != nullptr && menoSuboru[0] != '\0')
	if (menoSuboru && *menoSuboru)
		fHandle = fopen(menoSuboru, "wt");
}

Vystup::~Vystup()
{
	if (fHandle != nullptr)
		fclose(fHandle);
}

void Vystup::Zapis(MInt data)
{
	//if(fHandle!=nullptr)
	if (fHandle)
		fprintf(fHandle, "%d\n", data);
	else
		printf("%d\n", data);
}
