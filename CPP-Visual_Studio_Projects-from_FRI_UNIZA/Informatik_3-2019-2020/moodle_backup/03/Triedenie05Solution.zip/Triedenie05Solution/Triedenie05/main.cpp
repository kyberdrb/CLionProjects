#define TESTY
#ifdef TESTY
   #include "Testy.h"
#endif

int main()
{
	bool OK = true;
#ifdef TESTY
	Testy test;
//	OK = test.Start();
	OK = Testy().Start();
#endif
	if (OK)
	{

	}
	return 0;
}