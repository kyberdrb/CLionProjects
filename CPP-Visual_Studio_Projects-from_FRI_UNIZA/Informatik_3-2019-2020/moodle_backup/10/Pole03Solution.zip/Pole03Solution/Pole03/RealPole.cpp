#include <cstdlib>
#include <cstdio>
#include <cstring>
#include "RealPole.h"
#include "Vynimka.h"

RealPole::RealPole(unsigned int rozsah, int dolnyindex, double initval)
: aRozsah(rozsah),
aDolnyIndex(dolnyindex),
aData(rozsah > 0 ? new double[rozsah] : NULL)
{
	for (unsigned int i = 0; i < aRozsah; i++)
		aData[i] = initval;
	printf(" ---  RealPole --- \n");
}

void RealPole::copy(const RealPole &zdroj)
{
	aRozsah = zdroj.aRozsah;
	aDolnyIndex = zdroj.aDolnyIndex;
	aData = aRozsah > 0 ? new double[aRozsah] : NULL;
	if (!aData)
		memmove(aData, zdroj.aData, aRozsah*sizeof(double));
	//for (unsigned int i = 0; i < aRozsah; i++)
	//	aData[i] = zdroj.aData[i];
}

RealPole::RealPole(const RealPole &zdroj)
{
	copy(zdroj);
}

RealPole &RealPole::operator =(const RealPole &zdroj)
{
	if (this != &zdroj)
	{
		RealPole::~RealPole();
		copy(zdroj);
	}
	return *this;
}

RealPole::~RealPole()
{
	delete[] aData;
	printf(" --- ~RealPole --- \n");
}

double &RealPole::operator[](int index)
{
	if (index < aDolnyIndex)
		throw VynimkaDolnyIndex(aDolnyIndex);
	int hornyindex = aDolnyIndex + aRozsah - 1;
	if (index > hornyindex)
		throw VynimkaHornyIndex(hornyindex);
	return aData[index - aDolnyIndex];
}

void RealPole::vypis()
{
	for (int i = 0; i < aRozsah; i++)
		cout << aData[i] << endl;
	cout << endl;
}

int porovnajR(const void *p1, const void *p2)
{
	double d1 = *(double *)p1;
	double d2 = *(double *)p2;
	if (d1 < d2)
		return -1;
	return d1>d2 ? 1 : 0;
}

int porovnajK(const void *p1, const void *p2)
{
	return porovnajR(p1, p2) * -1;
}

void RealPole::sortuj(bool rastuco)
{
	qsort(aData, aRozsah, sizeof(double), rastuco ? porovnajR : porovnajK);
}
