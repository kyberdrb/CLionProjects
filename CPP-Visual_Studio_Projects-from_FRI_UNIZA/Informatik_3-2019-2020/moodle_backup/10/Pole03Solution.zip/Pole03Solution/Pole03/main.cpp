#include <iostream>
#include "Klient.h"
#include "Vynimka.h"

int main()
{
	try
	{
		int hi = 500, di = -1000;
		bool opakuj{ true };
		do {
			try
			{
				Klient k(hi,di);

				k.vypis();
				k.sortujRastuco();
				k.vypis();
				k.sortujKlesajuco();
				k.vypis();
				opakuj = false;
			}
			catch (VynimkaDolnyIndex &ex)
			{
				ex.vypis();
				di = ex.index();
			}
			catch (VynimkaHornyIndex &ex)
			{
				ex.vypis();
				hi = ex.index();
			}
		} while (opakuj);
	}
	catch (...)
	{
		std::cerr << "NEZNAMA VYNIMKA!" << std::endl;
	}
	return 0;
}