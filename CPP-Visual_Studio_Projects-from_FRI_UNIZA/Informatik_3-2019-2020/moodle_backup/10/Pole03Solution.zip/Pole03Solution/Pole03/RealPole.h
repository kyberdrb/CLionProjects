#pragma once
class VynimkaDolnyIndex;
class VynimkaHornyIndex;

class RealPole
{
private:
	double *aData;
	unsigned int aRozsah;
	int aDolnyIndex;
	void copy(const RealPole &zdroj);
public:
	RealPole(unsigned int rozsah = 11, int dolnyindex =-5, double initval = 0.0);
	RealPole(const RealPole &zdroj);
	RealPole &operator =(const RealPole &zdroj);
	~RealPole();

	double &operator[](int index) throw(VynimkaDolnyIndex &,VynimkaHornyIndex &);
	void vypis();
	void sortuj(bool rastuco);
};

