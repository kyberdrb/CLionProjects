#pragma once
#include <string>
#include <iostream>

using namespace std;

class Vynimka
{
private:
	int aIndex;
	string aOznam;
public:
	Vynimka(int index, const char *oznam)
		:aIndex(index), aOznam(oznam)
	{
	}

	void vypis()
	{
		cerr << aOznam << "Pripustna hodnota: " << aIndex << endl << endl;
	}
	int index() { return aIndex; }
};

class VynimkaDolnyIndex : public Vynimka
{
public:
	VynimkaDolnyIndex(int index)
		: Vynimka(index, "Dolny index mimo medze!")
	{
	}
};

class VynimkaHornyIndex : public Vynimka
{
public:
	VynimkaHornyIndex(int index)
		: Vynimka(index, "Horny index mimo medze!")
	{
	}
};

