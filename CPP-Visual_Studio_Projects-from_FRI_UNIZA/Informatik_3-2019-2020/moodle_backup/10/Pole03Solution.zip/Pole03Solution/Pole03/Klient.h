#pragma once
#include "RealPole.h"

class Klient
{
private:
	RealPole aDPole;
public:
	Klient(int di, int hi);
	~Klient();
	void pole(int index, double val) 
	{
		aDPole[index] = val;
	}

	void vypis() { aDPole.vypis(); }
	void sortujRastuco() { aDPole.sortuj(true); }
	void sortujKlesajuco() { aDPole.sortuj(false); }
};

