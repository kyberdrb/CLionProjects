#include <iostream>
#include "Klient.h"
#include "Vynimka.h"

using namespace std;

Klient::Klient(int di, int hi)
	: aDPole()
{
	aDPole[di] = 103.8;
	aDPole[hi] = 5.6;
}


Klient::~Klient()
{
}
