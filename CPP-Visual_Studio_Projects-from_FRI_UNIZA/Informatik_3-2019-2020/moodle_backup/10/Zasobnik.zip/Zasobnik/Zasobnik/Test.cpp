#include <iostream>
#include "Test.h"
#include "Zasobnik.h"

using namespace std;

Test::Test(void)
{
}


Test::~Test(void)
{
}


bool Test::Run(void)
{
	Zasobnik zas1;
	Zasobnik zas2(5);
	for(int i=15; i>=0; i--) {
		zas1.Push((i+1)*10);
	}
	int info;
	for(int i=0; i<17; i++) {
		info=zas1.Pop();
		cout<<info<<endl;
	}
	return true;
}
