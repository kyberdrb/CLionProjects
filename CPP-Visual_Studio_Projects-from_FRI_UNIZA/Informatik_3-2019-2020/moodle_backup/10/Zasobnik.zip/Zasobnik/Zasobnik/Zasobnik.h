#pragma once
class Zasobnik
{
private:
	int *aData;
	int aSP;
	int aFrameSize;
	int aSize;
	void Alok(const Zasobnik &src);

	void Realokuj(int size);
public:
	Zasobnik(int pFrameSize=10);
	Zasobnik(const Zasobnik &src);
	Zasobnik &operator =(const Zasobnik &src);
	~Zasobnik(void);
	void Push(int info);
	int Pop(void);
	int Peek(void);
};

