#include <stdlib.h>
#include <string.h>

#include "Zasobnik.h"


Zasobnik::Zasobnik(int pFrameSize)
{
	if(pFrameSize<=0) 
		pFrameSize = 10;
	aFrameSize = pFrameSize;
	aSize = aFrameSize;
	aSP = 0;
	aData = new int[aFrameSize];
}

void Zasobnik::Alok(const Zasobnik &src)
{
	aFrameSize = src.aFrameSize;
	aSize = src.aSize;
	aSP = src.aSP;
	aData = new int[aSize];
	memmove(aData,src.aData,aSize);
}

Zasobnik::Zasobnik(const Zasobnik &src)
{
	Alok(src);
}

Zasobnik &Zasobnik::operator =(const Zasobnik &src)
{
	if(this != &src) {
		delete[] aData;
		Alok(src);
	}
	return *this;
}

Zasobnik::~Zasobnik(void)
{
	delete[] aData;
}


void Zasobnik::Push(int info)
{
	if(aSP>=aSize)
	{
		Realokuj(aSize+aFrameSize);
		aSize += aFrameSize;
	}
	if(aSP<aSize) 
		aData[aSP++]=info;
}


int Zasobnik::Pop(void)
{
	if((aSP%aFrameSize)==0) 
	{
		aSize -= aFrameSize;
		Realokuj(aSize);
	}
	return aSP > 0 ? aData[--aSP] : 0;
}


int Zasobnik::Peek(void)
{
	return aSP > 0 ? aData[aSP-1] : 0;
}


void Zasobnik::Realokuj(int size)
{
	int *pomData;
	pomData = new int[size];
	if(pomData != NULL) {
		memmove(pomData,aData,aSize*sizeof(int));
	}
	delete[] aData;
	aData = pomData;
}
