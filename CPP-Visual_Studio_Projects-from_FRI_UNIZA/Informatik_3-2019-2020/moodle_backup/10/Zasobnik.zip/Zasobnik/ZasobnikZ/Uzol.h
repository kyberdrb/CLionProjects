#pragma once
class Uzol
{
private:
	int aInfo;
public:
	Uzol(int pInfo,Uzol *pDalsi);
	~Uzol(void);
private:
	Uzol *aDalsi;
public:

	int Info(void)
	{
		return aInfo;
	}

	Uzol * Dalsi(void)
	{
		return aDalsi;
	}
};

