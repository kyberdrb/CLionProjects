#include <stdlib.h>
#include "Uzol.h"


Uzol::Uzol(int pInfo,Uzol *pDalsi)
{
	aInfo = pInfo;
	aDalsi = pDalsi;
}


Uzol::~Uzol(void)
{
}
