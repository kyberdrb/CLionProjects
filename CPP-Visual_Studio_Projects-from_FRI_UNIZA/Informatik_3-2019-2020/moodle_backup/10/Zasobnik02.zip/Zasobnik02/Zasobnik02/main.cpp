#include <iostream>
#include "Zasobnik.h"
#include "TZasobnik.h"
#include "Student.h"

using namespace std;

int main()
{
	try
	{
		TZasobnik<Student> z;
		z.Push(Student("x","y","z"));
		z.Push(Student("a","b","c"));
		z.Push(Student("Rene","Novak","ZU"));
		TZasobnik<double> zx;
		//int x;
		//for(int i=0;i<5;i++)
		//	x = z.Pop();
	}
	catch(exception ex)
	{
		cout << ex.what() << endl;
	}
	return 0;
}