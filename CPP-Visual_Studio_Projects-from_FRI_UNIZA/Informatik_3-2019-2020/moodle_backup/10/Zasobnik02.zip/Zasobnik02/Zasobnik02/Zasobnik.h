#pragma once
#include <exception>
#include <stdlib.h>
#include "Uzol.h"

using namespace std;

class Zasobnik
{
private:
	Uzol *aSP;

	void copy(Uzol *uzol, const Zasobnik &zdroj)
	{
		if(uzol->dalsi())
			copy(uzol->dalsi(),zdroj);
		Push(uzol->info());
	}
public:
	Zasobnik(void)
		: aSP(NULL)
	{

	}

	Zasobnik(const Zasobnik &zdroj)
		: aSP(NULL)
	{
		if(zdroj.aSP)
			copy(zdroj.aSP, zdroj);
	}

	~Zasobnik(void)
	{
		while(aSP)
			Pop();
	}

	void Push(int info)
	{
		aSP = new Uzol(info, aSP);
	}

	int Pop()
	{
		if(aSP)
		{
			int info = aSP->info();
			Uzol *pom = aSP->dalsi();
			delete aSP;
			aSP = pom;
			return info;
		}
		throw exception("Prazdny zasobnik");
	}

	int Peek()
	{
		if(aSP)
		{
			return aSP->info();
		}
		throw exception("Prazdny zasobnik");
	}
};

