#pragma once
class Uzol
{
private:
	int aInfo;
	Uzol *aDalsi;
public:

	Uzol(int pinfo, Uzol *pdalsi)
		:
		aInfo(pinfo), aDalsi(pdalsi)
	{
	}

	int info() { return aInfo; }
	Uzol *dalsi() { return aDalsi; }
};

