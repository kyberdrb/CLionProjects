#pragma once
#include <exception>
#include <stdlib.h>
#include "TUzol.h"

using namespace std;

template <class T>
class TZasobnik
{
private:
	TUzol<T> *aSP;

	void copy(TUzol<T> *uzol, const TZasobnik &zdroj)
	{
		if(uzol->dalsi())
			copy(uzol->dalsi(),zdroj);
		Push(uzol->info());
	}
public:
	TZasobnik(void)
		: aSP(NULL)
	{

	}

	TZasobnik(const TZasobnik &zdroj)
		: aSP(NULL)
	{
		if(zdroj.aSP)
			copy(zdroj.aSP, zdroj);
	}

	~TZasobnik(void)
	{
		while(aSP)
			Pop();
	}

	void Push(T info)
	{
		aSP = new TUzol<T>(info, aSP);
	}

	T Pop()
	{
		if(aSP)
		{
			T info = aSP->info();
			TUzol<T> *pom = aSP->dalsi();
			delete aSP;
			aSP = pom;
			return info;
		}
		throw exception("Prazdny TZasobnik");
	}

	T Peek()
	{
		if(aSP)
		{
			return aSP->info();
		}
		throw exception("Prazdny TZasobnik");
	}
};

