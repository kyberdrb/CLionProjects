#pragma once
#include <string>

using namespace std;
class Student
{
private:
	string aMeno;
	string aPriezvisko;
	string aSkola;
public:

	//Student(const char *pmeno, const char *ppriezvisko, const char *pskola)
	//	: aMeno(pmeno), aPriezvisko(ppriezvisko), aSkola(pskola)
	//{
	//}

	Student(const string pmeno, const string ppriezvisko, const string pskola)
		: aMeno(pmeno), aPriezvisko(ppriezvisko), aSkola(pskola)
	{
	}

	~Student(void)
	{
	}
};

