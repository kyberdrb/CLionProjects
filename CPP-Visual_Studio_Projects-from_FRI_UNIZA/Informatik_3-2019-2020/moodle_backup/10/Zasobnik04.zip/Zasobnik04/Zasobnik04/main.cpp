#include <iostream>

#include "Student.h"

#include "TZasobnik.h"

using namespace std;

int main()
{
	try
	{
		TZasobnik<Student *> z;
		Student a("a","b");
		Student x("x","y");
		Student m("m","n");
		z.push(&a);
		z.push(&x);
		z.push(&m);
		//TZasobnik<int> z2(z);
		for(int i = 0;i<3;i++)
			z.pop();
	}
	catch(exception &ex)
	{
		cout << ex.what() << endl;
	}
	return 0;
}