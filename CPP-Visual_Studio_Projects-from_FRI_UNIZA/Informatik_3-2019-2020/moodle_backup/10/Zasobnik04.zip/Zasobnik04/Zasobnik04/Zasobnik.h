#pragma once
#include <stdlib.h>
#include <exception>

#include "Uzol.h"

using namespace std;

class Zasobnik
{
private:
	Uzol *aSP;

	void copy(Uzol *p)
	{
		if(p->dalsi())
			copy(p->dalsi());
		push(p->info());
	}

public:
	Zasobnik(void) : aSP(NULL)
	{
	}

	Zasobnik(const Zasobnik &src) : aSP(NULL)
	{
		if(src.aSP)
			copy(src.aSP);
	}

	~Zasobnik(void)
	{
		while(aSP)
			pop();
	}

	void push(int info)
	{
		aSP = new Uzol(info, aSP);
	}

	int pop()
	{
		if(aSP)
		{
			int info = aSP->info();
			//Uzol *puzol = aSP->dalsi();
			//delete aSP;
			//aSP = puzol;
			aSP = aSP->zmaz();
			return info;
		}
		throw exception("Prazdny zasobnik!");
	}

	int peek()
	{
		if(aSP)
		{
			return aSP->info();
		}
		throw exception("Prazdny zasobnik!");
	}
};

