#pragma once

template <class T>
class TUzol
{
private:
	T aInfo;
	TUzol *aDalsi;
public:
	TUzol(T pinfo, TUzol *pdalsi)
		: aInfo(pinfo), aDalsi(pdalsi)
	{
	}

	T info() { return aInfo; }
	TUzol *dalsi() { return aDalsi; }
	TUzol *zmaz()
	{
		TUzol *puzol = dalsi();
		delete this;
		return puzol;
	}
};