#pragma once
#include <stdlib.h>
#include <exception>

#include "TUzol.h"

using namespace std;

template <class T>
class TZasobnik
{
private:
	TUzol<T> *aSP;

	void copy(TUzol<T> *p)
	{
		if(p->dalsi())
			copy(p->dalsi());
		push(p->info());
	}

public:
	TZasobnik(void) : aSP(NULL)
	{
	}

	TZasobnik(const TZasobnik &src) : aSP(NULL)
	{
		if(src.aSP)
			copy(src.aSP);
	}

	~TZasobnik(void)
	{
		while(aSP)
			pop();
	}

	void push(T info)
	{
		aSP = new TUzol<T>(info, aSP);
	}

	T pop()
	{
		if(aSP)
		{
			T info = aSP->info();
			//TUzol *puzol = aSP->dalsi();
			//delete aSP;
			//aSP = puzol;
			aSP = aSP->zmaz();
			return info;
		}
		throw exception("Prazdny zasobnik!");
	}

	int peek()
	{
		if(aSP)
		{
			return aSP->info();
		}
		throw exception("Prazdny zasobnik!");
	}
};

