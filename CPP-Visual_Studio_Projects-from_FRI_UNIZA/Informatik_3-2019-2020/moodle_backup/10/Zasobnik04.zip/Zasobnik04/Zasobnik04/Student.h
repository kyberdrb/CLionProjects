#pragma once
#include <string>
using namespace std;

class Student
{
private:
	string aMeno;
	string aPriezvisko;
public:

	Student(const char *meno, const char *priezvisko)
		:aMeno(meno), aPriezvisko(priezvisko)
	{
	}
};

