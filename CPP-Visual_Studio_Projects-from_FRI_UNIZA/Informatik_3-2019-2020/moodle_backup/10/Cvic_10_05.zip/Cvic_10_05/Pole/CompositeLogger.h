#pragma once
#include "ILogger.h"
#include "StreamLogger.h"

class CompositeLogger :	public ILogger
{
private:
	StreamLogger *sLogger;
	StreamLogger *cLogger;
public:
	CompositeLogger();
	~CompositeLogger();

	// Inherited via ILogger
	virtual void log(eLogLevel level, const char * oznam) override;
};

