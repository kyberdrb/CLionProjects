#include "CompositeLogger.h"

CompositeLogger::CompositeLogger()
	: sLogger(new StreamLogger("c:\\temp\\klient.log")),
	  cLogger(new StreamLogger(""))
{
}


CompositeLogger::~CompositeLogger()
{
	delete sLogger;
	delete cLogger;
}

void CompositeLogger::log(eLogLevel level, const char * oznam)
{
	sLogger->log(level, oznam);
	cLogger->log(level, oznam);
}
