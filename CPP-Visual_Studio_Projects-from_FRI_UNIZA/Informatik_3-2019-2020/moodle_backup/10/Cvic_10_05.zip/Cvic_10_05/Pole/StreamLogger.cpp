#include <ctime>
#include <iostream>
#include "StreamLogger.h"

void StreamLogger::writelog(const char * level, const char * oznam)
{
	time_t cas(time(nullptr));
	char *scas = ctime(&cas);
	scas[strlen(scas) - 1] = '\0';
	if (aFLog)
		*aFLog << level << " [" << scas << "]: " << oznam << endl;
	else
		cout << level << " [" << scas << "]: " << oznam << endl;
}

StreamLogger::StreamLogger(const char * menosuboru)
	: aFLog(menosuboru && *menosuboru ?
		new ofstream(menosuboru, ios_base::app | ios_base::out) : nullptr)
{
}

StreamLogger::~StreamLogger()
{
	delete aFLog;
}

void StreamLogger::log(eLogLevel level, const char * oznam)
{
	switch (level)
	{
	case INFO:
		writelog("INFO   ", oznam);
		break;
	case WARNING:
		writelog("WARNING", oznam);
		break;
	case ERROR:
		writelog("  ERROR", oznam);
		break;
#ifdef _DEBUG
	case DEBUG:
		writelog("DEBUG  ", oznam);
		break;
#endif
	}
}
