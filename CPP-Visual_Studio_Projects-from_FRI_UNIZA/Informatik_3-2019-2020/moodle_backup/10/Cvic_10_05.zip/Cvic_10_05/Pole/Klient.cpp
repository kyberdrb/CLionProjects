#include "Klient.h"
#include "ILogger.h"

Klient::Klient()
	:aDolnyIndex(-100), aHornyIndex(50),
	aPole(new Pole<double>(-5, 8, 1.0))
{
	bool opakuj(true);
	do {
		try
		{
			aLog->log(DEBUG, "Priradenie hodnoty 20 do -5.prvku pola");
			(*aPole)[-5] = 20.0;
			aLog->log(DEBUG, "Priradenie hodnoty prvku pola s najnizsim indexom do prvku pola s navyssim indexom");
			(*aPole)[aHornyIndex] = (*aPole)[aDolnyIndex];
			aLog->log(DEBUG, "Vypis pola");
			aPole->vypis();
			opakuj = false;
		}
		catch (VynimkaDolnyIndex &ex)
		{
			aLog->log(ERROR, ex.oznam().c_str());
			aDolnyIndex = ex.index();
		}
		catch (VynimkaHornyIndex &ex)
		{
			aLog->log(ERROR, ex.oznam().c_str());
			aHornyIndex = ex.index();
		}
		catch (VynimkaIndex &ex)
		{
			aLog->log(ERROR, ex.oznam().c_str());
		}
	} while (opakuj);
}


Klient::~Klient()
{
}
