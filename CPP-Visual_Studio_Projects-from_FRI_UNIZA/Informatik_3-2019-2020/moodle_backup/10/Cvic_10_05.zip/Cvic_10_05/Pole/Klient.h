#pragma once
#include "Pole.h"

class Klient
{
private:
	int aDolnyIndex;
	int aHornyIndex;
	Pole<double> *aPole;
public:
	Klient();
	~Klient();
};

