#include "Klient.h"
#include "CompositeLogger.h"

ILogger *aLog;

int main()
{
	aLog = new CompositeLogger();
	//aLog = new StreamLogger("c:\\temp\\klient.log");
	try
	{
		aLog->log(INFO, "Start programu ...");
		Klient klient;
		aLog->log(INFO, "KONIEC PROGRAMU.");
	}
	catch (...)
	{
		aLog->log(ERROR, "NEZNAMA CHYBA");
	}
	return 0;
}