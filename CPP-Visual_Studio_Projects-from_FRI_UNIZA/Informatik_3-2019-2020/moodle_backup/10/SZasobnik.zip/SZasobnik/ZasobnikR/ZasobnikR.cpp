#include <stdlib.h>

#include "ZasobnikR.h"


ZasobnikR::ZasobnikR(void) : aSP(NULL)
{
}


ZasobnikR::~ZasobnikR(void)
{
}


ZasobnikR::ZasobnikR(const ZasobnikR &src)
{
}

Uzol *Prezri(Uzol *uzol)
{
	Uzol *puzol;
	puzol = uzol;
	if(uzol!=NULL) {
		Prezri(uzol->Dalsi());
	}
	return puzol;
}

void ZasobnikR::Push(int info)
{
	aSP = new Uzol(info, aSP);
}

int  ZasobnikR::Pop()
{
	int ret=0xfffffffff;
	Uzol *pomuzol;
	if(aSP !=NULL) {
		ret = aSP->Info();
		pomuzol = aSP->Dalsi();
		delete aSP;
		aSP = pomuzol;
	}
	return ret;
}

int ZasobnikR::Peek()
{
	if(aSP!=NULL)
		return aSP->Info();
	return 0xfffffffff;
}
