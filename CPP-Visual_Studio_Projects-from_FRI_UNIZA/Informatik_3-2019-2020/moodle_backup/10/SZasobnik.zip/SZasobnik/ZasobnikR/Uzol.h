#pragma once
class Uzol
{
private:
	int aInfo;
	Uzol *aDalsi;

public:
	Uzol(int pInfo, Uzol *pDalsi);
	~Uzol(void);

	int Info() { return aInfo; }
	void Info(int src) { aInfo = src; }
	Uzol *Dalsi() { return aDalsi; }
};

