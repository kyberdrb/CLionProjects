#include <stdio.h>
#include "ZasobnikR.h"

void main(void)
{
	ZasobnikR zasobnik;
	for(int i= 0;i<10;i++)
		zasobnik.Push((i+1)*10);
	printf("%d\n",zasobnik.Peek());
	for(int i= 0;i<12;i++)
		printf("%d\n",zasobnik.Pop());
}