#pragma once
#include "Uzol.h"

class ZasobnikR
{
private:
	Uzol *aSP;
	Uzol *Prezri(Uzol *uzol);
public:
	ZasobnikR(void);
	ZasobnikR(const ZasobnikR &src);
	~ZasobnikR(void);

	void Push(int info);
	int  Pop();
	int Peek();
};

