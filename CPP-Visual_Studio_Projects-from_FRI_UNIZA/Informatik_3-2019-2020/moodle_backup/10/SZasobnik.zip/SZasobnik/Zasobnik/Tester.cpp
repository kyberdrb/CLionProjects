#include <iostream>

#include "Tester.h"
#include "Student.h"

using namespace std;

bool Tester::TestujPush()
{
	//Zasobnik<int> z2;

	//z2 = aZasobnik;
	//for(int i=0; i<15; i++)
	//	aZasobnik.Push(i+1);
	//z2.Vypis(cout);

	//Zasobnik<Student> zs;
	Student s1("x", "y", "Z"),
			s2("a", "b", "C");
	//zs.Push(s1);
	//zs.Push(s2);

	//zs.Vypis(cout);

	Zasobnik<Student *> zsp;
	Student *ps1 = new Student("xp", "yp", "ZP"),
			*ps2= new Student("ap", "bp", "CP");
	
	zsp.Push(&s1);
	zsp.Push(&s2);
	zsp.Push(ps1);
	zsp.Push(ps2);
	zsp.Vypis(cout);
	return true;
}

bool Tester::TestujPop()
{
	int x;
	char buf[20];
	for(int i=0; i<10; i++) {
		x = aZasobnik.Pop();
		sprintf(buf,"%d",x);
		z->Zobraz(buf);
	}
	return true;
}

bool Tester::TestujPeek()
{
	char buf[20];

	int x(aZasobnik.Peek());

	sprintf(buf,"%d",x);
	z->Zobraz(buf);

	return true;
}

bool Tester::Run()
{
	return TestujPush() && TestujPeek() && TestujPop();
}

