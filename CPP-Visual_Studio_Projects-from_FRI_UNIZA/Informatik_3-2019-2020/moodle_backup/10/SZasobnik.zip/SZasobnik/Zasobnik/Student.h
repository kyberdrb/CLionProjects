#pragma		once
#include <iostream>
#include <string.h>
#include "DeletableObject.h"

using namespace std;

class Student : public DeletableObject
{
private:
	char aMeno[101];
	char aPriezvisko[101];
	char aSkola[201];
public:

	Student(const char *meno=NULL,const char *priezvisko=NULL,const char *skola=NULL)
	{
		Meno(meno);
		Priezvisko(priezvisko);
		Skola(skola);
	}

	~Student(void)
	{
	}

	const char *Meno() const { return aMeno; }
	const char *Priezvisko() const { return aPriezvisko; }
	const char *Skola() const { return aSkola; };
	void Meno(const char *meno) { 
		memset(aMeno,0,sizeof(aMeno));
		if(meno)
			strcpy(aMeno, meno); 
	}
	void Priezvisko(const char *priezvisko) { 
		memset(aPriezvisko,0,sizeof(aPriezvisko));
		if(priezvisko)
			strcpy(aPriezvisko,priezvisko); 
	}
	void Skola(const char *skola) { 
		memset(aSkola,0,sizeof(aSkola));
		if(skola)
		  strcpy(aSkola,skola); 
	}
	friend ostream &operator<<(ostream &os, Student &z) {
		  os<< "Meno: " << z.aMeno << endl << "Priezvisko: " <<z.aPriezvisko << endl << "Skola: "<< z.aSkola <<endl;
		  return os;
	}
	friend ostream &operator<<(ostream &os, Student *z) {
		  os << *z;
		  return os;
	}

	void Vypis(ostream &os) 
	{
		os <<this;
	};
};

