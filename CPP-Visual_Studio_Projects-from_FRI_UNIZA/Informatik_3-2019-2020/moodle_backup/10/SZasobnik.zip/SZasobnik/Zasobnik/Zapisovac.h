#pragma once
#include <stdio.h>

class Zapisovac
{
private:
	FILE *fHandle;
public:
	Zapisovac(const char *menosuboru);
	~Zapisovac(void);
	void Zobraz(char *info);
};

