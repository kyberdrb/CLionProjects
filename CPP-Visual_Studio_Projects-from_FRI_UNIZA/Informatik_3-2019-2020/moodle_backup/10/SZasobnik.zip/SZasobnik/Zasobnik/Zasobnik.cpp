#include <stdlib.h>
#include <string.h>

#include "Zasobnik.h"


Zasobnik::Zasobnik(int pFrameSize) : aFrameSize(pFrameSize != 0 ? pFrameSize : 10), aSP(0)
{
	//if(pFrameSize != 0)
	//	aFrameSize = pFrameSize;
	//else
	//	aFrameSize = 10;

	aData = new int[aFrameSize];
}

//Zasobnik::Zasobnik(const Zasobnik &src) : aFrameSize(src.aFrameSize), aSP(src.aSP),
//	aData(new int[(src.aSP % src.aFrameSize+1) * src.aFrameSize])
//{
//	memmove(aData,src.aData, src.aSP*sizeof(int));
//}


Zasobnik::Zasobnik(const Zasobnik &src) 
{
	Alloc(src);
}

Zasobnik &Zasobnik::operator =(const Zasobnik &src)
{
	if(this != &src)
	{
		delete[] aData;
		Alloc(src);
		//aFrameSize=src.aFrameSize;
		//aSP = src.aSP;
		//aData = new int[(src.aSP % src.aFrameSize+1) * src.aFrameSize];
		//memmove(aData,src.aData, src.aSP*sizeof(int));
	}
	return *this;
}

void Zasobnik::Alloc(const Zasobnik &src)
{
	aFrameSize=src.aFrameSize;
	aSP = src.aSP;
	aData = new int[(src.aSP % src.aFrameSize+1) * src.aFrameSize];
	memmove(aData,src.aData, src.aSP*sizeof(int));
}

Zasobnik::~Zasobnik(void)
{
	if(aData!=NULL) 
		delete[] aData;
}

void Zasobnik::Realokuj(int size)
{
	int *pomdata(new int[size]);
	memmove(pomdata,aData, aSP * sizeof(int));
	delete[] aData;
	aData = pomdata;
}

void Zasobnik::Push(int info)
{
	if(aSP!=0 && (aSP%aFrameSize)==0) 
		Realokuj(aSP+aFrameSize);
	aData[aSP++] = info;
}

int  Zasobnik::Pop()
{
	if(aSP>0 && (aSP%aFrameSize)==0) 
		Realokuj(aSP);
	return aSP > 0 ? aData[--aSP] : 0xffffffff;
}

int Zasobnik::Peek()
{
	return aSP > 0 ? aData[aSP-1] : 0xffffffff;
}
