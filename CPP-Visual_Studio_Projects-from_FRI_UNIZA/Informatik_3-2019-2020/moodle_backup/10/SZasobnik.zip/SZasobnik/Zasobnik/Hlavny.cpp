#include "stdio.h"

#define TESTY

#ifdef TESTY
#include "Tester.h"
#endif

void main()
{
	bool testyok = true;
#ifdef TESTY
	Tester testy;
	testyok = testy.Run();
#endif
	if(testyok==true)
		;  // Normalna cinnost programu
	else
		puts("Nepresli testy!");
}