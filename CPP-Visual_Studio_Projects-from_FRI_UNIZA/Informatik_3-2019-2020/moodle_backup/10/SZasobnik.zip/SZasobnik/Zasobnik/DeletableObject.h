#pragma once
#include <stdlib.h>
#include <ostream>
#include "Zasobnik.h"

using namespace std;

class DeletableObject
{
private:
	static bool IdemCezNew;
	
protected:
	bool somZHaldy;
public:

	DeletableObject(void) : somZHaldy(IdemCezNew)
	{
		IdemCezNew=false;
	}

	~DeletableObject(void)
	{
	}

	void *operator new(size_t size) {
		DeletableObject::IdemCezNew = true;
		return malloc(size);
	}

	void *operator new(size_t size,int pocet) {
		DeletableObject::IdemCezNew = true;
		return malloc(size*pocet);
	}

	void operator delete(void *objekt)
	{
		DeletableObject *ob = (DeletableObject *)objekt;
		if(ob->somZHaldy)
		  free(objekt);
	}

	void operator delete(void *objekt, int pocet)
	{
		free(objekt);
	}

	friend ostream &operator<<(ostream &os, DeletableObject &z) 
	{
		  z.Vypis(os);
		  return os;
	}
	virtual void Vypis(ostream &os) {};
};

//class DDZAsobnikk : public Zasobnik<DeletableObject *> {
//};

