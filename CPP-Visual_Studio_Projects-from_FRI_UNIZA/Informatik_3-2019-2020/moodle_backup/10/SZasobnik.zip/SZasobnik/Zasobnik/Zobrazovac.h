#pragma once
#include <stdio.h>

class Zobrazovac
{
public:
	void Zobraz(char *info)
	{
		if(info != NULL)
			puts(info);
	}
};

