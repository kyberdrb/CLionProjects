#pragma once
#include <exception>
#include <ostream>
#include <string.h>

using namespace std;

template <class T>
class Zasobnik
{
private:
	T *aData;
	int aSP;
	int aFrameSize;
	void Realokuj(int size);
	void Alloc(const Zasobnik &src);
public:
	Zasobnik(int pFrameSize = 10);
	~Zasobnik(void);
	Zasobnik(const Zasobnik &src);
	Zasobnik &operator =(const Zasobnik &src);
	void Push(T info);
	T  Pop();
	T Peek();
	//friend ostream &operator<<(ostream &os, Zasobnik<T> &z);
	void Vypis(ostream &os);
};

template <class T>
Zasobnik<T>::Zasobnik(int pFrameSize) : aFrameSize(pFrameSize != 0 ? pFrameSize : 10), aSP(0)
{
	aData = new T[aFrameSize];
}

template <class T>
Zasobnik<T>::Zasobnik(const Zasobnik &src) 
{
	Alloc(src);
}

template <class T>
Zasobnik<T> &Zasobnik<T>::operator =(const Zasobnik<T> &src)
{
	if(this != &src)
	{
		delete[] aData;
		aData = NULL;
		Alloc(src);
	}
	return *this;
}

template <class T>
void Zasobnik<T>::Alloc(const Zasobnik &src)
{
	aFrameSize=src.aFrameSize;
	aSP = src.aSP;
	aData = new T[(src.aSP % src.aFrameSize+1) * src.aFrameSize];
	memmove(aData,src.aData, src.aSP*sizeof(T));
}

template <class T>
Zasobnik<T>::~Zasobnik(void)
{
	if(aData!=NULL) 
		delete[] aData;
}

template <class T>
void Zasobnik<T>::Realokuj(int size)
{
	T *pomdata(new T[size]);
	memmove(pomdata,aData, aSP * sizeof(T));
	delete[] aData;
	aData = pomdata;
}

template <class T>
void Zasobnik<T>::Push(T info)
{
	if(aSP!=0 && (aSP%aFrameSize)==0) 
		Realokuj(aSP+aFrameSize);
	aData[aSP++] = info;
}

template <class T>
T Zasobnik<T>::Pop()
{
	if(aSP>0 && (aSP%aFrameSize)==0) 
		Realokuj(aSP);
	if(aSP > 0)
		return aData[--aSP];
	throw exception("Zasobnik je prazdny");
}

template <class T>
T Zasobnik<T>::Peek()
{
	if(aSP > 0)
 	  return aData[aSP-1];
	throw exception("Zasobnik je prazdny");
}

template <class T>
ostream &operator<<(ostream &os, Zasobnik<T> &z)
{
	for(int i=0;i<z.aSP;i++) {
		os << z.aData[i] << endl;
	}
	return os;
}

template <class T>
void Zasobnik<T>::Vypis(ostream &os)
{
	for(int i=0;i<aSP;i++) {
		os << aData[i] << endl;
	}
}
