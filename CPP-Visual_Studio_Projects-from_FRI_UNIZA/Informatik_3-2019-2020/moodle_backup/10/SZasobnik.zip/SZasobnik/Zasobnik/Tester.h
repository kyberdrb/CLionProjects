#pragma once
#include "Zasobnik.h"
#include "Zobrazovac.h"
#include "Zapisovac.h"

#define KONZOLA

class Tester
{
private:
	Zasobnik<int> aZasobnik;
#ifdef KONZOLA
	Zobrazovac *z;
#else
	Zapisovac *z;
#endif

	bool TestujPush();
	bool TestujPop();
	bool TestujPeek();
public:
	bool Run();
	Tester()
	{
#ifdef KONZOLA
		z =  new Zobrazovac();
#else
		z = new Zapisovac("c:\\student\\cpp\\zasobnik.txt");
#endif
	}
};

