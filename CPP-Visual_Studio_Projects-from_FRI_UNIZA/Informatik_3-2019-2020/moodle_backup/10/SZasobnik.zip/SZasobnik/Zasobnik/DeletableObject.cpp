#include "DeletableObject.h"

bool DeletableObject::IdemCezNew = false;