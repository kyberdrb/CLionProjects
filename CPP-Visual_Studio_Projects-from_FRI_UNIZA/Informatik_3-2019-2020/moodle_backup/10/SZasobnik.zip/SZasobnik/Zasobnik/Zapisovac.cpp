#include "Zapisovac.h"


Zapisovac::Zapisovac(const char *menosuboru)
{
	fHandle = fopen(menosuboru,"wt");
}


Zapisovac::~Zapisovac(void)
{
	if(fHandle!=NULL)
		fclose(fHandle);
}

void Zapisovac::Zobraz(char *info)
{
	if(info!=NULL && fHandle!=NULL)
		fputs(info, fHandle); 
	fputs("\n",fHandle);
}

