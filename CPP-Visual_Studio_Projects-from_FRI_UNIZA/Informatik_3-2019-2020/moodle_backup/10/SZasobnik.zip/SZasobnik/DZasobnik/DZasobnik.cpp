#include "DZasobnik.h"



Zasobnik::Zasobnik(int pFrameSize) : aFrameSize(pFrameSize != 0 ? pFrameSize : 10), aSP(0)
{
	aData = new DeletableObject  *[aFrameSize];
}


Zasobnik::Zasobnik(const Zasobnik &src) 
{
	Alloc(src);
}


Zasobnik &Zasobnik::operator =(const Zasobnik &src)
{
	if(this != &src)
	{
		delete[] aData;
		aData = NULL;
		Alloc(src);
	}
	return *this;
}


void Zasobnik::Alloc(const Zasobnik &src)
{
	aFrameSize=src.aFrameSize;
	aSP = src.aSP;
	aData = new DeletableObject  *[(src.aSP % src.aFrameSize+1) * src.aFrameSize];
	memmove(aData,src.aData, src.aSP*sizeof(DeletableObject  *));
}


Zasobnik::~Zasobnik(void)
{
	for(int i=0;i<aSP;i++) 
		delete aData[i];
	if(aData!=NULL) 
		delete[] aData;
}


void Zasobnik::Realokuj(int size)
{
	DeletableObject **pomdata = new DeletableObject  *[size];
	memmove(pomdata,aData, aSP * sizeof(DeletableObject  *));
	delete[] aData;
	aData = pomdata;
}


void Zasobnik::Push(DeletableObject  * info)
{
	if(aSP!=0 && (aSP%aFrameSize)==0) 
		Realokuj(aSP+aFrameSize);
	aData[aSP++] = info;
}


DeletableObject  * Zasobnik::Pop()
{
	if(aSP>0 && (aSP%aFrameSize)==0) 
		Realokuj(aSP);
	if(aSP > 0)
		return aData[--aSP];
	throw exception("Zasobnik je prazdny");
}


DeletableObject  * Zasobnik::Peek()
{
	if(aSP > 0)
 	  return aData[aSP-1];
	throw exception("Zasobnik je prazdny");
}


void Zasobnik::Vypis(ostream &os)
{
	for(int i=0;i<aSP;i++) {
		os << *aData[i] << endl;
	}
}
