#pragma once
#pragma once
#include <exception>
#include <ostream>
#include <string.h>
#include "DeletableObject.h"

using namespace std;

class Zasobnik
{
private:
	DeletableObject **aData;
	int aSP;
	int aFrameSize;
	void Realokuj(int size);
	void Alloc(const Zasobnik &src);
public:
	Zasobnik(int pFrameSize = 10);
	~Zasobnik(void);
	Zasobnik(const Zasobnik &src);
	Zasobnik &operator =(const Zasobnik &src);
	void Push(DeletableObject *info);
	DeletableObject *Pop();
	DeletableObject *Peek();
	//friend ostream &operator<<(ostream &os, Zasobnik<DeletableObject *> &z);
	void Vypis(ostream &os);
};
