#include <iostream>
#include "Student.h"
#include "DZasobnik.h"

using namespace std;

void main()
{
	Student s1("x", "y", "Z"),
			s2("a", "b", "C");
	Zasobnik zsp;
	Student *ps1 = new Student("xp", "yp", "ZP"),
			*ps2= new Student("ap", "bp", "CP");
	
	zsp.Push(&s1);
	zsp.Push(&s2);
	zsp.Push(ps1);
	zsp.Push(ps2);
	zsp.Vypis(cout);

}