#pragma once

#include <exception>

class Stack
{
private:
	int * aData;
	int aIdxTop;
	unsigned aCapacity;
public:
	Stack(unsigned capacity = 10)
	{
		aIdxTop = -1;
		aCapacity = capacity;
		aData = new int[aCapacity];
	}

	~Stack(void)
	{
		delete [] aData;
	}

	void push(int element);

	int pop()
	{
		int tempData = top();
		aIdxTop--;
		return tempData;
	}

	int top() const
	{
		if (!isEmpty())
			return aData[aIdxTop];

		throw std::exception("Stack is empty.");
	}

	// Pocet prvkov
	int size() { return aIdxTop + 1; }

	// Urcuje, ci je zasobnik prazdny
	bool isEmpty() const { return aIdxTop == -1; }
};
