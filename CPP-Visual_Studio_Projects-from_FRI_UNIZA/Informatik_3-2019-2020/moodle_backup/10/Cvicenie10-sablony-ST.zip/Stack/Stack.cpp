#include "Stack.h"

void Stack::push(int element)
{
	if (aCapacity == aIdxTop + 1)
	{
		aCapacity *= 2;	
		int * tempData = new int[aCapacity];
		for (int i = 0; i <= aIdxTop; i++)
		{
			tempData[i] = aData[i];
		}
		delete [] aData;
		aData = tempData;
	}

	aData[++aIdxTop] = element;
}