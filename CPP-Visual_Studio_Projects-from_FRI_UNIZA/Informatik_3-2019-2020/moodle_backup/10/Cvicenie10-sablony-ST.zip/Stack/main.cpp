#include <stack>
#include <iostream>
using namespace std;
//#include "Stack.h"
#include "TemplateStack.h"

int main()
{
	//stack<int> myStack;

	Stack<double> myStack; 
	try
	{
		myStack.push(10);
		myStack.push(20);
		cout << myStack.pop() << endl;
		cout << myStack.pop() << endl;
		cout << myStack.top() << endl; // vyhodi vynimku
	}
	catch(exception & e)
	{
		cout << "Exception: " << e.what() << endl;
	}
}
	