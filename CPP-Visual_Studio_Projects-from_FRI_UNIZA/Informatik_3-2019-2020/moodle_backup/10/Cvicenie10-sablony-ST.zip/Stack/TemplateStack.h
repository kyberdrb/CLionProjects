#pragma once

#include <exception>

template <class T>
class Stack
{
private:
	// Pole prvkov reprezentujuce zasobnik.
	T * aData;
	
	// Vrchol zasobnika - index (pozicia) v poli prvkov.
	int aIdxTop;
	
	// Kapacita - velkost vyalokovaneho pola.
	unsigned aCapacity;
public:
	// Konstruktor.
	Stack(unsigned capacity = 10)
	{
		aIdxTop = -1;
		aCapacity = capacity;
		aData = new T[aCapacity];
	}

	// Destruktor.
	~Stack(void)
	{
		delete [] aData;
	}


	// Vlozi prvok do zasobnika.
	void push(T element)
	{
		if (aCapacity == aIdxTop + 1)
		{
			aCapacity *= 2;	
			T * tempData = new T[aCapacity];
			for (int i = 0; i <= aIdxTop; i++)
			{
				tempData[i] = aData[i];
			}
			delete [] aData;
			aData = tempData;
		}

		aData[++aIdxTop] = element;
	}

	// Vyberie a vrati prvok z vrcholu zasobnika. Ak je prazdny, vyhodi vynimku.
	T pop()
	{
		T tempData = top();
		aIdxTop--;
		return tempData;
	}

	// Vrati prvok z vrcholu zasobnika. Ak je prazdny, vyhodi vynimku.
	T top() const
	{
		if (!isEmpty())
			return aData[aIdxTop];

		throw std::exception("Stack is empty.");
	}

	// Pocet prvkov.
	int size() { return aIdxTop + 1; }

	// Urcuje, ci je zasobnik prazdny.
	bool isEmpty() const { return aIdxTop == -1; }
};

