#ifdef TEST
#include "Test.h"
#endif
int main()
{
	bool ok = true;
#ifdef TEST
	Test testy;
	ok=testy.Run();
#endif
	if(ok)
		;
	return 0;
}
