#pragma once
#include <stdlib.h>
#include <string.h>
#include <ostream>
#include <fstream>

using namespace std;

const int IMPLICIT_SIZE = 10;

template<class T> 
class Zasobnik
{
public:
	Zasobnik(int pFrameSize = IMPLICIT_SIZE);
	Zasobnik(const Zasobnik<T> &src);
	Zasobnik & operator =(const Zasobnik<T> &src);
	~Zasobnik(void);

	void Push(T data);
	T Pop(void);
	T Peek(void);
	void Zapis(const char *menosuboru)
	{
		ofstream ofs(menosuboru);
		Zapis(ofs);
	}
	void Zapis(ostream &os);
private:
	// // Miesto pre data
	T *aData;
	// // Ukazovatel zasobnika
	int aSP;
	int aFrameSize;
	int aSize;
	// // Metoda na realokaciu frame zasobnika
	void Realokuj(int pSize);
	void Copy(const Zasobnik<T> &src);
};

template<class T>
void Zasobnik<T>::Zapis(ostream &os)
{
	for(int i=aSP-1;i>=0;i--) 
		os<<aData[i]<<endl;
}

template<class T>
Zasobnik<T>::Zasobnik(int pFrameSize)
{
	aFrameSize = pFrameSize<=0 ? IMPLICIT_SIZE : pFrameSize;
	aSize = aFrameSize;
	aSP=0;
	aData=new T[aFrameSize];
}

template<class T>
void Zasobnik<T>::Copy(const Zasobnik<T> &src)
{
	aSize = src.aSize;
	aFrameSize = src.aFrameSize;
	aSP = src.aSP;
	aData = new T[aSize];
	memmove(aData,src.aData,aSize*sizeof(T));
}

template<class T>
Zasobnik<T>::Zasobnik(const Zasobnik<T> &src)
{
	Copy(src);
}

template<class T>
Zasobnik<T> & Zasobnik<T>::operator =(const Zasobnik<T> &src)
{
	if(&src != this) {
		delete[] aData;
		Copy(src);
	}
	return *this;
}

template<class T>
Zasobnik<T>::~Zasobnik(void)
{
	delete[] aData;
}

template<class T>
void Zasobnik<T>::Push(T data)
{
	if(aSP>=aSize) {
		Realokuj(aSize+aFrameSize);
		aSize += aFrameSize;
	}
	if(aSP<aSize)
		aData[aSP++] = data;
}

template<class T>
T Zasobnik<T>::Pop(void)
{
	if((aSP%aFrameSize)==0) {
		aSize -= aFrameSize;
		Realokuj(aSize);
	}
	if(aSP>0)
		return aData[--aSP];
	return 0;
}

template<class T>
T Zasobnik<T>::Peek(void)
{
	if(aSP>0)
		return aData[aSP-1];
	return 0;
}

// // Metoda na realokaciu frame zasobnika
template<class T>
void Zasobnik<T>::Realokuj(int pSize)
{
	T *pomdata(new T[pSize]);
	if(pomdata!=NULL) {
		memmove(pomdata, aData, aSize*sizeof(T));
		delete[] aData;
		aData = pomdata;
	}
}
