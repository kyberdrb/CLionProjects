#pragma once

class Test
{
public:
	virtual bool Run();
};
