#pragma once
#include <stdlib.h>
#include <string.h>

class Student
{
private:
	char aMeno[151];
	char aPriezvisko[151];
	char aSkola[251];
public:
	Student(const char *meno=NULL,
		    const char *priezvisko=NULL,
			const char *skola=NULL)
	{
		Meno(meno);
		Priezvisko(priezvisko);
		Skola(skola);
	}

	Student(const Student &src)
	{
		Meno(src.aMeno);
		Priezvisko(src.aPriezvisko);
		Skola(src.aSkola);
	}

	Student & operator =(const Student &src)
	{
		if(this != &src) {
			Meno(src.aMeno);
			Priezvisko(src.aPriezvisko);
			Skola(src.aSkola);
		}
		return *this;
	}
	const char *Meno() const { return aMeno;}
	const char *Priezvisko() const { return aPriezvisko;}
	const char *Skola() const { return aSkola;}
	void Meno(const char *src) {
		if(src!=NULL) {
			strncpy(aMeno,src,sizeof(aMeno));
			aMeno[sizeof(aMeno)-1]=0;
		} else
			memset(aMeno,0,sizeof(aMeno));
	}
	void Priezvisko(const char *src) {
		if(src!=NULL) {
			strncpy(aPriezvisko,src,sizeof(aPriezvisko));
			aPriezvisko[sizeof(aPriezvisko)-1]=0;
		} else
			memset(aPriezvisko,0,sizeof(aPriezvisko));
	};
	void Skola(const char *src){
		if(src!=NULL) {
			strncpy(aSkola,src,sizeof(aSkola));
			aSkola[sizeof(aSkola)-1]=0;
		} else
			memset(aSkola,0,sizeof(aSkola));
	}
	friend ostream &operator <<(ostream &os,Student &s) {
		os<<s.Meno()<<" "<<s.Priezvisko()<<", "<<s.Skola();
		return os;
	}
	friend ostream &operator <<(ostream &os,Student *s) {
		return os<<*s;
		//		return operator <<(os,*s);
	}
};
