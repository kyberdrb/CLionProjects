#include "Test.h"
#include "Zasobnik.h"
#include "Student.h"

#include <iostream>

using namespace std;

bool Test::	Run()
{
	Zasobnik<int> zi;
	for(int i=0;i<15;i++) {
		zi.Push(i+1);
	}
	zi.Zapis("test.txt");
	zi.Zapis(cout);
	Student xy("x","y","z");
	Zasobnik<Student *> zs;
	zs.Push(&xy);
	zs.Zapis(cout);
	Zasobnik<Zasobnik<int> *> zz;
	zz.Push(&zi);
	zz.Push(&zi);
	return true;
}

