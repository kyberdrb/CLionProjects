/*
Vytvorte triedu, ktor� bude predstavova� "nekone�n�" z�sobn�k pre objekt lubovolnej triedy. 
Vytvorte z�kladn� met�dy pre pr�cu so z�sobn�kom

- push - vlo� na vrchol z�sobn�ka
- pop -  vyber z vrchola z�sobn�ka
- peek - pozri na vrchol z�sobn�ka
*/
#ifdef TEST
#include "Test.h"
#endif

int main()
{
#ifdef TEST
	Test testy;
	testy.Run();
#else
#endif
	return 0;
}