#include <iostream>

#include "Test.h"

#include "Zasobnik.h"
#include "Student.h"

using namespace std;


Test::Test(void)
{
}


Test::~Test(void)
{
}

bool Test::Run()
{
	//doplnit testy pre zasobnik instancii triedy Student
	return true;
}
