#pragma once
#include <stdlib.h>
#include <string.h>
#include <ostream>

using namespace std;

// vytvorit zasobnik pouzitelny pre objekt lubovolnej triedy (vyuzite triedne sablony)