#pragma once
#include <string.h>
#include <stdlib.h>
#include <ostream>

using namespace std;

class Student
{
private:
	char aMeno[100];
	char aPriezvisko[100];
	char aSkola[100];
	void Set(const char *meno,const char *priezvisko,const char *skola) {
		Meno(meno);
		Priezvisko(priezvisko);
		Skola(skola);
	};
public:
	Student() { Set(NULL,NULL,NULL); }
	Student(const char *meno,const char *priezvisko,const char *skola)
	{
		Set(meno,priezvisko,skola);
	}

	Student(const Student &src)
	{
		Set(src.aMeno,src.aPriezvisko,src.aSkola);
	}

	Student &operator =(const Student &src)
	{
		if(this != &src) {
		Set(src.aMeno,src.aPriezvisko,src.aSkola);
		}
		return *this;
	}

	~Student(void)
	{
	}

	const char *Meno() { return aMeno; }
	const char *Priezvisko() { return aPriezvisko; }
	const char *Skola() { return aSkola; }
	void Meno(const char *meno) { 
		if(meno!=NULL) {
			strncpy(aMeno,meno,100); 
			aMeno[99]=0;
		} else
			memset(aMeno,0,sizeof(aMeno));
	}
	void Priezvisko(const char *priezvisko) { 
		if(priezvisko!=NULL) {
			strncpy(aPriezvisko,priezvisko,100); 
			aPriezvisko[99]=0;
		} else
			memset(aPriezvisko,0,sizeof(aPriezvisko));
	}
	void Skola(const char *skola) { 
		if(skola!=NULL) {
			strncpy(aSkola,skola,100); 
			aSkola[99]=0;
		} else
			memset(aSkola,0,sizeof(aSkola));
	}
	friend ostream &operator << (ostream &os,Student &obj) {
		os << obj.aMeno << " " << obj.aPriezvisko <<", " << obj.aSkola << flush;
		return os;
	}

	friend ostream &operator << (ostream &os,Student *obj) {
		os<<*obj;
		return os;
		return operator <<(os,*obj);
	}
};

