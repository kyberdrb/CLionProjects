#pragma once
class Test
{
public:
	Test(void);
	~Test(void);
	virtual bool Run();
};

