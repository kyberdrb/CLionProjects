#pragma once
class Test
{
public:
	Test(void);
	~Test(void);
	bool Run(void);
};

