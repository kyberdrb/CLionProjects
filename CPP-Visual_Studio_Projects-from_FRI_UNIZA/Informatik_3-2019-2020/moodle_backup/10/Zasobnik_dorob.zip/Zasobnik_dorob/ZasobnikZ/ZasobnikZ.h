#pragma once
#include "Uzol.h"

class ZasobnikZ
{
private:
	Uzol *aSP;
public:
	ZasobnikZ(void);
	~ZasobnikZ(void);
	void Push(int info);
	int Pop(void);
	int Peek(void);
};

