#include <stdlib.h>

#include "ZasobnikZ.h"


ZasobnikZ::ZasobnikZ(void)
{
	aSP=NULL;
}


ZasobnikZ::~ZasobnikZ(void)
{
}

void ZasobnikZ::Push(int info)
{
	aSP = new Uzol(info,aSP);
}


int ZasobnikZ::Pop(void)
{
	int ret=0;
	Uzol *pomuzol;
	if(aSP!=NULL) {
		ret = aSP->Info();
		pomuzol = aSP->Dalsi();
		delete aSP;
		aSP= pomuzol;
	}
	return ret;
}


int ZasobnikZ::Peek(void)
{
	return 0;
}
