#include <memory>

#include "Zasobnik.h"
#include "Vstup.h"
#include "Vystup.h"
int main()
{
	unique_ptr<Zasobnik> z(new Zasobnik);
	//Zasobnik *z = new Zasobnik;
	z->push(10);
	z->push(20);
	z->push(30);
	z->push(40);
	z->nacitaj(cppvstup::vstup);
	vypis(z->pop());
	vypis("\n");
	return 0;
}