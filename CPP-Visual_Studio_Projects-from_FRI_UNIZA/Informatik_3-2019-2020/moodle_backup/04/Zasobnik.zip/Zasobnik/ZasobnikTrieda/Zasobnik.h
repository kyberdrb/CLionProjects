#pragma once
#include "Vstup.h"

using namespace std;

class InfoBox
{
private:
	InfoBox *dalsi = nullptr;
	int info = 0;
public:
	InfoBox(int info, InfoBox *predch);
	InfoBox();

	int Info() { return info; }
	InfoBox *Dalsi() { return dalsi; }
};

class Zasobnik {
private:
	void vloz(Zasobnik *cielzasobnik, InfoBox *box);
public:
	InfoBox *sp = nullptr;
	int pocet = 0;
	Zasobnik();
	~Zasobnik();
	bool push(int x);
	int pop();
	int peek();
	void copy(Zasobnik *cielzasobnik);
	void nacitaj();
	void nacitaj(VstupPtr fun);
};


