#include <cstdio>
#include <cctype>
#include <iostream>

#include "Vstup.h"
using namespace std;

namespace cvstup
{
	int vstup(const char *oznam)
	{
		int cislo;
		if (oznam != NULL && *oznam != 0)
		{
			char *oz = strdup(oznam);
			strupr(oz);
			printf(oz);
			free(oz);
		}
		scanf("%d", &cislo);
		return cislo;
	}
}

namespace cppvstup
{
	using namespace std;
	int vstup(const char *oznam)
	{
		int cislo;
		if (oznam != NULL && *oznam != 0)
			cout << oznam;
		cin >> cislo;
		return cislo;
	}
}