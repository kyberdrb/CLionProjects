#pragma once

void vypis(const char *text);
void vypis(const int val, bool newline = true);
