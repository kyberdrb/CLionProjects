#include "Zasobnik.h"
#include "Vstup.h"
#include "Vystup.h"

using namespace cppvstup;

InfoBox::InfoBox(int pinfo, InfoBox * predch)
{
	info = pinfo;
	dalsi = predch;
}

InfoBox::InfoBox()
{
	//info = 0;
	//dalsi = nullptr;
}

Zasobnik::Zasobnik()
{
}

Zasobnik::~Zasobnik()
{
	while (sp) {
		int x = pop();
		vypis(x);
	}
}

bool Zasobnik::push(int x)
{
	if (x > 0)
	{
		sp = new InfoBox(x, sp);
		pocet++;
		return true;
	}
	return false;
}

int Zasobnik::pop()
{
	int retval = 0;
	if (sp)
	{
		retval = sp->Info();
		InfoBox *novesp = sp->Dalsi();
		sp = novesp;
		pocet--;
	}
	return retval;
}

int Zasobnik::peek()
{
	if (sp)
		return sp->Info();
	return 0;
}


void Zasobnik::vloz(Zasobnik *cielzasobnik, InfoBox *box)
{
	if (box->Dalsi())
		vloz(cielzasobnik, box->Dalsi());
	cielzasobnik->push(box->Info());
}

void Zasobnik::copy(Zasobnik *cielzasobnik)
{
	if (sp && cielzasobnik)
		vloz(cielzasobnik, sp);
}

void Zasobnik::nacitaj()
{
	char oznam[] = "Zadavaj prirodzene cislo (koniec = 0)\n-------------------------------------\n";
	int cislo = vstup(oznam);
	while (cislo > 0)
	{
		push(cislo);
		cislo = vstup(nullptr);
	}
}

void Zasobnik::nacitaj(VstupPtr VstupFun)
{
	char oznam[] = "Zadavaj prirodzene cislo (koniec = 0)\n-------------------------------------\n";
	if (VstupFun) {
		int cislo = VstupFun(oznam);
		while (cislo > 0)
		{
			push(cislo);
			cislo = VstupFun(nullptr);
		}
	}
}

