#pragma once
#pragma once

typedef int (*VstupPtr)(const char *oznam);

namespace cvstup
{
	int vstup(const char *oznam);
}

namespace cppvstup
{
	int vstup(const char *oznam);
}