#include <iostream>

#include "Vystup.h"
using namespace std;

void vypis(const char *text)
{
	cout << text;
}

void vypis(const int val, bool newline)
{
	cout << val;
	if (newline)
		cout << endl;
}