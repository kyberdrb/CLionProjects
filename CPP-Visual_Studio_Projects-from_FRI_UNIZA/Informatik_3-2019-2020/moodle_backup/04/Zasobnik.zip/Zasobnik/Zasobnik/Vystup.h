#pragma once
#include <cstdio>

void vypis(const char *text);