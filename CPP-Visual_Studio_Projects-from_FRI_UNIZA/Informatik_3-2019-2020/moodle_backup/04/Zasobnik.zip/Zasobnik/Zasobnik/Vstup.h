#pragma once

namespace cvstup
{
	int vstup(const char *oznam);
}

namespace cppvstup
{
	int vstup(const char *oznam);
}