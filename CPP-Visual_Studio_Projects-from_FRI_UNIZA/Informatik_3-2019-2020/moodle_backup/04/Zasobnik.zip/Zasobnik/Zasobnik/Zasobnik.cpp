#include <cstdlib> // len C++11
#include "Vstup.h"
#include "Zasobnik.h"

using namespace cppvstup;

void init(Zasobnik *zasobnik)
{
	if (zasobnik != NULL)
	{
		zasobnik->pocet = 0;
		zasobnik->sp = NULL;
	}
}

bool push(Zasobnik *zasobnik, int x)
{
	if (x > 0)
	{
		zasobnik->sp = new InfoBox(x,zasobnik->sp);
		zasobnik->pocet++;
		return true;
	}
	return false;
}

//bool push(Zasobnik *zasobnik, int x)
//{
//	if (x > 0)
//	{
//		InfoBox *novybox = new InfoBox;
//		novybox->info = x;
//		novybox->dalsi = NULL;
//		if (zasobnik->sp == NULL)
//			zasobnik->sp = novybox;
//		else
//		{
//			novybox->dalsi = zasobnik->sp;
//			zasobnik->sp = novybox;
//		}
//		zasobnik->pocet++;
//		return true;
//	}
//	return false;
//}

int pop(Zasobnik *zasobnik)
{
	int retval = 0;
	if (zasobnik != NULL && zasobnik->sp != NULL)
	{
		retval = zasobnik->sp->info;
		InfoBox *novesp = zasobnik->sp->dalsi;
		delete zasobnik->sp;
		zasobnik->sp = novesp;
		zasobnik->pocet--;
	}
	return retval;
}

int peek(Zasobnik *zasobnik)
{
	if (zasobnik != NULL && zasobnik->sp != NULL)
		return zasobnik->sp->info;
	return 0;
}

void zrus(Zasobnik *zasobnik)
{
	if (zasobnik != NULL)
	{
		while (zasobnik->sp)
			pop(zasobnik);
	}
}

void vloz(Zasobnik *cielzasobnik, InfoBox *box)
{
	if (box->dalsi != NULL)
		vloz(cielzasobnik, box->dalsi);
	push(cielzasobnik, box->info);
}

void copy(Zasobnik *cielzasobnik, const Zasobnik *zdrojzasobnik)
{
	if (zdrojzasobnik != NULL&& zdrojzasobnik->sp != NULL&& cielzasobnik != NULL)
	{
		vloz(cielzasobnik, zdrojzasobnik->sp);
	}
}

void nacitaj(Zasobnik *cielzasobnik)
{
	char oznam[] = "Zadavaj prirodzene cislo (koniec = 0)\n-------------------------------------\n";
	int cislo = vstup(oznam);
	while (cislo > 0)
	{
		push(cielzasobnik, cislo);
		cislo = vstup(NULL);
	}
}

InfoBox::InfoBox(int pinfo, InfoBox * predch)
{
	info = pinfo;
	dalsi = predch;
}

InfoBox::InfoBox()
{
	info = 0;
	dalsi = NULL;
}
