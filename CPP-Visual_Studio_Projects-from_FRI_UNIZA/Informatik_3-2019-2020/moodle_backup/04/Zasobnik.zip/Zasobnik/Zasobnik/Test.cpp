#include "Test.h"
#include "Vystup.h"

bool runtest(Zasobnik *zasobnik)
{
	Zasobnik zkopia;
	bool res = true;
	int ires;

	init(&zkopia);

	for (int i = 0; i < 20; i++)
	{
		res = push(zasobnik, i + 1);
		if (!res)
		{
			vypis("Chyba vkladania do zasobnika!\n");
			return false;
		}
	}
	if (zasobnik->pocet!=20)
	{
		vypis("Chyba vkladania do zasobnika! Nespravny pocet prvkov!\n");
		return false;
	}
	copy(&zkopia, zasobnik);
	ires = pop(&zkopia);
	if (ires != 20)
	{
		vypis("Chyba kopirovania zasobnika! Moznost vlozenia neprirodzeneho cisla!\n");
		return false;
	}
	zrus(&zkopia);
	ires = pop(&zkopia);
	if (ires != 0)
	{
		vypis("Chyba zrusenia zasobnika!\n");
		return false;
	}

	res = push(zasobnik, 0);
	if (res == true)
	{
		vypis("Chyba vkladania do zasobnika! Moznost vlozenia neprirodzeneho cisla!\n");
		return false;
	}
	for (int i = 0; i < 20; i++)
	{
		ires = pop(zasobnik);
		if (ires != (20 - i))
		{
			vypis("Chyba vyberu zo zasobnika!\n");
			return false;
		}
	}
	ires = pop(zasobnik);
	if (ires != 0)
	{
		vypis("Chyba vyberu zo zasobnika! Z prazdneho zasobnika bola vybrana ina hodnota ako 0!\n");
		return false;
	}
	zrus(zasobnik);

	return true;
}