#pragma once

struct InfoBox
{
	InfoBox *dalsi;
	int info;
	InfoBox(int info, InfoBox *predch);
	InfoBox();
};

struct Zasobnik {
	InfoBox *sp;
	int pocet;
};

void init(Zasobnik *zasobnik);
bool push(Zasobnik *zasobnik, int x);
int pop(Zasobnik *zasobnik);
int peek(Zasobnik *zasobnik);
void zrus(Zasobnik *zasobnik);
void copy(Zasobnik *cielzasobnik, const Zasobnik *zdrojzasobnik);
void nacitaj(Zasobnik *cielzasobnik);


