#pragma once
#include "Data.h"

void Vypis(TYPHODNOTA phodnota);
void Vypis(const char * text, bool novyriadok = false);