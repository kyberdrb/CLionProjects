#include <iostream>

#include "Vystup.h"

using namespace std;

void Vypis(TYPHODNOTA phodnota)
{
	cout << phodnota << endl;// "\n";
}

void Vypis(const char * text, bool novyriadok)
{
	cout << text;
	if (novyriadok)
		cout << endl;
}
