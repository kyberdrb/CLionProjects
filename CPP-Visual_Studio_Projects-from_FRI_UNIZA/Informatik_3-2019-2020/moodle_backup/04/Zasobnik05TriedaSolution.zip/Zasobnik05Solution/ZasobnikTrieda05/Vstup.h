#pragma once
#include "Data.h"

typedef TYPHODNOTA (*CitajPtr)();

TYPHODNOTA Citaj();
TYPHODNOTA ZadajKladneCislo();
