#include <iostream>
#include <cctype>
#include <cstdio>

#include "Vstup.h"

using namespace std;

TYPHODNOTA Citaj()
{
	TYPHODNOTA cislo;
	cin >> cislo;
	return cislo;
}


TYPHODNOTA ZadajKladneCislo()
{
	TYPHODNOTA cislo = 0;

	char pomCislo[100];

	scanf("%s", pomCislo);
	getchar();

	for (TYPHODNOTA i = 0; i < strlen(pomCislo); i++)
	{
		if (!isdigit(pomCislo[i]))
			return cislo;
	}

	sscanf(pomCislo, "%u", &cislo);
	//	cislo = atoi(pomCislo);
	return cislo;
}