#pragma once
#include "Data.h"
#include "Vystup.h"
#include "Vstup.h"

class CUzol
{
private:
	TYPHODNOTA hodnota = NEPLATNA_HODNOTA;
	CUzol *dalsi = nullptr;
public:
	CUzol(TYPHODNOTA phodnota = NEPLATNA_HODNOTA, CUzol *pdalsi = nullptr)
	{
		hodnota = phodnota;
		dalsi = pdalsi;
	}
	~CUzol()
	{
#ifdef _DEBUG
		Vypis("Destrukor: ");
		Vypis(hodnota);
#endif
	}
	TYPHODNOTA Hodnota() { return hodnota; }
	CUzol *Dalsi() { return dalsi; }

	void Hodnota(TYPHODNOTA phodnota) { hodnota = phodnota; }
	void Dalsi(CUzol *pdalsi) { dalsi = pdalsi; }
};

//inline TYPHODNOTA CUzol::Hodnota() { return hodnota; }

class CZasobnik
{
private:
	CUzol *stackPointer = nullptr;
	UPOCETTYP pocet = 0;
	void Vloz(CZasobnik &ciel, CUzol *puzol);
public:
	CZasobnik();
	CZasobnik(const CZasobnik &zdroj)
	{
		Copy(zdroj);
	}
	~CZasobnik();

	bool Push(TYPHODNOTA phodnota);
	TYPHODNOTA Pop();
	TYPHODNOTA Peek();

	void Copy(const CZasobnik &zdroj);
	void Nacitaj(CitajPtr citajFun);
};

