#include "CTest.h"
#include "Vstup.h"

bool CTest::Testuj(CZasobnik &pzasobnik)
{
	pzasobnik.Nacitaj(ZadajKladneCislo);
	//pzasobnik.Push(10);
	//pzasobnik.Push(20);
	//pzasobnik.Push(30);
	//TYPHODNOTA x = pzasobnik.Peek();
	//TYPHODNOTA y = pzasobnik.Pop();

	//CZasobnik kopia(pzasobnik);
	//kopia.Push(100);
	//kopia.Copy(pzasobnik);
	//if (x != y)
	//	return false;
	return true;
}
