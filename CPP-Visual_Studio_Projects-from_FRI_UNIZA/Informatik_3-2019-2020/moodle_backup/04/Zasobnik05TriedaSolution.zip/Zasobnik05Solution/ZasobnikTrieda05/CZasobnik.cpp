#include <new>

#include "CZasobnik.h"

using namespace std;

CZasobnik::CZasobnik()
{
	pocet = 0;
	stackPointer = nullptr;
}


CZasobnik::~CZasobnik()
{
	while (pocet > 0)
		Pop();
}

//1.krok: alokuj novy uzol
//2.krok: uloz hodnoty do uzla
//3.krok: pripoj novy uzol na vrchol zasobnika
//4.krok: zvys pocet uzlov zasobnika
bool CZasobnik::Push(TYPHODNOTA phodnota)
{
	if (phodnota != NEPLATNA_HODNOTA)
	{
		//		CUzol *novy = new (nothrow) CUzol;
		stackPointer = new CUzol(phodnota, stackPointer);
		pocet++;
		return true;
	}
	return false;
}

//1.krok: Odloz hodnoty vrchola zasobnika do pomocnych premennych
//2.krok: Vymaz uzol
//4.krok: Nastav novy vrchol zasobnika
//5.krok: Zniz pocet uzlov v zasobniku
//6.krok: Vrat hodnotu
TYPHODNOTA CZasobnik::Pop()
{
	if (pocet > 0)
	{
		TYPHODNOTA hodnota = stackPointer->Hodnota();
		CUzol *novyvrcholzasobnika = stackPointer->Dalsi();
		delete stackPointer;
		stackPointer = novyvrcholzasobnika;
		pocet--;
		return hodnota;
	}
	return NEPLATNA_HODNOTA;
}

TYPHODNOTA CZasobnik::Peek()
{
	if (pocet > 0)
		return stackPointer->Hodnota();
	return NEPLATNA_HODNOTA;
}

void CZasobnik::Vloz(CZasobnik &ciel, CUzol *puzol)
{
	if (puzol->Dalsi())
		Vloz(ciel, puzol->Dalsi());
	ciel.Push(puzol->Hodnota());
}

void CZasobnik::Copy(const CZasobnik &zdroj)
{
	if (stackPointer)
		this->~CZasobnik();
	if (zdroj.stackPointer)
		Vloz(*this, zdroj.stackPointer);
}

void CZasobnik::Nacitaj(CitajPtr citajFun)
{
	if (citajFun)
	{
		Vypis("Zadavaj prirodzene cisla (koniec=0):", true);
		while (Push(citajFun()))
			;
	}
}
