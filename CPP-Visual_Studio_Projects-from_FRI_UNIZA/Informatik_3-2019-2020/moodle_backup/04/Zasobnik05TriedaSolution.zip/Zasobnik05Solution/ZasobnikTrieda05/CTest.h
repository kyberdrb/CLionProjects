#pragma once
#include "CZasobnik.h"

class CTest
{
public:
	bool Testuj(CZasobnik &pzasobnik);
};

