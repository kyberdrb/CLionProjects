#define TESTY
#include <memory>

using namespace std;

#ifdef TESTY
#include "CTest.h"
#endif

//CZasobnik *z;
unique_ptr<CZasobnik> z(new CZasobnik);

int main()
{
	bool ok(true);
#ifdef TESTY
	CTest test;
	ok = test.Testuj(*z);
#endif
	if (ok)
		;

//	delete z;
	return 0;
}
