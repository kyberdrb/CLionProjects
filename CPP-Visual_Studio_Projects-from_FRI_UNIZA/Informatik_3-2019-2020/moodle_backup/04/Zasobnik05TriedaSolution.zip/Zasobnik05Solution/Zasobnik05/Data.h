#pragma once

//#define TYPHODNOTA unsigned int;

typedef unsigned int TYPHODNOTA;
typedef unsigned int UPOCETTYP;

const TYPHODNOTA NEPLATNA_HODNOTA = 0;

