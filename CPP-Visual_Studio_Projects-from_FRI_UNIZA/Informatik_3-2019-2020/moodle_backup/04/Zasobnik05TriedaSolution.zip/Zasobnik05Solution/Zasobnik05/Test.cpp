#include "Test.h"
#include "Zasobnik.h"

bool Testuj()
{
	Zasobnik z;
	Init(&z);

	Push(&z, 10);
	if (z.pocet != 1)
	{
		Uprac(&z);
		return false;
	}
	Push(&z, 20);
	Push(&z, 30);
	Push(&z, 40);
	TYPHODNOTA x = Pop(&z);
	if (x != 40)
	{
		Uprac(&z);
		return false;
	}
	Zasobnik kopia;
	Init(&kopia);
	Push(&kopia, 100);
	Copy(&kopia, &z);
	Uprac(&z);
	Uprac(&kopia);
	return true;
}