#include <stdlib.h>
#include <malloc.h>

#include "Zasobnik.h"

void Init(Zasobnik * pzasobnik)
{
	pzasobnik->pocet = 0;
	pzasobnik->stackPointer = nullptr;
}

//1.krok: alokuj novy uzol
//2.krok: uloz hodnoty do uzla
//3.krok: pripoj novy uzol na vrchol zasobnika
//4.krok: zvys pocet uzlov zasobnika
bool Push(Zasobnik *pzasobnik, TYPHODNOTA phodnota)
{
	//Uzol *novy = new Uzol;
	//Uzol *novy = (Uzol *)calloc(1, sizeof(Uzol));
	if (pzasobnik && phodnota != NEPLATNA_HODNOTA) //if (pzasobnik != nullptr && phodnota != NEPLATNA_HODNOTA)
	{
		Uzol *novy = (Uzol *)malloc(sizeof(Uzol));   // 1.
		if (novy != nullptr)
		{
			novy->hodnota = phodnota;					//2.
			novy->dalsi = pzasobnik->stackPointer;		//2.
			pzasobnik->stackPointer = novy;				//3.
			pzasobnik->pocet++;							//4.
			return true;
		}
	}
	return false;
}

//1.krok: Odloz hodnoty vrchola zasobnika do pomocnych premennych
//2.krok: Vymaz uzol
//4.krok: Nastav novy vrchol zasobnika
//5.krok: Zniz pocet uzlov v zasobniku
//6.krok: Vrat hodnotu
TYPHODNOTA Pop(Zasobnik * pzasobnik)
{
	if (pzasobnik != nullptr && pzasobnik->pocet > 0)
	{
		TYPHODNOTA hodnota = pzasobnik->stackPointer->hodnota;
		Uzol *novyvrcholzasobnika = pzasobnik->stackPointer->dalsi;

		//delete pzasobnik->stackPointer;
		free(pzasobnik->stackPointer);
		pzasobnik->stackPointer = novyvrcholzasobnika;
		pzasobnik->pocet--;
		return hodnota;
	}
	return NEPLATNA_HODNOTA;
}

TYPHODNOTA Peek(Zasobnik * pzasobnik)
{
	if (pzasobnik != nullptr && pzasobnik->pocet > 0)
		return pzasobnik->stackPointer->hodnota;
	return NEPLATNA_HODNOTA;
}

void Uprac(Zasobnik * z)
{
	while (z != nullptr && z->pocet > 0)
		Pop(z);
}

void Copy(Zasobnik * kopia, Zasobnik * zdroj)
{
	//if (kopia != nullptr && zdroj != nullptr)
	if (kopia && zdroj)
	{
		Zasobnik pomZasobnik;
		Init(&pomZasobnik);
		Uprac(kopia);

		while (zdroj->pocet > 0)
			Push(&pomZasobnik, Pop(zdroj));
		while (pomZasobnik.pocet)
		{
			TYPHODNOTA hodnota = Pop(&pomZasobnik);
			Push(kopia, hodnota);
			Push(zdroj, hodnota);
		}
	}
}
