#pragma once
#include "Data.h"

//#define NEPLATNA_HODNOTA 0

struct Uzol
{
	TYPHODNOTA hodnota;
	Uzol *dalsi;
};

struct Zasobnik
{
	Uzol *stackPointer;
	UPOCETTYP pocet;
};

void Init(Zasobnik * pzasobnik);
bool Push(Zasobnik *pzasobnik, TYPHODNOTA phodnota);
TYPHODNOTA Pop(Zasobnik *pzasobnik);
TYPHODNOTA Peek(Zasobnik *pzasobnik);

void Uprac(Zasobnik *z);

void Copy(Zasobnik *kopia, Zasobnik *zdroj);