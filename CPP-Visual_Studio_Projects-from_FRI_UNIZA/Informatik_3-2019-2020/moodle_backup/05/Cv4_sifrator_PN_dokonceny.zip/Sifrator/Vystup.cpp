#include <cstdio>
#include <cstring>
#include "Vystup.h"
#include "Funkcie.h"
#include <iostream>

using namespace std;

Vystup::Vystup(const char *menoSuboru)
{
	aMenoSuboru = KopirujRetazec(menoSuboru);
}

Vystup::Vystup(const Vystup & zdroj)
{
	aMenoSuboru = KopirujRetazec(zdroj.aMenoSuboru);
}

Vystup & Vystup::operator=(const Vystup & zdroj)
{
	if (this != &zdroj)
	{
		delete[] aMenoSuboru;
		aMenoSuboru = KopirujRetazec(zdroj.aMenoSuboru);
	}
	return *this;
}

Vystup::~Vystup()
{
	delete[] aMenoSuboru;
}

void Vystup::zapis(unsigned char *text)
{
	if (text && *text)
	{
		if (aMenoSuboru && *aMenoSuboru)
		{
			int dlzka = strlen((char *)text);
			FILE *f = fopen(aMenoSuboru, "wb");
			if (f)
			{
				fwrite(text, dlzka, 1, f);
				fclose(f);
			}
		}
		else
			cout << text << endl;
			//printf("%s\n", text);
	}
}
