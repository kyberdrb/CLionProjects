#pragma once
class Sifrator
{
private:
	char aCinnost;	// Typ po�adovanej �innosti: s � �ifrovanie, d � de�ifrovanie, h � help
	char *aHeslo;	// Heslo: max. 8 znakov
	char *aVstupSubor;	// Meno (vr�tane cesty) vstupn�ho s�boru
	bool aKonzola;	// Indik�tor v�pisu na konzolu (napr. znak c)
	char *aVystupSubor;	// Meno (vr�tane cesty) v�stupn�ho s�boru
	void init(char cinnost, const char *heslo, const char *vstupsubor, bool konzola, const char *vystupsubor);
	void zmaz();
	void vypisHelp();
public:
	Sifrator(char cinnost, const char *heslo, const char *vstupsubor, bool konzola, const char *vystupsubor);
	Sifrator(const Sifrator &zdroj);
	//Sifrator &operator =(const Sifrator &zdroj);
	~Sifrator();

	void start();
};

