#pragma once
#include "Koder.h"
#include "Test.h"
#include "Vstup.h"
#include "Vystup.h"

class Test
{
public:
	// Testy kodera
	bool run()
	{
		Koder k;
		Vstup v("Test.h");

		unsigned char *srctext = v.citaj();
		unsigned char *zasifrtext = k.koduj((unsigned char *)"vt", srctext);
		delete[] srctext;

		Vystup vyst("Test.kod");
		vyst.zapis(zasifrtext);
		delete[] zasifrtext;

		Vstup dv("Test.kod");
		zasifrtext = dv.citaj();

		Koder dk;
		srctext = dk.dekoduj((unsigned char *)"vt", zasifrtext);
		delete[] zasifrtext;

		Vystup konz("");
		konz.zapis(srctext);
		delete[] srctext;

		return true;
	}
};

