#include <cstring>
#include "Funkcie.h"

char  *KopirujRetazec(const char *zdrojretazec)
{
	char *ciel(nullptr);
	if (zdrojretazec && *zdrojretazec)
	{
		int dlzka = strlen(zdrojretazec);
		ciel = new char[dlzka + 1];
		strcpy(ciel, zdrojretazec);
	}
	return ciel;
}