#pragma once
#include <string>

using namespace std;

class IZobrazovac
{
public:
	virtual void zobraz(string *info) = 0;
};

