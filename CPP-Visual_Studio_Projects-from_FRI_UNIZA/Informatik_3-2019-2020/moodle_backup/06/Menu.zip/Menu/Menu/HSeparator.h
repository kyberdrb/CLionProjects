#pragma once
#include "textcommand.h"

class HSeparator : public TextCommand
{
public:

	HSeparator(IZobrazovac &pZobrazovac)
		: TextCommand(-1, " | ", pZobrazovac)
	{
	}
};

