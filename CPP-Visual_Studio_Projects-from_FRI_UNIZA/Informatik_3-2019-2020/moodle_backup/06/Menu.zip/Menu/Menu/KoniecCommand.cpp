#include "KoniecCommand.h"


KoniecCommand::KoniecCommand(IZobrazovac &pZobrazovac, IReceiver *pReceiver)
: TextCommand(KONIEC_ID, "[K]oniec", pZobrazovac, pReceiver, 'K')
{
}


bool KoniecCommand::execute()
{
	return !TextCommand::execute();
}