#pragma once
#include "ireceiver.h"
#include "TextMenu.h"
#include "Student.h"

class Okno : public IReceiver
{
private:
	IZobrazovac *aZobrazovac;
	TextMenu *aMenu;
	Student *aStudent;
	TextMenu *sMenu;
	
public:
	Okno(void);
	~Okno(void);
	void start();
	virtual void action(int id);
};

