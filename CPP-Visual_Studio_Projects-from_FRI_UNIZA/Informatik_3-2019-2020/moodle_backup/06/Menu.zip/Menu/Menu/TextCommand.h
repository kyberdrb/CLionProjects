#pragma once
#include <string>
#include "icommand.h"
#include "IZobrazovac.h"
#include "IReceiver.h"

using namespace std;

class TextCommand : public ICommand
{
private:
	string aText;
	char aHotKey;
	IZobrazovac &aZobrazovac;
	IReceiver *aReceiver;
	int aId;
public:
	TextCommand(int id, string pText, IZobrazovac &pZobrazovac, IReceiver *pReceiver = NULL, char pHotKey = '\1');

	virtual bool execute();
	virtual void zobraz();
	virtual bool jeHotKey(char c);
	virtual int id();
};

