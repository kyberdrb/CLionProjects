#include <stdlib.h>
#include <conio.h>

#include "TextMenu.h"
#include "TextCommand.h"
#include "KoniecCommand.h"
#include "HSeparator.h"
#include "VSeparator.h"

TextMenu::TextMenu(unsigned pPocet, IZobrazovac &pZobrazovac)
: aPocet(pPocet), aZobrazovac(pZobrazovac), aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL)
{
	for (unsigned int i = 0; i < aPocet; i++)
		aPrikazy[i] = NULL;
}


TextMenu::~TextMenu(void)
{
	for (int i = 0; i < aPocet && aPrikazy[i]; i++)
	{
		delete aPrikazy[i];
	}
	delete[] aPrikazy;
}

int TextMenu::najdiVolne()
{
	int i;
	for (i = 0; i < aPocet; i++)
	{
		if (aPrikazy[i] == NULL)
			return i;
	}
	return -1;
}

bool TextMenu::pridajPrikaz(int id, string pText, IReceiver *pReceiver, char pHotKey)
{
	int i = najdiVolne();
	if (i != -1)
	{
		aPrikazy[i] = new TextCommand(id, pText, aZobrazovac, pReceiver, pHotKey);
		return true;
	}
	return false;
}

bool TextMenu::pridajKoniec(IReceiver *pReceiver)
{
	int i = najdiVolne();
	if (i != -1)
	{
		aPrikazy[i] = new KoniecCommand(aZobrazovac, pReceiver);
		return true;
	}
}


bool TextMenu::pridajVSeparator()
{
	int i = najdiVolne();
	if (i != -1)
	{
		aPrikazy[i] = new VSeparator(aZobrazovac);
		return true;
	}
}

bool TextMenu::pridajHSeparator()
{
	int i = najdiVolne();
	if (i != -1)
	{
		aPrikazy[i] = new HSeparator(aZobrazovac);
		return true;
	}
}


void TextMenu::zobraz()
{
	for (unsigned int i = 0; i < aPocet && aPrikazy[i] != NULL; i++)
	{
		aPrikazy[i]->zobraz();
	}
}

void TextMenu::start()
{
	do {
		zobraz();
	} while (vykonajPrikaz());
}

bool TextMenu::vykonajPrikaz()
{
	char vstup = getch();
	for (unsigned int i = 0; i < aPocet && aPrikazy[i] != NULL; i++)
	{
		if (aPrikazy[i]->jeHotKey(vstup))
			return aPrikazy[i]->execute();
	}
	return true;
}

void TextMenu::action(int id)
{
	start();
}