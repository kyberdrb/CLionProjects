#pragma once

const int KONIEC_ID = 1;
const int USER_ID = 2;

class ICommand
{
public:
	virtual bool execute() = 0;
	virtual void zobraz() = 0;
	virtual bool jeHotKey(char c) = 0;
	virtual int id() = 0;
};

