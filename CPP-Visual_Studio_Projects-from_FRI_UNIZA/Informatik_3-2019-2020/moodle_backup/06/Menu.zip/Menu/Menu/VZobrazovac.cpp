#include <iostream>

#include "VZobrazovac.h"

void VZobrazovac::zobraz(string *info)
{
	cout << *info << endl;
}

