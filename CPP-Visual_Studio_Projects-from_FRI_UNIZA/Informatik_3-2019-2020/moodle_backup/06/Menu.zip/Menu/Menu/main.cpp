#include "Okno.h"

int main()
{
	Okno HlavneOkno;
	HlavneOkno.start();
	return 0;
}