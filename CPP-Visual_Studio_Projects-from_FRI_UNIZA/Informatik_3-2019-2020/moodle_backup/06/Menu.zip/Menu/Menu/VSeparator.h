#pragma once
#include "textcommand.h"

class VSeparator : public TextCommand
{
public:
	VSeparator(IZobrazovac &pZobrazovac)
		: TextCommand(-1, "-------------", pZobrazovac)
	{
	}
};

