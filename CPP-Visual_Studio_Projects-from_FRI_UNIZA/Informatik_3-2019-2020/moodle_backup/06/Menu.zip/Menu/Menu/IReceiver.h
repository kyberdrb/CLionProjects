#pragma once
class IReceiver
{
public:
	virtual void action(int id) = 0;
};

