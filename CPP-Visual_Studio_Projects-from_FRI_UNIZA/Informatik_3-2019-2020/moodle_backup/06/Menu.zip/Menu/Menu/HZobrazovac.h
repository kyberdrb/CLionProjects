#pragma once
#include "izobrazovac.h"

class HZobrazovac :	public IZobrazovac
{
public:
	virtual void zobraz(string *info);
};

