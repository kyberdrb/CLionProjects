#include "TextCommand.h"

TextCommand::TextCommand(int id, string pText, IZobrazovac &pZobrazovac, IReceiver *pReceiver, char pHotKey)
	: aId(id),aText(pText), aZobrazovac(pZobrazovac), aReceiver(pReceiver), aHotKey(tolower(pHotKey))
{
}

bool TextCommand::execute()
{
	if(aReceiver)
		aReceiver->action(aId);
	return true;
}

void TextCommand::zobraz()
{
	aZobrazovac.zobraz(&aText);
}

bool TextCommand::jeHotKey(char c)
{
	return tolower(c) == aHotKey;
}

int TextCommand::id()
{
	return aId;
}