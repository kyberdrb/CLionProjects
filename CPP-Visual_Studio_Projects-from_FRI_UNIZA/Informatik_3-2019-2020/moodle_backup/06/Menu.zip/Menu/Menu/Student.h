#pragma once
#include <string>
using namespace std;

class Student
{
private:
	string aMeno;
	string aPriezvisko;
	string aSkola;
public:
	Student(string pMeno, string pPriezvisko, string pSkola):
		aMeno(pMeno), aPriezvisko(pPriezvisko), aSkola(pSkola)
	{
	}

	string meno() { return aMeno; }
	string priezvisko() { return aPriezvisko; }
	string skola() { return aSkola; }
};

