#include "Okno.h"
#include "VZobrazovac.h"
#include "HZobrazovac.h"
#include "ICommand.h"

Okno::Okno(void) : aZobrazovac(new HZobrazovac()),
aMenu(new TextMenu(9, *aZobrazovac)),
sMenu(new TextMenu(5, *aZobrazovac)),
aStudent(new Student("David", "Copperfield", "Zilinska Univerzita"))
{
	aMenu->pridajPrikaz(USER_ID, "[M]eno", this, 'M');
	aMenu->pridajHSeparator();
	aMenu->pridajPrikaz(USER_ID + 1, "[P]priezvisko", this, 'P');
	aMenu->pridajHSeparator();
	aMenu->pridajPrikaz(USER_ID + 2, "[S]kola", this, 'S');
	aMenu->pridajHSeparator();
	aMenu->pridajPrikaz(USER_ID + 3, "[D]alsi", this, 'D');
	aMenu->pridajHSeparator();
	aMenu->pridajKoniec(this);

	sMenu->pridajPrikaz(USER_ID + 4, "[X]sur", this, 'X');
	sMenu->pridajHSeparator();
	sMenu->pridajPrikaz(USER_ID + 5, "[Y]sur", this, 'Y');
	sMenu->pridajHSeparator();
	sMenu->pridajKoniec(this);
}


Okno::~Okno(void)
{
	delete aZobrazovac;
	delete aStudent;
	delete aMenu;
}

void Okno::start()
{
	aMenu->start();
}

void Okno::action(int id)
{
	string nl = "\n";
	aZobrazovac->zobraz(&nl);
	switch (id)
	{
	case USER_ID: 
		aZobrazovac->zobraz(&aStudent->meno());
		break;
	case USER_ID+1:
		aZobrazovac->zobraz(&aStudent->priezvisko());
		break;
	case USER_ID + 2:
		aZobrazovac->zobraz(&aStudent->skola());
		break;
	case USER_ID + 3:
		sMenu->action(-1);
		break;
	case USER_ID + 4:
		aZobrazovac->zobraz(new string("XXX"));
		break;
	case USER_ID + 5:
		aZobrazovac->zobraz(new string("YYY"));
		break;
	}
	aZobrazovac->zobraz(&nl);
}
