#pragma once
#include "textcommand.h"
class KoniecCommand : public TextCommand
{
public:
	KoniecCommand(IZobrazovac &pZobrazovac, IReceiver *pReceiver = NULL);
	virtual bool execute();
};

