#include <iostream>

#include "HZobrazovac.h"

void HZobrazovac::zobraz(string *info)
{
	cout << *info;
}
