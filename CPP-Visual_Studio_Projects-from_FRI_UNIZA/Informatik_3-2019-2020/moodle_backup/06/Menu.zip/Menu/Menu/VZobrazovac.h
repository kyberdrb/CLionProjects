#pragma once
#include "izobrazovac.h"

class VZobrazovac :	public IZobrazovac
{
public:
	virtual void zobraz(string *info);
};

