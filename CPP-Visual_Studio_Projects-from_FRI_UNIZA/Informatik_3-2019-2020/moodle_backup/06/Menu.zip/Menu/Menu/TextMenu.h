#pragma once
#include "ICommand.h"
#include "IZobrazovac.h"
#include "IReceiver.h"

class TextMenu : public IReceiver
{
private:
	unsigned aPocet;
	ICommand **aPrikazy;
	IZobrazovac &aZobrazovac;
	void zobraz();
	bool vykonajPrikaz();
	int najdiVolne();
public:
	TextMenu(unsigned pPocet, IZobrazovac &pZobrazovac);
	~TextMenu(void);
	bool pridajPrikaz(int id, string pText, IReceiver *pReceiver = NULL, char pHotKey = '\1');
	bool pridajKoniec(IReceiver *pReceiver);
	bool pridajVSeparator();
	bool pridajHSeparator();
	void start();
	virtual void action(int id);
};

