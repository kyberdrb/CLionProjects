#include "VystupXml.h"

VystupXml::VystupXml(const char * menosuboru) : VystupSubor(menosuboru)
{
	VystupSubor::Vypis("<xml version=\"1.0\" encoding = \"utf-8\"?>");
	VystupSubor::Vypis("<body>");
}

VystupXml::~VystupXml()
{
	VystupSubor::Vypis("<\\body>");
}

void VystupXml::Vypis(const char * text)
{
	VystupSubor::Vypis("<text>");
	VystupSubor::Vypis(text);
	VystupSubor::Vypis("<\\text>");
}
