#include "VystupSubor.h"

VystupSubor::VystupSubor(const char * meno) :fd(nullptr)
{
	if (meno && *meno)
		fd = fopen(meno, "wt+");
}

VystupSubor::~VystupSubor()
{
	if (fd)
		fclose(fd);
}

void VystupSubor::Vypis(const char * text)
{
	if (text)
		fprintf(fd, "%s\n", text);
}
