#include <cstring>
#include <cstdlib>

#include "BinCislo.h"
using namespace std;

llong BinCislo::Bin2Dec(const char * binstrcislo)
{
	int dlzka = strlen(binstrcislo);
	char *pomBinCislo = new char[dlzka + 1];
	strcpy(pomBinCislo, binstrcislo);

	//pomBinCislo = strdup(binstrcislo);
	strrev(pomBinCislo);
	llong deccislo(0);

	int i(0);
	while (pomBinCislo[i])
	{
		if (pomBinCislo[i] == '1')
			deccislo += ((llong)1 << i);
		i++;
	}
	if (binstrcislo[0] == '-')
		deccislo = -deccislo;
	//free(pomBinCislo);
	delete[] pomBinCislo;

	return deccislo;
}

char *BinCislo::Dec2Bin(char *cielbinstrcislo, llong deccislo)
{
	llong pomcislo(abs(deccislo));
	if (cielbinstrcislo)
	{
		int i(0);
		do
		{
			cielbinstrcislo[i++] = (pomcislo % 2) + '0';
			pomcislo >>= 1; // /=2
		} while (pomcislo > 0);
		if (deccislo < 0)
			cielbinstrcislo[i++] = '-';
		cielbinstrcislo[i] = '\0';
	}
	return strrev(cielbinstrcislo);
}

BinCislo::~BinCislo()
{
}

void BinCislo::Vypis(IVystup & vystup)
{
	char pombuf[66];
	vystup.Vypis(Dec2Bin(pombuf, cislo));
}
