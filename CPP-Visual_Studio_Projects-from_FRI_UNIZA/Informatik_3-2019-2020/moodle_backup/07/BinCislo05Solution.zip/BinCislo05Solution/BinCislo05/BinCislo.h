#pragma once
#include "IVystup.h"
typedef long long llong;

class BinCislo
{
private:
	llong cislo;
	llong Bin2Dec(const char *binstrcislo);
	char *Dec2Bin(char *cielbinstrcislo, llong deccislo);
public:
	BinCislo(llong deccislo = 0) : cislo(deccislo) {}
	BinCislo(const char *binstrcislo) : cislo(Bin2Dec(binstrcislo)) {}
	~BinCislo();
	void Vypis(IVystup &vystup);
	friend BinCislo operator+(BinCislo op1, BinCislo op2);
	friend BinCislo operator-(BinCislo op1, BinCislo op2);
	friend BinCislo operator/(BinCislo op1, BinCislo op2);
	friend BinCislo operator*(BinCislo op1, BinCislo op2);
	friend bool operator <(BinCislo op1, BinCislo op2);
	friend bool operator >(BinCislo op1, BinCislo op2);
	friend bool operator <=(BinCislo op1, BinCislo op2);
	friend bool operator >=(BinCislo op1, BinCislo op2);
	friend bool operator ==(BinCislo op1, BinCislo op2);
	friend bool operator !=(BinCislo op1, BinCislo op2);
};

inline BinCislo operator+(BinCislo op1, BinCislo op2) { return op1.cislo + op2.cislo; }
inline BinCislo operator-(BinCislo op1, BinCislo op2) { return op1.cislo - op2.cislo; }
inline BinCislo operator/(BinCislo op1, BinCislo op2) { return op1.cislo / op2.cislo; }
inline BinCislo operator*(BinCislo op1, BinCislo op2) { return op1.cislo * op2.cislo; }

inline bool operator<(BinCislo op1, BinCislo op2) { return op1.cislo < op2.cislo; }
inline bool operator>=(BinCislo op1, BinCislo op2) { return !(op1 < op2); }

inline bool operator>(BinCislo op1, BinCislo op2) { return op1.cislo > op2.cislo; }
inline bool operator<=(BinCislo op1, BinCislo op2) { return !(op1 > op2); }

inline bool operator==(BinCislo op1, BinCislo op2) { return op1.cislo == op2.cislo; }
inline bool operator!=(BinCislo op1, BinCislo op2) { return !(op1 == op2); }

