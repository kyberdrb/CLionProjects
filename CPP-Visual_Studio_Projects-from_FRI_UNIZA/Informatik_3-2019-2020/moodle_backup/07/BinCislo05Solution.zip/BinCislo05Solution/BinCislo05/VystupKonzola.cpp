#include <iostream>
#include "VystupKonzola.h"

using namespace std;

void VystupKonzola::Vypis(const char * text)
{
	if (text)
		cout << text << endl;
}
