#include "IVystup.h"


IVystup::~IVystup()
{
}
