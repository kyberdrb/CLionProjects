#pragma once
#include <cstdio>
#include "IVystup.h"

using namespace std;

class VystupSubor : public IVystup
{
private:
	FILE  *fd;
public:
	VystupSubor(const char *meno);
	~VystupSubor();

	// Inherited via IVystup
	virtual void Vypis(const char * text) override;
};

