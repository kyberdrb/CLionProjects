#pragma once
#include "VystupSubor.h"

class VystupXml : public VystupSubor
{
public:
	VystupXml(const char *menosuboru);
	~VystupXml();

	// Inherited via IVystup
	virtual void Vypis(const char * text) override;
};

