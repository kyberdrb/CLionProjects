#include "BinCislo.h"
#include "IVystup.h"
#include "VystupKonzola.h"
#include "VystupSubor.h"
#include "VystupXml.h"

int main()
{
	BinCislo x(-13), y("-11101"), z;
	//IVystup *konzola = new VystupKonzola;
	IVystup *vypisovac = new VystupXml("cislo.xml");
	
	z = x + y;
	z.Vypis(*vypisovac);
	z = y + 5;
	z.Vypis(*vypisovac);
	z = y / 2;
	z.Vypis(*vypisovac);
	
	delete vypisovac;
	return 0;
}