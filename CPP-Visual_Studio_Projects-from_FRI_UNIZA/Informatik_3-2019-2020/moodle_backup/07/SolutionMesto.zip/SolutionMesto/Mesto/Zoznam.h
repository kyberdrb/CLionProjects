#pragma once
#include "Obec.h"

class Zoznam
{
private:
	int pocet;
	Obec *data;
	void Skopiruj(int ppocet, const Obec *zdroj);
public:
	Zoznam() : data(nullptr), pocet(0) {}
	Zoznam(const Zoznam &zdroj);
	Zoznam &operator =(const Zoznam &zdroj);
	~Zoznam();
	void vloz(const Obec &obec);
	void vypis();
};

