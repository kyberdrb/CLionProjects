#pragma once
class Obec
{
private:
	char *nazov;
	double gpsX;
	double gpsY;
	char *kopirujRetazec(const char *zdroj);
public:
	Obec() : nazov(nullptr), gpsX(0), gpsY(0) {}
	Obec(const char *pnazov, double pgpsx, double pgpsy);
	Obec(const Obec &zdroj);
	Obec &operator =(const Obec &zdroj);
	~Obec();

	const char *Nazov() const { return nazov; }
	double GpsX() const { return gpsX; }
	double GpsY() const { return gpsY; }
};

