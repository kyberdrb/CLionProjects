#include "Zoznam.h"
#include "Obec.h"

int main()
{
	Zoznam obce;
	obce.vloz(Obec("Zilina", 0, 0));
	obce.vloz(Obec("Bratislava", 0, 0));
	obce.vloz(Obec("Mojs", 0, 0));
	obce.vloz(Obec("Tvrdosin", 0, 0));
	obce.vypis();
	return 0;
}