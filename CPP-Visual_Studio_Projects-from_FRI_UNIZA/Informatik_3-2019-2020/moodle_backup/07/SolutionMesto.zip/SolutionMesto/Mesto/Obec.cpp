#include <cstring>
#include "Obec.h"


char *Obec::kopirujRetazec(const char * zdroj)
{
	char *rettxt = nullptr;
	if (zdroj && *zdroj) {
		int dlzka = strlen(zdroj);
		rettxt = new char[dlzka + 1];
		strcpy(rettxt, zdroj);
	}
	return rettxt;
}

Obec::Obec(const char *pnazov, double pgpsx, double pgpsy)
	: nazov(kopirujRetazec(pnazov)), gpsX(pgpsx), gpsY(pgpsy)
{

}

Obec::Obec(const Obec & zdroj)
	: nazov(kopirujRetazec(zdroj.nazov)), gpsX(zdroj.gpsX), gpsY(zdroj.gpsY)
{
}

Obec & Obec::operator=(const Obec & zdroj)
{
	if (this != &zdroj)
	{
		delete[] nazov;
		nazov = kopirujRetazec(zdroj.nazov);
		gpsX = zdroj.gpsX;
		gpsY = zdroj.gpsY;
	}
	return *this;
}


Obec::~Obec()
{
	delete[] nazov;
}
