#include <iostream>
#include <cstring>
#include "Zoznam.h"

using namespace std;

Zoznam::Zoznam(const Zoznam & zdroj)
	: data(nullptr)
{
	Skopiruj(zdroj.pocet, zdroj.data);
}

Zoznam & Zoznam::operator=(const Zoznam & zdroj)
{
	if (this != &zdroj) {
		delete[] data;
		Skopiruj(zdroj.pocet, zdroj.data);
	}
	return *this;
}

void Zoznam::Skopiruj(int ppocet,const Obec *zdroj)
{
	pocet = ppocet;
	if (pocet)
	{
		data = new Obec[pocet];
		for (int i = 0; i < pocet; i++)
			data[i] = zdroj[i];
	}
}

Zoznam::~Zoznam()
{
	delete[] data;
}

void Zoznam::vloz(const Obec &obec)
{
	Obec *pomdata = new Obec[pocet + 1];
	if (pocet == 0) {
		data = pomdata;
		data[0] = obec;
	}
	else
	{
		int i = 0;
		while (strcmp(data[i].Nazov(), obec.Nazov()) < 0)
		{
			pomdata[i] = data[i];
			i++;
		}
		pomdata[i] = obec;
		while (i < pocet)
			pomdata[++i] = data[i - 1];
		Obec *pom = data;
		data = pomdata;
		delete[] pom;
	}
	pocet++;
}

void Zoznam::vypis()
{
	for (int i = 0; i < pocet; i++)
		cout << data[i].Nazov() << endl << "  GPS X: " << data[i].GpsX() << endl << "  GPS Y: " << data[i].GpsY() << endl << endl;
}
