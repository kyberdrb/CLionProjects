#include <iostream>
#include "Vystup.h"

using namespace std;

void VertVystup::zobraz(string text)
{
	cout << text << endl;
}

void HorzVystup::zobraz(string text)
{
	cout << text;
}
