#include "Separator.h"

ICommand * VerticalSeparator::clone()
{
	return new VerticalSeparator(*this);
}

ICommand * HorizontalSeparator::clone()
{
	return new HorizontalSeparator(*this);
}
