#include "TextMenu.h"
#include "TextCommand.h"
#include "KoniecCommand.h"
#include "Separator.h"

TextMenu::TextMenu(unsigned pocet, IVystup & vystup, IVstup & vstup)
	:aPocet(pocet), aVystup(vystup), aVstup(vstup),
	aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL),
	aAktualnyPocet(0)
{
	if (aPrikazy)
		memset(aPrikazy, 0, aPocet*sizeof(ICommand *));
	//for (int i = 0;i < aPocet;i++)
	//	aPrikazy[i] = NULL;
}

TextMenu::TextMenu(const TextMenu & zdroj)
	:aPocet(zdroj.aPocet), aVystup(zdroj.aVystup), aVstup(zdroj.aVstup),
	aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL),
	aAktualnyPocet(zdroj.aAktualnyPocet)
{
	skopirujPrikazy(zdroj);
}

TextMenu & TextMenu::operator=(const TextMenu & zdroj)
{
	if (this != &zdroj)
	{
		TextMenu::~TextMenu();
		aPocet = zdroj.aPocet;
		aVystup = zdroj.aVystup;
		aVstup = zdroj.aVstup;
		aPrikazy = aPocet > 0 ? new ICommand *[aPocet] : NULL;
		aAktualnyPocet = zdroj.aAktualnyPocet;
		skopirujPrikazy(zdroj);
	}
	return *this;
}

TextMenu::~TextMenu()
{
	for (unsigned i = 0;i < aPocet && aPrikazy[i];i++)
		delete aPrikazy[i];
	delete[] aPrikazy;
}

bool TextMenu::addCommand(const char * text, int id, char hotkey, IReceiver * receiver)
{
	if (text && *text)
		return addCommand(new TextCommand(text, aVystup, id, hotkey, receiver));
	return false;
}

bool TextMenu::addKoniecCommand(IReceiver * receiver)
{
	return addCommand(new KoniecCommand(aVystup, receiver));
}

bool TextMenu::addVSeparator()
{
	return addCommand(new VerticalSeparator(aVystup));
}

bool TextMenu::addHSeparator()
{
	return addCommand(new HorizontalSeparator(aVystup));
}

void TextMenu::action(int id)
{
	start();
}

bool TextMenu::addCommand(ICommand * prikaz)
{
	if (aPrikazy && aAktualnyPocet < aPocet)
	{
		aPrikazy[aAktualnyPocet++] = prikaz;
		return true;
	}
	return false;
}

void TextMenu::zobraz()
{
	for (unsigned i = 0;i < aPocet && aPrikazy[i];i++)
		aPrikazy[i]->zobraz();
	aVystup.zobraz(string("\n\n"));
}

bool TextMenu::getPrikaz()
{
	char znak(aVstup.getChar());
	for (unsigned i = 0;i < aPocet && aPrikazy[i];i++)
	{
		if (aPrikazy[i]->jeHotKey(znak))
			return aPrikazy[i]->execute();
	}
	return true;
}

void TextMenu::skopirujPrikazy(const TextMenu & zdroj)
{
	for (unsigned i = 0;i < aPocet;i++)
	{
		if (zdroj.aPrikazy[i])
			aPrikazy[i] = zdroj.aPrikazy[i]->clone();
		else
			aPrikazy[i] = NULL;
	}
}

void TextMenu::spracujPrikaz(int id, int pozicia, char hotkey, string sprikaz, IReceiver * receiver)
{
	sprikaz = sprikaz.substr(0, pozicia) +
		"[" +
		sprikaz.substr(pozicia + 1, 1) +
		"]" +
		sprikaz.substr(pozicia + 2, sprikaz.length() - pozicia - 2);
	addCommand(sprikaz.c_str(), id, hotkey, receiver);
}


void TextMenu::start()
{
	do {
		zobraz();
	} while (getPrikaz());
}

