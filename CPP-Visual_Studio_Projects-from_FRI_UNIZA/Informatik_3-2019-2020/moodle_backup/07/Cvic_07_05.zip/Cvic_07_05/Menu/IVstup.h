#pragma once
class IVstup
{
public:
	virtual char getChar() = 0;
};

