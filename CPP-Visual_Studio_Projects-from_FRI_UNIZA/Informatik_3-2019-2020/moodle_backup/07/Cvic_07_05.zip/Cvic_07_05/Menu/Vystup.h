#pragma once
#include "IVystup.h"

class VertVystup :	public IVystup
{
public:
	virtual void zobraz(string text) override;
};

class HorzVystup : public IVystup
{
public:
	virtual void zobraz(string text) override;
};

