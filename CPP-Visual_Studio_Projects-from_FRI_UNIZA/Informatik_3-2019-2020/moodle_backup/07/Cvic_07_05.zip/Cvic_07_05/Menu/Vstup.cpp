#include <conio.h>
#include "Vstup.h"

char Vstup::getChar()
{
	return _getch();
}
