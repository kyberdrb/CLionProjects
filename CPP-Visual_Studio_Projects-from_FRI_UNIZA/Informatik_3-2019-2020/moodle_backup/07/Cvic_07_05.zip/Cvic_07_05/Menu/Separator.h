#pragma once
#include "TextCommand.h"

class VerticalSeparator :public TextCommand
{
public:
	VerticalSeparator(IVystup &vystup)
		: TextCommand("------------",vystup)
	{
	}

	virtual ICommand * clone() override;
};

class HorizontalSeparator :public TextCommand
{
public:
	HorizontalSeparator(IVystup &vystup)
		: TextCommand(" | ", vystup)
	{
	}

	virtual ICommand * clone() override;
};
