#pragma once

const int ID_NONE = -1;
const int ID_KONIEC = 0;
const int ID_USER = 1;

class ICommand
{
public:
	virtual bool execute() = 0;
	virtual void zobraz() = 0;
	virtual bool jeHotKey(char key) = 0;
	virtual ICommand *clone() = 0;
};

