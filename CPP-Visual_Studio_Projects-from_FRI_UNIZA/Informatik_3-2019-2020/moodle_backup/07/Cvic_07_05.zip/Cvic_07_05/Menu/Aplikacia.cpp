#include <cstdlib>

#include "Aplikacia.h"
#include "Vstup.h"
#include "Vystup.h" 
#include "HMenu.h"
#include "VMenu.h"

Aplikacia *Aplikacia::aAplik(NULL);


Aplikacia::Aplikacia()
	: aVstup(new Vstup),
	aVystup(new VertVystup),
	aStudent(new Student("Viliam", "Tavac", "Zilinska univerzita")),
	aSubmenu(new VMenu(ID_USER + 10, *aVstup, this, 1, "&Data")),
	aMenu(new HMenu(ID_USER, *aVstup, this, 4, "&Meno", "&Priezvisko", "&Skola", "#Info", aSubmenu))
{
}


Aplikacia::~Aplikacia()
{
	delete aMenu;
	delete aSubmenu;
	delete aStudent;
	delete aVystup;
	delete aVstup;
}

void Aplikacia::action(int id)
{
	switch (id)
	{
	case ID_USER: aVystup->zobraz(aStudent->meno()); break;
	case ID_USER + 1: aVystup->zobraz(aStudent->priezvisko()); break;
	case ID_USER + 2: aVystup->zobraz(aStudent->skola()); break;
	case ID_USER + 10:
		action(ID_USER);
		action(ID_USER + 1);
		action(ID_USER + 2);
		break;
	}
}
