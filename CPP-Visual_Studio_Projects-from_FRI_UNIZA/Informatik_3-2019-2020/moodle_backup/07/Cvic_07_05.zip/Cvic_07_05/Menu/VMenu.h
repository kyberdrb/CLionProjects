#pragma once
#include "TextMenu.h"
#include "IVstup.h"
#include "IReceiver.h"

class VMenu : public TextMenu
{
private:
	IVystup *aVystup;
public:
	VMenu(int startid, IVstup &vstup, IReceiver *receiver, unsigned pocet, ...);
	~VMenu();
};

