#pragma once
#include "IReceiver.h"
#include "IVstup.h"
#include "IVystup.h"
#include "TextMenu.h"
#include "Student.h"

class Aplikacia : public IReceiver
{
private:
	static Aplikacia *aAplik;

	IVstup *aVstup;
	IVystup *aVystup;
	Student *aStudent;
	TextMenu *aSubmenu;
	TextMenu *aMenu;

	Aplikacia();
	Aplikacia(const Aplikacia &zdroj) {}

public:
	~Aplikacia();

	// Inherited via IReceiver
	virtual void action(int id) override;

	static void start()
	{
		if (!aAplik)
			aAplik = new Aplikacia;
		aAplik->aMenu->start();
		delete aAplik;
		aAplik = NULL;
	}
};

