#include "KoniecCommand.h"

KoniecCommand::KoniecCommand(IVystup & vystup, IReceiver * receiver)
	:TextCommand("[K]oniec", vystup, ID_KONIEC, 'k', receiver)
{
}

bool KoniecCommand::execute()
{
	TextCommand::execute();
	return false;
}

ICommand * KoniecCommand::clone()
{
	return new KoniecCommand(*this);
}
