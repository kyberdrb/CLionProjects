#pragma once
#include "TextMenu.h"
#include "IVstup.h"
#include "IReceiver.h"

class HMenu : public TextMenu
{
private:
	IVystup *aVystup;
public:
	HMenu(int startid, IVstup &vstup, IReceiver *receiver, unsigned pocet, ...);
	~HMenu();
};

