#pragma once
#include<cstdlib>
#include "ICommand.h"
#include "IReceiver.h"
#include "IVystup.h"
#include "IVstup.h"

class TextMenu : public IReceiver
{
private:
	unsigned aPocet;
	ICommand **aPrikazy;
	IVystup &aVystup;
	IVstup &aVstup;

	unsigned aAktualnyPocet;

	bool addCommand(ICommand *prikaz);
	void zobraz();
	bool getPrikaz();
	void skopirujPrikazy(const TextMenu &zdroj);
protected:
	void spracujPrikaz(int id, int pozicia, char hotkey, string sprikaz, IReceiver *receiver);

public:
	TextMenu(unsigned pocet, IVystup &vystup, IVstup &vstup);
	
	TextMenu(const TextMenu &zdroj);
	TextMenu &operator =(const TextMenu &zdroj);

	~TextMenu();

	void start();
	bool addCommand(const char *text, int id = ID_NONE, char hotkey = '\0', IReceiver *receiver = NULL);
	bool addKoniecCommand(IReceiver *receiver = NULL);
	bool addVSeparator();
	bool addHSeparator();

	// Inherited via IReceiver
	virtual void action(int id) override;
};

