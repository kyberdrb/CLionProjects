#include <cctype>
#include "TextCommand.h"

TextCommand::TextCommand(const char * text, IVystup & vystup, int id, char hotkey, IReceiver * receiver)
	: aText(text), aVystup(vystup), aId(id), aHotKey(toupper(hotkey)), aReceiver(receiver)
{
}

bool TextCommand::execute()
{
	if (aReceiver)
		aReceiver->action(aId);
	return true;
}

void TextCommand::zobraz()
{
	aVystup.zobraz(aText);
}

bool TextCommand::jeHotKey(char key)
{
	return aHotKey == toupper(key);
}

ICommand * TextCommand::clone()
{
	return new TextCommand(*this);
}
