#pragma once
#include <string>
#include "ICommand.h"
#include "IReceiver.h"
#include "IVystup.h"

using namespace std;

class TextCommand : public ICommand
{
private:
	string aText;
	char aHotKey;
	int aId;
	IReceiver *aReceiver;
	IVystup &aVystup;

public: 
	TextCommand(const char *text, IVystup &vystup,
		int id = ID_NONE, char hotkey = '\0', IReceiver *receiver=NULL);

	// Inherited via ICommand
	virtual bool execute() override;
	virtual void zobraz() override;
	virtual bool jeHotKey(char key) override;

	// Inherited via ICommand
	virtual ICommand * clone() override;
};

