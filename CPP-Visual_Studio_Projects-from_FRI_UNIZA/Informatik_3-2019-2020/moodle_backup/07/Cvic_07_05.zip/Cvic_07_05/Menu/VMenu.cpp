#include <cstdarg>

#include "VMenu.h"
#include "Vystup.h"

VMenu::VMenu(int startid, IVstup & vstup, IReceiver * receiver, unsigned pocet, ...)
	: TextMenu(pocet + 2, *(aVystup = new VertVystup), vstup)
{
	va_list argptr;
	va_start(argptr, pocet);
	unsigned i(0);
	while (i < pocet)
	{
		char *prikaz = va_arg(argptr, char *);
		string sprikaz(prikaz);
		int pozicia = sprikaz.find('#');
		if (pozicia >= 0)
		{
			IReceiver *rec = va_arg(argptr, IReceiver *);
			spracujPrikaz(startid + i, pozicia, prikaz[pozicia + 1], sprikaz, rec);
		}
		else
		{
			pozicia = sprikaz.find('&');
			if (pozicia >= 0)
				spracujPrikaz(startid + i, pozicia, prikaz[pozicia + 1], sprikaz, receiver);
		}
		i++;
	}
	addVSeparator();
	addKoniecCommand(receiver);
	va_end(argptr);
}

VMenu::~VMenu()
{
	delete aVystup;
}
