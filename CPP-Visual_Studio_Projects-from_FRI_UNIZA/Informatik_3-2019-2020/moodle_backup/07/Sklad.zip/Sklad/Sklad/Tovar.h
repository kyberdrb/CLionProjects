#pragma once
#include <ostream>

char *kopiruj(const char *zdroj);

class Tovar
{
	char *nazov = nullptr;
	double cena = 0;
	int pocet = 0;
public:
	static int styp;

	Tovar()
	{
	}

	Tovar(const Tovar &zdroj)
		: nazov(zdroj.nazov), cena(zdroj.cena), pocet(zdroj.cena)
	{
	}

	Tovar &operator = (const Tovar &zdroj)
	{
		if (this != &zdroj)
		{
			delete[] nazov;
			nazov = kopiruj(zdroj.nazov);
			cena = zdroj.cena;
			pocet = zdroj.pocet;
		}
		return *this;
	}
	~Tovar()
	{
		delete[] nazov;
	}

	char *Nazov() { return nazov; }
	double Cena() { return cena; };
	int Pocet() { return pocet; }

	void Nazov(const char *pnazov) { nazov = kopiruj(pnazov); }
	void Cena(double pcena) { cena = pcena; };
	void Pocet(int ppocet) { pocet = ppocet; }

	friend std::ostream &operator <<(std::ostream &os, Tovar &h);
	friend bool operator <(Tovar &op1, Tovar &op2);
};

