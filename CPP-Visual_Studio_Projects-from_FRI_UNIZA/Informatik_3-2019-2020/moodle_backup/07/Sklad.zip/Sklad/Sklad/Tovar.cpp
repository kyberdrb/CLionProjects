#include "Tovar.h"
#include <cstring>

int Tovar::styp = 0;

char *kopiruj(const char *zdroj)
{
	if (zdroj && *zdroj)
	{
		int dlzka = strlen(zdroj);
		char *kopia = new char[dlzka + 1];
		strcpy(kopia, zdroj);
		return kopia;
	}
	return nullptr;
}

std::ostream& operator<<(std::ostream &os, Tovar& h)
{
	switch (Tovar::styp)
	{
	case 0:
		os << "Nazov: " << h.nazov << std::endl;
		os << "Pocet: " << h.pocet << std::endl;
		os << "Cena : " << h.cena << std::endl;
		break;
	case 1:
		os << "Cena : " << h.cena << std::endl;
		os << "Nazov: " << h.nazov << std::endl;
		os << "Pocet: " << h.pocet << std::endl;
		break;
	case 2:
		os << "Pocet: " << h.pocet << std::endl;
		os << "Nazov: " << h.nazov << std::endl;
		os << "Cena : " << h.cena << std::endl;
		break;
	}
	return os;
}

bool operator<(Tovar & op1, Tovar & op2)
{
	int ret = 0;
	int retnazov = strcmp(op1.Nazov(), op2.Nazov());
	int retcena = op1.Cena() - op2.Cena();
	int retpocet = op1.Pocet() - op2.Pocet();

	switch (Tovar::styp)
	{
	case 0:
		ret = retnazov;
		if (ret == 0)
		{
			ret = retcena;
			if (ret == 0)
				ret = retpocet;
		}
		break;
	case 1:
		ret = retcena;
		if (ret == 0)
		{
			ret = retnazov;
			if (ret == 0)
				ret = retpocet;
		}
		break;
	case 2:
		ret = retpocet;
		if (ret == 0)
		{
			ret = retnazov;
			if (ret == 0)
				ret = retcena;
		}
		break;
	}
	return ret > 0;
}
