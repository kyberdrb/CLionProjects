#include "Sklad.h"

int main()
{
	Sklad sklad;
	sklad.Pridaj("A", 10, 3);
	sklad.Pridaj("B", 100, 30);
	sklad.Pridaj("D", 10, 5);
	sklad.Pridaj("G", 1, 7);
	sklad.ZobrazPodlaNazov();
	sklad.ZobrazPodlaCena();
	sklad.ZobrazPodlaPocet();
	return 0;
}