#include "Sklad.h"
#include <cstring>
#include <cstdlib>
#include <iostream>

int PorovnajNazov(const void *p1, const void *p2)
{
	Tovar **ptrt1 = (Tovar **)p1;
	Tovar **ptrt2 = (Tovar **)p2;
	return *(*ptrt1)<*(*ptrt2);
}

int PorovnajCena(const void *p1, const void *p2)
{
	Tovar **ptrt1 = (Tovar **)p1;
	Tovar **ptrt2 = (Tovar **)p2;
	int ret = (*ptrt1)->Cena() - (*ptrt2)->Cena();
	if (ret == 0) {
		ret = strcmp((*ptrt1)->Nazov(), (*ptrt2)->Nazov());
		if (ret == 0)
			ret = (*ptrt1)->Pocet() - (*ptrt2)->Pocet();
	}
	return ret;
}


int PorovnajPocet(const void *p1, const void *p2)
{
	Tovar **ptrt1 = (Tovar **)p1;
	Tovar **ptrt2 = (Tovar **)p2;
	int ret = ret = (*ptrt1)->Pocet() - (*ptrt2)->Pocet();
	if (ret == 0) {
		ret = strcmp((*ptrt1)->Nazov(), (*ptrt2)->Nazov());
		if (ret == 0)
			(*ptrt1)->Cena() - (*ptrt2)->Cena();
	}
	return ret;
}

Tovar* Sklad::Realokuj()
{
	Tovar *pom = new Tovar[pocet + 1];
	if (zasoby)
	{
		for (int i = 0; i < pocet; i++)
		{
			pom[i] = zasoby[i];
		}
		delete[] zasoby;
	}
	pocet++;
	return pom;
}

void Sklad::Vypis(Tovar** tovary)
{
	for (int i = 0; i < pocet; i++)
		std::cout << *tovary[i] << std::endl;
}

Sklad::Sklad()
{
}


Sklad::~Sklad()
{
	delete[] zasoby;
}

void Sklad::Pridaj(const char* nazov, int cena, int ppocet)
{
	if (nazov && *nazov)
	{
		zasoby = Realokuj();
		zasoby[pocet - 1].Nazov(nazov);
		zasoby[pocet - 1].Cena(cena);
		zasoby[pocet - 1].Pocet(ppocet);
	}
}


void Sklad::VytvorPolePtr(Tovar**& ptrzasob)
{
	ptrzasob = new Tovar *[pocet];
	for (int i = 0; i < pocet; i++)
	{
		ptrzasob[i] = &zasoby[i];
	}
}

void Sklad::ZobrazSort(PorovnajFunPtr fun)
{
	Tovar** ptrzasob;
	VytvorPolePtr(ptrzasob);
	qsort(ptrzasob, pocet, sizeof(Tovar *), fun);
	Vypis(ptrzasob);
	delete[] ptrzasob;
}

void Sklad::ZobrazPodlaNazov()
{
	std::cout << "Podla nazov:" << std::endl << "------------" << std::endl;
	Tovar::styp = 0;
	ZobrazSort(PorovnajNazov);
}

void Sklad::ZobrazPodlaCena()
{
	std::cout << "Podla cena:" << std::endl << "------------" << std::endl;
	Tovar::styp = 1;
	ZobrazSort(PorovnajCena);
}

void Sklad::ZobrazPodlaPocet()
{
	std::cout << "Podla pocet:" << std::endl << "------------" << std::endl;
	Tovar::styp = 2;
	ZobrazSort(PorovnajPocet);
}
