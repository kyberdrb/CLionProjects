#pragma once
#include "Tovar.h"

typedef int(*PorovnajFunPtr)(const void *p1, const void *p2);

class Sklad
{
	Tovar *zasoby = nullptr;
	Tovar *Realokuj();
	void Vypis(Tovar **tovary);
	void ZobrazSort(PorovnajFunPtr fun);
	int pocet = 0;
public:
	Sklad();
	~Sklad();
	void Pridaj(const char *nazov, int cena, int pocet);
	void VytvorPolePtr(Tovar**& ptrzasob);
	void ZobrazPodlaNazov();
	void ZobrazPodlaCena();
	void ZobrazPodlaPocet();
};

