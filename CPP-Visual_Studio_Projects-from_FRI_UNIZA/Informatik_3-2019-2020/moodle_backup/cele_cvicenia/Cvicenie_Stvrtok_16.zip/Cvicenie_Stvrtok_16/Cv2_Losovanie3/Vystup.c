#include <stdio.h>
#include "Vystup.h"

void Vypis(MUINT pocetLosovanych)
{
	printf("\nVYSLEDOK ZREBOVANIA\n--------------------\n");
	for (MUINT i = 0;
		i < pocetLosovanych && i < PocetZrebov; i++)
	{
		printf("%3u. poradie:\t%c %05u\n",
			i + 1, Zreby[i].Kod, Zreby[i].Cislo);
	}
	printf("------------------------------------\n"
		"KONIEC\n");
}