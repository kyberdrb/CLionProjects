#pragma once
#include "Data.h"

// nahodne vyberie dany pocet zrebov
void Losuj(MUINT pocetLosovanychZrebov);