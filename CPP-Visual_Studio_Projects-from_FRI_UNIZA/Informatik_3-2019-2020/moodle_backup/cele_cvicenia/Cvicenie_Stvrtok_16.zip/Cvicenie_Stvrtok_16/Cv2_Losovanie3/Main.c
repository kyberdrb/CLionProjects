//#include "Test.h"
#include <stdio.h>
#include <stdlib.h>
#include "Loteria.h"

int main(int argc, char* argv[])
{
	if (argc == 3)
	{
		PocetZrebov = atoi(argv[2]);
		Tah(atoi(argv[1]));
	}
	else {
		printf("CHYBNY POCET PARAMETROV!\n");
	}

	//PocetZrebov = 10;
	//BOOL ok = Testuj();
	printf("pre koniec stlac ENTER\n");
	getchar();
	return 0;
}