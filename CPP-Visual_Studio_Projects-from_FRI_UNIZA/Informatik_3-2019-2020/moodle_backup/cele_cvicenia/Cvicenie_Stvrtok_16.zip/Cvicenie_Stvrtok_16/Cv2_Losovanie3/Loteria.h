#pragma once
#include "Data.h"

void Tah(MUINT pocetLosovanychZrebov);
