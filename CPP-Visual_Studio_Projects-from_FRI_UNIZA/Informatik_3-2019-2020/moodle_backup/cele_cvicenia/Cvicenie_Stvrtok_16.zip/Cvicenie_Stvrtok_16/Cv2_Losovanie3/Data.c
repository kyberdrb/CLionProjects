#include <malloc.h>

#include "Data.h"

MUINT PocetZrebov;
struct Zreb* Zreby;

void PripravZreby()
{
	if (PocetZrebov > 0)
	{
		Zreby = malloc(PocetZrebov * sizeof(struct Zreb));
		if (Zreby != NULL)
		{
			for (MUINT i = 0; i < PocetZrebov; i++)
			{
				Zreby[i].Cislo = i + 1;
				Zreby[i].Kod = 'A' + (i % 26);
			}
		}
	}
}

void ZrusZreby()
{
	if (Zreby != NULL)
		free(Zreby);
	Zreby = NULL;
}