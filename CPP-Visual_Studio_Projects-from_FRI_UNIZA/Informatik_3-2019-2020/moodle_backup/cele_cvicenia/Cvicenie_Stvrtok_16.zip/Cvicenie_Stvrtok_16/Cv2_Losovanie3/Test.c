#include "Test.h"

BOOL Testuj()
{
	PripravZreby();
	if (Zreby[3].Cislo == 4)
		return TRUE;

	return FALSE;
}