#pragma once
#ifdef WINDOWS
typedef unsigned int MUINT;
#else
typedef unsigned long MUINT;
#endif

typedef unsigned short BOOL;

enum { FALSE, TRUE };

struct Zreb
{
	char Kod;
	MUINT Cislo;
};

extern MUINT PocetZrebov;
extern struct Zreb* Zreby;

// vytvori pole zrebov a incializuje jeho prvky
void PripravZreby();
// uvolni pole zreby z pamate
void ZrusZreby();