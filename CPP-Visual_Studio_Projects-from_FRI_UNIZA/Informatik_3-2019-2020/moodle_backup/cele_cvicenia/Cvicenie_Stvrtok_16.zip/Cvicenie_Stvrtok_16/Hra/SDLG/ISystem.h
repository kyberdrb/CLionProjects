#pragma once
#include <string>
using namespace std;
class ISystem
{
public:
	virtual ~ISystem(){}

	virtual int Sirka() = 0;
	virtual int Vyska() = 0;
	virtual ISystem* CitajBMP(const char* menoSuboru) = 0;
	virtual void Uvolni(ISystem* grafickyObjekt) = 0;
	virtual void Zobraz(ISystem& grafickyObjekt, int x, int y) = 0;
	virtual bool Vstup(int& x, int& y) = 0;
	virtual int Cas() = 0;
	virtual void Zmaz() = 0;
	virtual void Update() = 0;
	virtual void ZobrazText(string stext) = 0;
};

