#pragma once
#include "IObjekt.h"

class PohyblivyObjekt : public IObjekt
{
private:
	int aCasPoslednejZmeny, aInterval;
	int aDeltaX, aDeltaY;
	int aSirkaPlochy, aVyskaPlochy;
	int Generuj(int zaciatok, int koniec);
protected:
	int aX = 0, aY = 0;
	int aSirka = 0, aVyska = 0;
	virtual void Reset();
public:
	PohyblivyObjekt(int sirkaPlochy, int vyskaPlochy);
	~PohyblivyObjekt();


	// Inherited via IObjekt
	virtual bool AktualizujSa(int pCas) override;
	virtual bool Zasah(int x, int y) override;

};

