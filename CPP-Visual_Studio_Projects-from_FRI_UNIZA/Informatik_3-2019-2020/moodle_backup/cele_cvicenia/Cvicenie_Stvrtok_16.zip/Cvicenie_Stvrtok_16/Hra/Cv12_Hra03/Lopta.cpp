#include "ISystem.h"
#include "Lopta.h"

Lopta::Lopta(ISystem* hraciaPlocha)
	:PohyblivyObjekt(hraciaPlocha ? hraciaPlocha->Sirka() : 0,
		hraciaPlocha ? hraciaPlocha->Vyska() : 0),
	aLopta(nullptr), aHraciaPlocha(hraciaPlocha)
{
	if (aHraciaPlocha)
		aLopta = aHraciaPlocha->CitajBMP("ball.bmp");
	if (aLopta)
	{
		aSirka = aLopta->Sirka();
		aVyska = aLopta->Vyska();
		Reset();
	}
}

Lopta::~Lopta()
{
	if (aHraciaPlocha && aLopta)
		aHraciaPlocha->Uvolni(aLopta);
}

void Lopta::ZobrazSa()
{
	if (aHraciaPlocha && aLopta)
		aHraciaPlocha->Zobraz(*aLopta, aX, aY);
}

int Lopta::DajBody()
{
	return 1;
}
