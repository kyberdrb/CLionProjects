#pragma once
class IObjekt
{
public:
	virtual ~IObjekt(){}

	virtual void ZobrazSa() = 0;
	virtual bool AktualizujSa(int pCas) = 0;
	virtual int DajBody() = 0;
	virtual bool Zasah(int x, int y) = 0;
};

