#pragma once
#include "IEngine.h"

class IObjekt;
class ISystem;

class Engine : public IEngine
{
private:
	int aSkore = 0;
	ISystem* aHraciaPlocha = nullptr;
	IObjekt* aObjekt = nullptr;

	void ZobrazSkore();
	void Aktualizuj();
	void SpracujVstup(int x, int y);
public:
	Engine(ISystem* hraciaPlocha, IObjekt* objekt);
	~Engine();

	// Inherited via IEngine
	virtual void Start() override;

};

