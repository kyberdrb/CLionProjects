#include <sstream>
#include "Engine.h"
#include "ISystem.h"
#include "IObjekt.h"

using namespace std;

void Engine::ZobrazSkore()
{
	if (aHraciaPlocha)
	{
		stringstream sts;
		sts << aSkore;
		aHraciaPlocha->ZobrazText(
			string("Skore: ") + sts.str());
	}
}

void Engine::Aktualizuj()
{
}

void Engine::SpracujVstup(int x, int y)
{
}

Engine::Engine(ISystem* hraciaPlocha, IObjekt* objekt)
{
}

Engine::~Engine()
{
}

void Engine::Start()
{
}
