#include <cstdlib>
#include "PohyblivyObjekt.h"

const int DELTA = 10;
const int INTERVAL = 20;

int PohyblivyObjekt::Generuj(int zaciatok, int koniec)
{
	if (zaciatok == koniec) koniec++;
	if (zaciatok > koniec)
	{
		int pom = zaciatok;
		zaciatok = koniec;
		koniec = pom;
	}
	return rand() % (koniec - zaciatok) + zaciatok;
}

void PohyblivyObjekt::Reset()
{
	aX = Generuj(0, aSirkaPlochy - aSirka);
	aY = Generuj(0, aVyskaPlochy - aVyska);
	aDeltaX = Generuj(-DELTA / 2, DELTA / 2);
	aDeltaY = Generuj(-DELTA / 2, DELTA / 2);
	aInterval = Generuj(INTERVAL, 5 * INTERVAL);
}

PohyblivyObjekt::PohyblivyObjekt(int sirkaPlochy, int vyskaPlochy)
	:aSirkaPlochy(sirkaPlochy), aVyskaPlochy(vyskaPlochy),
	aCasPoslednejZmeny(0), aInterval(0),
	aDeltaX(0), aDeltaY(0)
{
}

PohyblivyObjekt::~PohyblivyObjekt()
{
}

bool PohyblivyObjekt::AktualizujSa(int pCas)
{
	if (pCas - aCasPoslednejZmeny > aInterval)
	{
		aX += aDeltaX;
		if (aX <= 0 || aX >= aSirkaPlochy - aSirka)
		{
			aDeltaX = -aDeltaX;
			aX += aDeltaX;
		}
		aY += aDeltaY;
		if (aY <= 0 || aY >= aVyskaPlochy - aVyska)
		{
			aDeltaY = -aDeltaY;
			aY += aDeltaY;
		}
		return true;
	}
	return false;
}

bool PohyblivyObjekt::Zasah(int x, int y)
{
	bool zasah = x >= aX && x <= (aX + aSirka) &&
		y >= aY && y <= (aY + aVyska);
	if (zasah) Reset();
	return zasah;
}
