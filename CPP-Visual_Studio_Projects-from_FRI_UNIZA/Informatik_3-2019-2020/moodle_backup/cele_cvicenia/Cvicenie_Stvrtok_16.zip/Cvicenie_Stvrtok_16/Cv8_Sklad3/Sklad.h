#pragma once
#include "Tovar.h"

typedef int(*PorovnajFunPtr)(const void* p1, const void* p2);

class Sklad
{
	Tovar* aZasoby = nullptr;
	int aPocet = 0;

	Tovar* Realokuj();
	void VytvorPolePtr(Tovar**& zasobyPtr);
	void Vypis(Tovar** zasobyPtr);
	void ZobrazSort(PorovnajFunPtr fun);
public:
	Sklad();
	//Sklad(const Sklad& zdroj){/*dorobit*/ }
	//Sklad& operator =(const Sklad& zdroj) {/*dorobit*/ return *this; }
	~Sklad();
	
	void Pridaj(const char* nazov, double cena, int pocet);
	void ZobrazPodlaNazov();
	void ZobrazPodlaCena();
	void ZobrazPodlaPocet();


};

