#include "Sklad.h"

int main() 
{
	Sklad sklad;
	sklad.Pridaj("E", 14.80, 200);
	sklad.Pridaj("A", 10, 10);
	sklad.Pridaj("E", 5, 5);
	sklad.Pridaj("W", 20, 4);
	sklad.Pridaj("C", 20, 40);
	sklad.ZobrazPodlaNazov();
	sklad.ZobrazPodlaCena();
	sklad.ZobrazPodlaPocet();

	Sklad skladkopia;
	//skladkopia = sklad;

	return 0;
}