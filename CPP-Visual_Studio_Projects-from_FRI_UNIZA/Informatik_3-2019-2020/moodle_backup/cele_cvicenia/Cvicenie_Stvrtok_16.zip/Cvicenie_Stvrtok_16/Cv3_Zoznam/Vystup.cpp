#include "Vystup.h"

Vystup::Vystup(const char* menosuboru)
{
	if (menosuboru && *menosuboru) //!='\0'
	{
		aHandle = fopen(menosuboru, "wt"); //mod write text file
	}
}

Vystup::~Vystup()
{
	if (aHandle != nullptr)
		fclose(aHandle);
}

void Vystup::ZapisCislo(int cislo)
{
	if (aHandle)
		fprintf(aHandle, "%d\n", cislo);
	else
		printf("%d\n", cislo);
}
