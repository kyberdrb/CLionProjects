#include "Testy.h"
#include "Zoznam.h"

bool Testy::Testuj()
{
	Zoznam zoznam;

	zoznam.Sort("data.txt", Porovnaj);
	zoznam.Uloz("usporiadany.txt");
	zoznam.Uloz(nullptr);
	return true;
}
