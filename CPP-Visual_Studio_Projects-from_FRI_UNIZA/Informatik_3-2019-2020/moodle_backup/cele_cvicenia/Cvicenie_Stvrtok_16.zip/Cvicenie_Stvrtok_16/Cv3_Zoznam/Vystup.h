#pragma once
#include <cstdio>

class Vystup
{
private:
	FILE* aHandle = nullptr;
public:
	Vystup(const char* menosuboru); // ak meno existuje, bude zapis do suboru, inak na konzolu 
	~Vystup();

	void ZapisCislo(int cislo);
};

