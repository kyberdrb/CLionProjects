#pragma once
#include <cstdio>

class Vstup
{
private:
	FILE* aHandle; // popisovac suboru
public:
	Vstup(const char* menosuboru); //parametricky konstruktor
	~Vstup(); //destruktor

	int CitajCislo();
};

