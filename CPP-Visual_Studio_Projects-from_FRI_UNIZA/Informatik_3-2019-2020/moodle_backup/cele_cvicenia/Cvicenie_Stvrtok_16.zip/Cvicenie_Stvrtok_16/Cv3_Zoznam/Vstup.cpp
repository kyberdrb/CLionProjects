#include "Vstup.h"

Vstup::Vstup(const char* menosuboru)
{
	aHandle = nullptr;
	if (menosuboru != nullptr && *menosuboru != 0) //!='\0'
	{
		aHandle = fopen(menosuboru, "rt"); //mod read text file
	}
}

Vstup::~Vstup()
{
	if (aHandle != nullptr)
		fclose(aHandle);
}

int Vstup::CitajCislo()
{
	if (aHandle)
	{
		if (!feof(aHandle))
		{
			int cislo;
			fscanf(aHandle, "%d", &cislo);
			return cislo;
		}
	}
	return 0;
}
