//#define TESTY
#include <cstdio>

#ifdef _DEBUG
#include "Testy.h"
#endif // _DEBUG

int main()
{
	bool ok = true;
#ifdef _DEBUG
	ok = Testy().Testuj();
#endif // _DEBUG
	if (ok)
		; // rozumny beh aplikacie
	else
		printf("CHYBA!!!\n");
	return 0;
}