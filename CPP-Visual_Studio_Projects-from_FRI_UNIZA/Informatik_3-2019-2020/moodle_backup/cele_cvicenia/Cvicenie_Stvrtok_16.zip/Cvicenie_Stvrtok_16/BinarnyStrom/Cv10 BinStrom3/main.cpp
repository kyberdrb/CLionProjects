#include "Strom.h"
int main()
{
	Strom* strom = new Strom;
	strom->Vloz(20);
	strom->Vloz(10);
	strom->Vloz(15);
	strom->Vloz(-20);
	strom->Vloz(-10);
	strom->Vloz(-200);
	strom->Vloz(10);
	strom->Vloz(0);
	strom->Vloz(-2);
	strom->Vloz(2);
	strom->Vypis();

	delete strom;
	//strom->~Strom();

	return 0;
}