#pragma once
//class Uzol;

class Strom
{
	class Uzol
	{
	public:
		Uzol() {}
		Uzol(int data, Uzol* lavy = nullptr, Uzol* pravy = nullptr)
			:aData(data), aLavy(lavy), aPravy(pravy) {}
		~Uzol() {}

		int Data() { return aData; }
		inline Uzol* Lavy();
		inline Uzol* Pravy();

		void Data(int data) { aData = data; }
		void Lavy(Uzol* lavy) { aLavy = lavy; }
		void Pravy(Uzol* pravy) { aPravy = pravy; }
	private:
		int aData = 0;
		Uzol* aLavy = nullptr;
		Uzol* aPravy{};
	} *aKoren{};

	void ZrusStrom(Uzol* uzol);
	void Vloz(int data, Uzol* uzol);
	void Vypis(Uzol* uzol);
public:
	Strom() = default;
	~Strom() { ZrusStrom(aKoren); aKoren = nullptr; }
	void Vloz(int data);
	void Vypis();
};

inline Strom::Uzol* Strom::Uzol::Lavy() { return aLavy; }
inline Strom::Uzol* Strom::Uzol::Pravy() { return aPravy; }