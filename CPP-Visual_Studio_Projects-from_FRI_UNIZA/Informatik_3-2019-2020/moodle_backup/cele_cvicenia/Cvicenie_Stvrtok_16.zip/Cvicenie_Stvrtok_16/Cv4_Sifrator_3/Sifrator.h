#pragma once

class Sifrator
{
private:
	//Typ po�adovanej �innosti : s � �ifrovanie, d � de�ifrovanie, h � help
	char aCinnost;
	//	Heslo : max. 8 znakov
	char* aHeslo;
	//	Indik�tor v�pisu na konzolu(napr.znak c)
	bool aKonzola;
	//	Meno(vr�tane cesty) vstupn�ho s�boru
	char* aVstupSubor;
	//	Meno(vr�tane cesty) v�stupn�ho s�boru
	char* aVystupSubor;

	void VypisHelp();
	void Init(char cinnost, const char* heslo, bool konzola,
		const char* vstupSubor, const char* vystupSubor);
	void Zmaz();
public:
	Sifrator(char cinnost, const char* heslo, bool konzola,
		const char* vstupSubor, const char* vystupSubor);
	Sifrator(const Sifrator& zdroj);
	Sifrator& operator =(const Sifrator& zdroj);

	~Sifrator();

	void Start();
};

