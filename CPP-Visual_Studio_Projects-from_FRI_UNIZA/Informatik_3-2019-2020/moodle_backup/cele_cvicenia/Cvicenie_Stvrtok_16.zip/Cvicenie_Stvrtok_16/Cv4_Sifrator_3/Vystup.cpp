#include <cstdio>
#include <cstring>
#include "Vystup.h"
#include "helper.h"

Vystup::Vystup(const char* menoSuboru)
{
	aMenoSuboru = AlokujKopiruj(menoSuboru);
}

Vystup::Vystup(const Vystup& zdroj)
{
	aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
}

Vystup& Vystup::operator=(const Vystup& zdroj)
{
	if (this != &zdroj)
	{
		delete[] aMenoSuboru;
		aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
	}
	return *this;
}

Vystup::~Vystup()
{
	delete[] aMenoSuboru;
}

void Vystup::Zapis(const unsigned char* text)
{
	if (aMenoSuboru && *aMenoSuboru)
	{
		FILE* f{ fopen(aMenoSuboru, "wb") };
		if (f)
		{
			int dlzka = strlen((char*)text);
			fwrite(text, dlzka, 1, f);
			fclose(f);
		}
	}
	else
		printf("%s\n", text);
}

