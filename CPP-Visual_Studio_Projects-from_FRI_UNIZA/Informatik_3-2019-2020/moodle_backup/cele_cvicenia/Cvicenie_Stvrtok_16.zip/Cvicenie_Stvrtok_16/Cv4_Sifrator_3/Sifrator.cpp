#include "Vystup.h"
#include "Sifrator.h"
#include "helper.h"
#include "Vstup.h"
#include "Koder.h"

void Sifrator::VypisHelp()
{
	Vystup(nullptr).Zapis((unsigned char*)
		"Cv4_Sifrator_3 CINNOST HESLO VSTUP_SUBOR [TYP_VYSTUPU VYSTUP_SUBOR]\n"
		"   CINNOST:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...help\n"
		"   TYP_VYSTUPU:\n"
		"      s...subor\n"
		"      c...konzola\n\n");

}

void Sifrator::Init(char cinnost, const char* heslo,
	bool konzola, const char* vstupSubor, const char* vystupSubor)
{
	aCinnost = cinnost;
	aHeslo = AlokujKopiruj(heslo);
	aKonzola = konzola;
	aVstupSubor = AlokujKopiruj(vstupSubor);
	aVystupSubor = aKonzola ? nullptr : AlokujKopiruj(vystupSubor);
}

void Sifrator::Zmaz()
{
	delete[] aVstupSubor;
	delete[] aVystupSubor;
	delete[] aHeslo;
	//delete[] aHeslo; // toto padne. Pomohlo by nulovanie smernika po prvom delete[]: aHeslo = nullptr;
}

Sifrator::Sifrator(char cinnost, const char* heslo,
	bool konzola, const char* vstupSubor, const char* vystupSubor)
{
	Init(cinnost, heslo, konzola, vstupSubor, vystupSubor);
}

Sifrator::Sifrator(const Sifrator& zdroj)
{
	Init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aKonzola,
		zdroj.aVstupSubor, zdroj.aVystupSubor);
}

Sifrator& Sifrator::operator=(const Sifrator& zdroj)
{
	if (this != &zdroj)
	{
		Zmaz();
		Init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aKonzola,
			zdroj.aVstupSubor, zdroj.aVystupSubor);
	}
	return *this;
}

Sifrator::~Sifrator()
{
	Zmaz();
}

void Sifrator::Start()
{
	if (aCinnost == 'h')
		VypisHelp();
	else
	{
		Vstup zdroj(aVstupSubor);
		char* zdrojText = (char*)zdroj.Citaj();
		if (zdrojText)
		{
			char* cielText{ nullptr };
			Koder koder;
			if (aCinnost == 's')
				cielText = koder.Koduj(aHeslo,
				(unsigned char*)zdrojText);
			else
				cielText = (char*)koder.Dekoduj(aHeslo, zdrojText);
			if (cielText)
			{
				Vystup vystup(aVystupSubor);
				vystup.Zapis((unsigned char*)cielText);
				delete[] cielText;
			}
			delete[] zdrojText;
		}
	}
}
