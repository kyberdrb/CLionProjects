//#include "Test.h"
#include "Sifrator.h"

int main(int argc, char* argv[])
{
	char cinnost{ 'h' };
	char* heslo{ nullptr };
	char* vstupSubor{ nullptr };
	bool konzola{ true };
	char* vystupSubor(nullptr);
	if (argc > 1)
		cinnost = argv[1][0];
	if (argc > 2)
		heslo = argv[2];
	if (argc > 3)
		vstupSubor = argv[3];
	if (argc > 4)
		konzola = argv[4][0] == 'c';
	if (argc > 5)
		vystupSubor = argv[5];

	Sifrator sifrator(cinnost, heslo, konzola, vstupSubor, vystupSubor);
	sifrator.Start();
	
	//Test t;
	//t.start();
	return 0;
}