#include <cstdio>
#include "Koder.h"

char* Koder::Koduj(const char* pheslo,
	const unsigned char* ptext)
{
	if (ptext && *ptext)
	{
		PripravTabulku(pheslo);
		int dlzkaTextu = strlen((char*)ptext);
		unsigned char* kodText = new unsigned char[dlzkaTextu]; //pole znakov, nie retazec
		if (kodText)
		{
			for (int i = 0; i < dlzkaTextu; i++)
				kodText[i] = aKodTabulka[ptext[i]];
			char* sifrText = new char[dlzkaTextu * 3 + 1];
			if (sifrText)
			{
				int k = 0; // int k(0); // int k{0};
				for (int i = 0; i < dlzkaTextu; i++)
				{
					char ciskod[4];
					sprintf(ciskod, "%03u", kodText[i]);
					memmove(&sifrText[k], ciskod, 3);
					k += 3;
				}
				sifrText[k] = '\0';
				delete[] kodText;
				return sifrText;
			}
		}
	}
	return nullptr;
}

unsigned char* Koder::Dekoduj(const char* pheslo, const char* sifrText)
{
	if (sifrText && *sifrText)
	{
		PripravTabulku(pheslo);
		DekodujTabulku();
		int dlzkaTextu = strlen(sifrText);
		unsigned char* kodText = new unsigned char[dlzkaTextu / 3];
		if (kodText)
		{
			char ciskod[4]{};
			int k(0), i(0);
			while (i < dlzkaTextu)
			{
				memmove(ciskod, &sifrText[i], 3);
				kodText[k++] = (unsigned char)atoi(ciskod);
				i += 3;
			}
			unsigned char* desifrovanyText = new unsigned char[k + 1];
			if (desifrovanyText)
			{
				for (int i = 0; i < k; i++)
					desifrovanyText[i] =
					aKodTabulka[kodText[i]];
				desifrovanyText[k] = '\0';
				delete[] kodText;
				return desifrovanyText;
			}
		}
	}
	return nullptr;
}
