#pragma once

#include "Koder.h"

class Test
{
public:
	bool start()
	{
		Koder k;
		char* zakodovanyText = k.Koduj("abcdef4", (unsigned char*)"stvrtok 16:00");
		unsigned char* dekodovanyText =
			k.Dekoduj("abcdef4", zakodovanyText);
		delete[] dekodovanyText;
		delete[] zakodovanyText;
		return true;
	}
};

