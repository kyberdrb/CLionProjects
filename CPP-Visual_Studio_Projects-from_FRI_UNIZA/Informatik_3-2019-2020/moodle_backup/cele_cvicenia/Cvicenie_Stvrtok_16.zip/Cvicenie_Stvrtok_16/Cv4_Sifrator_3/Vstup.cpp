#include <cstdio>
#include "Vstup.h"
#include "helper.h"

int Vstup::DlzkaSuboru()
{
	FILE* f{ fopen(aMenoSuboru, "rb") };//citaj binarny subor
	if (f)
	{
		fseek(f, 0, SEEK_END);
		int dlzka = ftell(f);
		fclose(f);
		return dlzka;
	}
	return 0;
}

Vstup::Vstup(const char* menoSuboru)
{
	aMenoSuboru = AlokujKopiruj(menoSuboru);
}

Vstup::Vstup(const Vstup& zdroj)
{
	aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
}

Vstup& Vstup::operator=(const Vstup& zdroj)
{
	if (this != &zdroj)
	{
		delete[] aMenoSuboru;
		aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
	}
	return *this;
}

Vstup::~Vstup()
{
	delete[] aMenoSuboru;
}

unsigned char* Vstup::Citaj()
{
	int dlzka = DlzkaSuboru();
	if (dlzka > 0)
	{
		unsigned char* text = new unsigned char[dlzka + 1];
		FILE* f = fopen(aMenoSuboru, "rb");
		fread(text, dlzka, 1, f);
		text[dlzka] = '\0';
		fclose(f);
		return text;
	}
	return nullptr;
}
