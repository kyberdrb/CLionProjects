#pragma once
#include <cstdlib>
#include "Heslo.h"

const int DLZKA_TABULKY = 256;

class Koder
{
private:
	unsigned char aKodTabulka[DLZKA_TABULKY] = {};

	unsigned DajNasadu(const char* pheslo)
	{
		Heslo h(pheslo);
		return h.DajNasadu1();
	}

	void NaplnTabulku()
	{
		for (int i = 0; i < DLZKA_TABULKY; i++)
			aKodTabulka[i] = i;
	}

	void Vymen(unsigned char& a, unsigned char& b)
	{
		unsigned char c(a);
		a = b;
		b = c;
	}

	void ZakodujTabulku(const char* pheslo)
	{
		unsigned int nasada = DajNasadu(pheslo);
		srand(nasada);
		for (int i = 0; i < DLZKA_TABULKY; i++)
		{
			int index = rand() % (DLZKA_TABULKY - i);
			Vymen(aKodTabulka[index],
				aKodTabulka[DLZKA_TABULKY - 1 - i]);
		}
	}

	void PripravTabulku(const char* pheslo)
	{
		NaplnTabulku();
		ZakodujTabulku(pheslo);
	}

	void DekodujTabulku()
	{
		unsigned char pom[DLZKA_TABULKY];
		for (int i = 0; i < DLZKA_TABULKY; i++)
			pom[aKodTabulka[i]] = i;
		for (int i = 0; i < DLZKA_TABULKY; i++)
			aKodTabulka[i] = pom[i];
	}

public:
	char* Koduj(const char* pheslo,
		const unsigned char* ptext);
	unsigned char* Dekoduj(const char* pheslo,
		const char* sifrText);

};

