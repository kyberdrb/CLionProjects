#pragma once
class Vystup;

class Binary
{
	//char aCislo[66];
	long long aCislo = 0;
	long long Bin2Dec(const char* bcislo);
	char* Dec2Bin(const long long cislo);
public:
	Binary(long long pcislo) :aCislo(pcislo) {}
	Binary(const char* bcislo=nullptr) :aCislo(Bin2Dec(bcislo)) {}
	void Vypis(Vystup &v);

	friend Binary operator +(Binary op1, Binary op2);
	friend bool operator ==(Binary op1, Binary op2);
	friend bool operator !=(Binary op1, Binary op2);
};

inline Binary operator +(Binary op1, Binary op2)
{
	return op1.aCislo + op2.aCislo;
}
inline bool operator ==(Binary op1, Binary op2)
{
	return op1.aCislo == op2.aCislo;
}
inline bool operator !=(Binary op1, Binary op2)
{
	return !(op1 == op2);
}
