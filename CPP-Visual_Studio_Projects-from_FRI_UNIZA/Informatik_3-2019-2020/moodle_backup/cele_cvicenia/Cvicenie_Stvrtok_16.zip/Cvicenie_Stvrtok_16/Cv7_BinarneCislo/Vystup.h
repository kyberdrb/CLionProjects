#pragma once
class Vystup
{
private:
	char* aMenoSuboru = nullptr;
public:
	Vystup(const char* menoSuboru);
	Vystup(const Vystup& zdroj);
	Vystup& operator =(const Vystup& zdroj);
	~Vystup();
	//zapis do suboru/na konzolu
	void Zapis(const unsigned char* text);

};

