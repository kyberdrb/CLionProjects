#include "Binary.h"
#include "Vystup.h"

int main()
{
	Binary a("1101"), b("111101"), c("-1x32c0"), d(8), e, f, g;
	// Error	C2668	'Binary::Binary': ambiguous call to overloaded function
	// prekladac nevie, ktory z konverznych konstruktorov ma pouzit pre vytvorenie objektov e,f,g.
	// Treba v jednom zrusit implicitnu hodnotu
	e = a + d;
	f = a + 10;
	g = 10 + b;
	Vystup v(nullptr);
	e.Vypis(v);
	f.Vypis(v);
	g.Vypis(v);
	//g = f / e;
	Vystup subor("binary.txt");
	g.Vypis(subor);

}
