#include <iostream>
#include "Strom.h"

Strom::Uzol::Uzol(int pdata, Uzol* plavy, Uzol* ppravy)
	: data(pdata), lavy(plavy), pravy(ppravy)
{
}

void Strom::ZrusStrom()
{
}


void Strom::Vloz(int pdata, Uzol* uzol)
{
	if (pdata < uzol->Data())
	{
		// Idem vlavo
		if (uzol->Lavy() != nullptr)
			Vloz(pdata, uzol->Lavy());
		else
			uzol->Lavy(new Uzol(pdata));
	}
	else
	{
		// Idem vpravo
		if (uzol->Pravy() != nullptr)
			Vloz(pdata, uzol->Pravy());
		else
			uzol->Pravy(new Uzol(pdata));
	}
}

void Strom::Vypis(Uzol* uzol)
{
	if (uzol != nullptr)
	{
		Vypis(uzol->Lavy());
		std::cout << uzol->Data() << std::endl;
		Vypis(uzol->Pravy());
	}
}

void Strom::Vloz(int pdata)
{
	if (koren)
		Vloz(pdata, koren);
	else
		koren = new Uzol(pdata);
}
