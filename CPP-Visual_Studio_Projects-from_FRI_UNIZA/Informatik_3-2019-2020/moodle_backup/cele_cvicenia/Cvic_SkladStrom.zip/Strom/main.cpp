#include "Strom.h"

int main()
{
	Strom s;
	s.Vloz(10);
	s.Vloz(8);
	s.Vloz(5);
	s.Vloz(12);
	s.Vypis();
	return 0;
}