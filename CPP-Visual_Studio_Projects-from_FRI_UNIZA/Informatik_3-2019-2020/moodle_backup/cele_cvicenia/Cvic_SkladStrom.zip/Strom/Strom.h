#pragma once
class Strom
{
private:
	class Uzol {
		int data = 0;
		Uzol* lavy = nullptr;
		Uzol* pravy = nullptr;
	public:
		Uzol(int pdata, Uzol* plavy = nullptr, Uzol* ppravy = nullptr);
		int Data() { return data; }
		Uzol* Lavy() { return lavy; }
		Uzol* Pravy() { return pravy; };

		void Data(int pdata) { data = pdata; }
		void Lavy(Uzol* puzol) { lavy = puzol; }
		void Pravy(Uzol* puzol) { pravy = puzol; };
	}*koren = nullptr;

	void Vloz(int pdata, Uzol* uzol);
	void Vypis(Uzol* uzol);

public:
	Strom() :koren(nullptr) {}
	virtual ~Strom() { ZrusStrom(); }
	void ZrusStrom();
	void Vloz(int pdata);
	void Vypis() { Vypis(koren); }
};

