#include <iostream>
#include "Testy.h"

bool Testy::Start()
{
	Sklad& s = Sklad::GetSklad();

	s.Pridaj("Jablko", 20, 100);
	s.Pridaj("Hruska", 15, 200);
	s.Pridaj("Slivka", 50, 3);

	s.ZobrazPodlaNazov();
	s.ZobrazPodlaCena();
	s.ZobrazPodlaPocet();

	Tovar t1;
	Tovar t2;
	Tovar t3;

	t1.Nazov("auto");
	t1.Cena(9999.90);
	t1.Pocet(5);

	t2.Nazov("bicykel");
	t2.Cena(999.90);
	t2.Pocet(10);

	t3.Nazov("cukriky");
	t3.Cena(99.90);
	t3.Pocet(20);

	std::cout << t1 << std::endl << t2 << std::endl << t3 << std::endl;
	std::cout << (t1 < t2) << std::endl;

	Tovar::styp = 1;
	std::cout << (t1 < t2) << std::endl;

	Tovar::styp = 2;
	std::cout << (t1 < t2) << std::endl;

	Tovar::styp = 2;
	std::cout << (t3 < t2) << std::endl;


	return true;
}
