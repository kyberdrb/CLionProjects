#define TESTY
#include <cstdio>

#ifdef TESTY
#include "Testy.h"
#endif

#include "Sklad.h"

int main()
{
	bool OK = true;
#ifdef TESTY
	OK = Testy().Start();
#endif

	if (OK)
		;
	else
		printf("Nepresli testy!\n");
	return 0;
}