#include "Tovar.h"

 int Tovar::styp = 0;

Tovar& Tovar::operator=(const Tovar& zdroj)
{
	if (this != &zdroj)
	{
		delete[] nazov;
		nazov = kopiruj(zdroj.nazov);
		cena = zdroj.cena;
		pocet = zdroj.pocet;
	}
	return *this;
}

Tovar::~Tovar()
{
	delete[] nazov;
}

char* kopiruj(const char* paVstup)
{
	if (paVstup && *paVstup)
	{
		char* kopia = new char[strlen(paVstup) + 1];
		strcpy(kopia, paVstup);
		return kopia;
	}
	return nullptr;
}

bool operator<(Tovar& op1, Tovar& op2)
{
	int ret = 0;
	int retNazov = strcmp(op1.nazov, op2.nazov); //-1 ak op1 je sk�r v abcede, 0 ak su rovnake, 1 ak op2 je sk�r v abecede
	int retCena = op1.cena - op2.cena;
	int retPocet = op1.pocet - op2.pocet;
	switch (Tovar::styp)
	{
	case 0:
		ret = retNazov;
		if (ret == 0) {
			ret = retCena;
			if (ret == 0)
			{
				ret = retPocet;
			}
		}
		break;
	case 1:
		ret = retCena;
		if (ret == 0) {
			ret = retNazov;
			if (ret == 0)
			{
				ret = retPocet;
			}
		}
		break;
	case 2:
		ret = retPocet;
		if (ret == 0) {
			ret = retNazov;
			if (ret == 0)
			{
				ret = retNazov;
			}
		}
		break;
	default:
		break;
	}
	return ret < 0;
}

std::ostream& operator<<(std::ostream& os, Tovar& h)
{
	os << "Nazov: " << h.nazov << "\tCena: " << h.cena << "\tPocet: " << h.pocet;
	return os;
}
