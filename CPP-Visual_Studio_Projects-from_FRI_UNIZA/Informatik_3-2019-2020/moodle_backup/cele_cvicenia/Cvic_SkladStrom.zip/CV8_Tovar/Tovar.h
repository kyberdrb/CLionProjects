#pragma once
#include <ostream>

using namespace std;

char* kopiruj(const char* paVstup);

class Tovar
{
public:
	//Tovar();
	Tovar& operator = (const Tovar& zdroj);
	~Tovar();
	char* Nazov() { return nazov; }
	double Cena() { return cena; }
	int Pocet() { return pocet; }
	void Nazov(const char* paNazov) { nazov = kopiruj(paNazov); }
	void Cena(double paCena) { cena = paCena; }
	void Pocet(int paPocet) { pocet = paPocet; }
	friend bool operator <(Tovar& op1, Tovar& op2);
	friend std::ostream& operator << (std::ostream& os, Tovar& h);
	static int styp; //sortovaci typ

private:
	char* nazov = nullptr;
	double cena = 0;
	int pocet = 0;
};