#include <cstdlib>
#include <iostream>
#include "Sklad.h"

using namespace std;

Sklad* Sklad::sklad = nullptr;

int PorovnajTovary(const void* ob1, const void* ob2)
{
	Tovar** tovar1Ptr = (Tovar * *)ob1;
	Tovar** tovar2Ptr = (Tovar * *)ob2;
	return *(*tovar2Ptr) < *(*tovar1Ptr);
}

Tovar& Sklad::RealokujZasoby()
{
	Tovar* pomZasoby = new Tovar[pocet + 1];
	// Skopiruj uz existujuce tovary do novych zasob
	if (zasoby) // skrateny zapis pre (zasoby !=nullptr)
	{
		for (unsigned int i = 0; i < pocet; i++)
			pomZasoby[i] = zasoby[i];
		delete[] zasoby;
	}
	pocet++;
	zasoby = pomZasoby;
	return pomZasoby[pocet - 1];
}

void Sklad::VytvorPoleTovarPtr(Tovar**& ptrzasob)
{
	ptrzasob = new Tovar * [pocet];
	for (unsigned int i = 0; i < pocet; i++)
		ptrzasob[i] = &zasoby[i];
}

Sklad::Sklad()
{
}

Sklad::~Sklad()
{
	delete[] zasoby;
}

bool Sklad::Pridaj(const char* nazov, int cena, int pocet)
{
	//if (nazov != nullptr && *nazov != 0) 
	//if (nazov != nullptr && nazov[0] != 0) 
	if (nazov && *nazov)
	{
		Tovar& novyTovar = RealokujZasoby();
		novyTovar.Nazov(nazov);
		novyTovar.Cena(cena);
		novyTovar.Pocet(pocet);
	}
	return false;
}

void Sklad::Sort(PorovnajPtr compareFun, const char* text, int typ)
{
	cout << text << endl;
	Tovar::styp = typ;
	Tovar** ptrzasob = nullptr;
	VytvorPoleTovarPtr(ptrzasob);
	qsort(ptrzasob, pocet, sizeof(Tovar*), compareFun);
	Vypis(ptrzasob);
	delete[] ptrzasob;
}

void Sklad::Vypis(Tovar** ptrzasoby)
{
	for (unsigned i = 0; i < pocet; i++)
		cout << *ptrzasoby[i] << endl;
}


void Sklad::ZobrazPodlaNazov()
{
	Sort(PorovnajTovary, "Podla NAZOV:\n--------------", 0);
}

void Sklad::ZobrazPodlaCena()
{
	Sort(PorovnajTovary, "Podla CENA:\n--------------", 1);
}

void Sklad::ZobrazPodlaPocet()
{
	Sort(PorovnajTovary, "Podla POCET:\n--------------", 2);
}
