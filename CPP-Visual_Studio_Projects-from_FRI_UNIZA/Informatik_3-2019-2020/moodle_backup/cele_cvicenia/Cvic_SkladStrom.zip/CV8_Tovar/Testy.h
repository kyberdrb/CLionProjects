#pragma once
#include "Sklad.h"

class Testy
{
public:
	bool Start();
};

