#pragma once
#include "Tovar.h"

typedef int (*PorovnajPtr)(const void* ob1, const void* ob2);

class Sklad
{
private:
	Tovar* zasoby = nullptr;
	static Sklad* sklad;

	unsigned pocet = 0;
	Tovar& RealokujZasoby();
	void VytvorPoleTovarPtr(Tovar**& ptrzasob);
	void Sort(PorovnajPtr compareFun, const char* text, int typ);
	void Vypis(Tovar** ptrzsob);
	Sklad();
	Sklad(const Sklad& zdroj) {}
public:
	~Sklad();
	bool Pridaj(const char* nazov, int cena, int pocet = 1);
	void ZobrazPodlaNazov();
	void ZobrazPodlaCena();
	void ZobrazPodlaPocet();
	
	static Sklad &GetSklad() 
	{
		if (sklad == nullptr)
			sklad = new Sklad;
		return *sklad;
	}
};

