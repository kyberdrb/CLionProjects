#include <cstdio>
#include "Vstup.h"

int Vstup::DlzkaSuboru()
{
	int dlzka = 0;
	if (aMenoSuboru)
	{
		FILE* f = fopen(aMenoSuboru, "rb");
		if (f)
		{
			fseek(f, 0, SEEK_END);
			dlzka = ftell(f);
			fclose(f);
		}
	}
	return dlzka;
}

unsigned char* Vstup::Citaj()
{
	unsigned char* text = nullptr;
	if (aMenoSuboru)
	{
		int dlzka = DlzkaSuboru();
		if (dlzka > 0)
		{
			text = new unsigned char[dlzka + 1];
			if (text)
			{
				FILE* fd = fopen(aMenoSuboru, "rb");
				if (fd)
				{
					fread(text, dlzka, 1, fd);
					text[dlzka] = '\0';
					fclose(fd);
				}
			}
		}
	}
	return text;
}
