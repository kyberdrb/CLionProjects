#include <random>
#include <cstring>
#include <cstdio>

#include "Heslo.h"
#include "Koder.h"

void Koder::ZakodujTabulku(const unsigned char* heslo)
{
	unsigned nasada = DajNasadu(heslo);
	std::default_random_engine generator;
	generator.seed(nasada);
	for (int i = 0; i < DLZKA_TABULKY; i++)
	{
		std::uniform_int_distribution<int> distribution(0, DLZKA_TABULKY - i - 1);
		int index = distribution(generator);
		Vymen(aKodovaciaTabulka[index], aKodovaciaTabulka[DLZKA_TABULKY - i - 1]);
	}
}

unsigned Koder::DajNasadu(const unsigned char* heslo)
{
	return Heslo(heslo).DajNasadu();
}

void Koder::Vymen(unsigned char& a, unsigned char& b)
{
	unsigned c = a;
	a = b;
	b = c;
}

void Koder::VytvorDekodovaciuTabulku()
{
	unsigned char pomtabulka[DLZKA_TABULKY];
	for (int i = 0; i < DLZKA_TABULKY; i++)
		pomtabulka[aKodovaciaTabulka[i]] = i;
	memmove(aKodovaciaTabulka, pomtabulka, DLZKA_TABULKY * sizeof(unsigned char));
}

Koder::Koder()
{
	for (int i = 0; i < DLZKA_TABULKY; i++)
		aKodovaciaTabulka[i] = i;
}

unsigned char* Koder::Koduj(const unsigned char* heslo, const unsigned char* text2kodtext)
{
	unsigned char* zasifrovanytext = nullptr;
	if (heslo && text2kodtext && *text2kodtext)
	{
		ZakodujTabulku(heslo);
		//int dlzka = sizeof(text2kodtext); // ZLE vysledok = 4 alebo 8
		int dlzka = strlen((char*)text2kodtext);	// SPRAVNE vysledok = dlzka reztazca v bytoch
		unsigned char* zakodovanytext = new unsigned char[dlzka];
		if (zakodovanytext != nullptr)
		{
			for (int i = 0; i < dlzka; i++)
				zakodovanytext[i] = aKodovaciaTabulka[text2kodtext[i]];
			zasifrovanytext = new unsigned char[3 * dlzka + 1];
			if (zasifrovanytext != nullptr)
			{
				unsigned char* pomptr = zasifrovanytext;
				for (int i = 0; i < dlzka; i++)
				{
					char pombuf[4];
					sprintf(pombuf, "%03u", zakodovanytext[i]);
					memmove(pomptr, pombuf, 3);
					pomptr += 3;
				}
				*pomptr = '\0';
			}
			delete[] zakodovanytext;
		}
	}
	return zasifrovanytext;
}

unsigned char* Koder::Dekoduj(const unsigned char* heslo, const unsigned char* text2dekodtext)
{
	unsigned char* desifrovanytext = nullptr;
	if (heslo && text2dekodtext && *text2dekodtext)
	{
		ZakodujTabulku(heslo);
		VytvorDekodovaciuTabulku();
		int dlzka = strlen((char*)text2dekodtext);	// SPRAVNE vysledok = dlzka reztazca v bytoch
		desifrovanytext = new unsigned char[dlzka / 3 + 1];
		if (desifrovanytext != nullptr)
		{
			int k = 0;
			char pombuf[4]{};
			for (int i = 0; i < dlzka; i += 3)
			{
				memmove(pombuf, &text2dekodtext[i], 3);
				desifrovanytext[k++] = aKodovaciaTabulka[atoi(pombuf)];
			}
			desifrovanytext[k] = '\0';
		}
	}
	return desifrovanytext;
}
