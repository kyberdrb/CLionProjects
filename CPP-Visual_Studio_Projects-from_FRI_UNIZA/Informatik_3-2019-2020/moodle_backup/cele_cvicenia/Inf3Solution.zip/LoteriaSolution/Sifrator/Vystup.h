#pragma once
#include "Subor.h"
class Vystup : public Subor
{
public:
	void Zapis(unsigned char* text);
	Vystup(const char* pMenoSuboru = nullptr) : Subor(pMenoSuboru) {}
};

