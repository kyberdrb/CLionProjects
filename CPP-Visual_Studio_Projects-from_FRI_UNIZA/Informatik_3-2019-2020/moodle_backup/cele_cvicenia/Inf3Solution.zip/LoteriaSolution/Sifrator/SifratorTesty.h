#pragma once
class SifratorTesty
{
public:
	// Start testov
	bool Start();
};

