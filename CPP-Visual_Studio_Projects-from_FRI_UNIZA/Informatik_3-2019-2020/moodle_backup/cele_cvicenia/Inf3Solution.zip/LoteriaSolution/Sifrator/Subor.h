#pragma once

char* KopirujText(const char* zdroj);

class Subor
{
protected:
	char* aMenoSuboru = nullptr;
public:
	Subor(const char* pMenoSuboru);
	Subor(const Subor& zdroj);
	virtual ~Subor() = 0 { delete[] aMenoSuboru; }
	Subor& operator =(const Subor& zdroj);
};

