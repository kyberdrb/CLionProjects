#pragma once
class Sifrator
{
private:
	char aCinnost = 'h';
	char* aHeslo = nullptr;
	char* aInSubor = nullptr;
	bool aKonzola = true;
	char* aOutSubor = nullptr;
	void VypisHelp();
public:
	Sifrator(char cinnost, const char* heslo, const char* vstupnySubor,
		bool konzola = true, const char* vystupSubor = nullptr);
	~Sifrator();
	void Start();
};

