#pragma once
#include <cstring>

class Heslo
{
private:
	union {
		unsigned char aHeslo[8];
		unsigned long long aNasada = 0;
	};
public:
	Heslo(const unsigned char* heslo)
	{
		int dlzka = strlen((char*)heslo);
		//if (dlzka > 8)
		//	dlzka = 8;
		dlzka = dlzka > 8 ? 8 : dlzka;
		memmove(aHeslo, heslo, dlzka);
	}

	unsigned int DajNasadu()
	{
		unsigned int loUint = aNasada & 0x00000000ffffffff;
		unsigned int hiUint = (aNasada >> 32) & 0x00000000ffffffff;
		return loUint + hiUint;
	}
};

