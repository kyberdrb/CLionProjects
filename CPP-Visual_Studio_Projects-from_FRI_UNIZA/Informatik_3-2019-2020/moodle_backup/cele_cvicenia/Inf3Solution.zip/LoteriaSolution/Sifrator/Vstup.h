#pragma once
#include "Subor.h"
class Vstup : public Subor
{
private:
	int DlzkaSuboru();
public:
	Vstup(const char* pMenosuboru) : Subor(pMenosuboru) {}
	unsigned char* Citaj();
};

