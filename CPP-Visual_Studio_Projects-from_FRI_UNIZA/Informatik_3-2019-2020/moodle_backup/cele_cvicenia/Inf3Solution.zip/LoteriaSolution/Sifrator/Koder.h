#pragma once
const unsigned DLZKA_TABULKY = 256;

//#define DLZKA_TABULKY  256

class Koder
{
private:
	unsigned char aKodovaciaTabulka[DLZKA_TABULKY];

	void ZakodujTabulku(const unsigned char* heslo);
	unsigned DajNasadu(const unsigned char* heslo);
	void Vymen(unsigned char& a, unsigned char& b);
	void VytvorDekodovaciuTabulku();
public:
	Koder();
	// Zakodovanie textu
	unsigned char* Koduj(const unsigned char* heslo, const unsigned char* text2kodtext);
	unsigned char* Dekoduj(const unsigned char* heslo, const unsigned char* text2dekodtext);
};

