#include <cstring>
#include "Subor.h"

Subor::Subor(const char* pMenoSuboru)
{
	aMenoSuboru = KopirujText(pMenoSuboru);
}

Subor::Subor(const Subor& zdroj)
{
	aMenoSuboru = KopirujText(zdroj.aMenoSuboru);
}

Subor& Subor::operator=(const Subor& zdroj)
{
	if (this != &zdroj)
	{
		Subor::~Subor();
		aMenoSuboru = KopirujText(zdroj.aMenoSuboru);
	}
	return *this;
}

char* KopirujText(const char* zdroj)
{
	char* ciel = nullptr;
	if (zdroj && *zdroj)
	{
		int dlzka = strlen(zdroj);
		ciel = new char[dlzka + 1];
		strcpy(ciel, zdroj);
	}
	return ciel;
}

