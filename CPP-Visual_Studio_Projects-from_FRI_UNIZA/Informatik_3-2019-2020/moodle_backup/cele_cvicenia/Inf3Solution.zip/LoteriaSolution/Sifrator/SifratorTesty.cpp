#include "SifratorTesty.h"
#include "Koder.h"
#include "Vstup.h"
#include "Vystup.h"

// Start testov
bool SifratorTesty::Start()
{
	//Vstup s("main.cpp"); // , s2("Koder.cpp"), s3(s);
	
	unsigned char* text = Vstup("main.cpp").Citaj();
	unsigned char* zakodovanytext = Koder().Koduj((unsigned char*)"vilo", text);
	Vystup().Zapis(zakodovanytext);
	Vystup("main.kod").Zapis(zakodovanytext);
	unsigned char* dekodovanytext = Koder().Dekoduj((unsigned char*)"vilo", zakodovanytext);
	Vystup().Zapis(dekodovanytext);
	delete[] dekodovanytext;
	delete[] zakodovanytext;
	delete[] text;

	//s2 = s2;

	return true;
}
