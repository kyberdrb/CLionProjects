//#define TESTY
#include "Sifrator.h"

#include <iostream>

#ifdef TESTY
#include "SifratorTesty.h"
#endif

int main(int argc, char* argv[])
{
	bool OK = true;
#ifdef TESTY
	//SifratorTesty testy;
	OK = SifratorTesty().Start();
#endif
	if (OK)
	{
		char cinnost = 'h';
		char* heslo = nullptr;
		char* vstupnySubor = nullptr;
		bool konzola = true;
		char* vystupSubor = nullptr;
		if (argc > 1)
			cinnost = argv[1][0];
		if (argc > 2)
			heslo = argv[2];
		if (argc > 3)
			vstupnySubor = argv[3];
		if (argc > 4)
			konzola = argv[4][0] == 's' ? false : true;
		if (argc > 5)
			vystupSubor = argv[5];
		Sifrator(cinnost, heslo, vstupnySubor, konzola, vystupSubor).Start();
	}
	else
		std::cout << "NEPRESLI TESTY!!!" << std::endl;
	return 0;
}