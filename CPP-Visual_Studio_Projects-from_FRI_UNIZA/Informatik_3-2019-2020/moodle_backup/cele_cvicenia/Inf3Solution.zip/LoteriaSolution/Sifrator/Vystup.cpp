#include <cstring>
#include <cstdio>
#include <iostream>
#include "Vystup.h"

void Vystup::Zapis(unsigned char* text)
{
	if (text != nullptr && *text != '\0')
	{
		if (aMenoSuboru)
		{
			int dlzka = strlen((char*)text);
			FILE* f = fopen(aMenoSuboru, "wb");
			if (f)
			{
				fwrite(text, dlzka, 1, f);
				fclose(f);
			}
		}
		else
			std::cout << text << std::endl;
	}
}
