#include <cctype>
#include "Sifrator.h"
#include "Koder.h"
#include "Vstup.h"
#include "Vystup.h"

void Sifrator::VypisHelp()
{
	Vystup().Zapis((unsigned char *)
		"sifrator CINNOST HESLO VSTUPNY_SUBOR [TYP_VYSTUPU VYSTUPNY_SUBOR]\n"
		"   CINNOST:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...help\n"
		"   HESLO: max. 8 znakov\n"
		"   VSTUPNY_SUBOR: meno vstupneho suboru\n"
		"   TYP_VYSTUPU:\n"
		"      s...subor\n"
		"      c...konzola\n"
		"   VYSTUPNY_SUBOR: meno vystupneho suboru\n"
	);
}

Sifrator::Sifrator(char cinnost, const char* heslo, const char* vstupnySubor, bool konzola, const char* vystupSubor)
{
	aCinnost = tolower(cinnost);
	aCinnost = (aCinnost != 's' && aCinnost != 'd') ? 'h' : aCinnost;
	aHeslo = KopirujText(heslo);
	if (aHeslo == nullptr)
		aCinnost = 'h';
	aInSubor = KopirujText(vstupnySubor);
	if (aInSubor == nullptr)
		aCinnost = 'h';
	aKonzola = konzola;
	aOutSubor = KopirujText(vystupSubor);
	if (aOutSubor == nullptr)
		aKonzola = true;
}

Sifrator::~Sifrator()
{
	delete[] aOutSubor;
	delete[] aInSubor;
	delete[] aHeslo;
}

void Sifrator::Start()
{
	if (aCinnost == 'h')
		VypisHelp();
	else
	{
		unsigned char* zdrojtext = Vstup(aInSubor).Citaj();
		if (zdrojtext != nullptr)
		{
			unsigned char* cieltext = aCinnost == 's' ?
				Koder().Koduj((unsigned char*)aHeslo, zdrojtext) :
				Koder().Dekoduj((unsigned char*)aHeslo, zdrojtext);
			if (cieltext != nullptr)
			{
				Vystup(aOutSubor).Zapis(cieltext);
				delete[] cieltext;
			}
			delete[] zdrojtext;
		}
		else
			VypisHelp();
	}
}
