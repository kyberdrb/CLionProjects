#include "Sklad.h"

int main()
{
	Sklad& s = Sklad::GetSklad();

	s.Pridaj("Hruska", 30, 10);
	s.Pridaj("Repa", 20, 100);
	s.Pridaj("Jablko", 120, 340);
	s.Pridaj("Ananas", 23, 123);
	s.Pridaj("Pomaranc", 220, 400);
	s.Pridaj("Mandarinka", 45, 340);
	s.Pridaj("Slivka", 210, 43);
	s.ZobrazPodlaNazov();
	s.ZobrazPodlaCena();
	s.ZobrazPodlaPocet();
	return 0;
}