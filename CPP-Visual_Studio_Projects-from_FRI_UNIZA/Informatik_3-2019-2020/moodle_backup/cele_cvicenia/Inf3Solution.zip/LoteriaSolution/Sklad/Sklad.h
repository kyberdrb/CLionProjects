#pragma once
#include "Tovar.h"

class Sklad
{
private:
	static Sklad* aSklad;
	Tovar* aZasoby = nullptr;
	unsigned aPocet = 0;
	Tovar* Realokuj();
	void Vypis(Tovar** zasobyptr);
	void VytvorZasobyPtr(Tovar**& ptrzasob);
	void Sort();
	Sklad() {}
	Sklad(const Sklad& zdroj) {}
	Sklad& operator=(const Sklad& zdroj) { return *this; }
public:
	static Sklad& GetSklad();
	virtual ~Sklad() { delete[] aZasoby; }

	void Pridaj(const char* nazov, double cena, unsigned pocet);

	void ZobrazPodlaNazov();
	void ZobrazPodlaCena();
	void ZobrazPodlaPocet();
};

