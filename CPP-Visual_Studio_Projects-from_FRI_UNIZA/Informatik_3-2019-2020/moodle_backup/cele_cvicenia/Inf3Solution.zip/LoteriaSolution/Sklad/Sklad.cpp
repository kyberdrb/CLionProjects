#include <cstdlib>
#include "Sklad.h"

Sklad* Sklad::aSklad = nullptr;

int PorovnajFun(const void* obj1, const void* obj2)
{
	Tovar** tovar1ptr = (Tovar * *)obj1;
	Tovar** tovar2ptr = (Tovar * *)obj2;
	return *(*tovar1ptr) < *(*tovar2ptr);
}

Tovar* Sklad::Realokuj()
{
	Tovar* pomZasoby = new Tovar[aPocet + 1];
	if (aZasoby)
	{
		for (unsigned i = 0; i < aPocet; i++)
			pomZasoby[i] = aZasoby[i];
		delete[] aZasoby;
	}
	aPocet++;
	return pomZasoby;
}

void Sklad::Vypis(Tovar** zasobyptr)
{
	for (unsigned i = 0; i < aPocet; i++)
	{
		std::cout << *zasobyptr[i] << std::endl;
	}
}

void Sklad::VytvorZasobyPtr(Tovar**& ptrzasob)
{
	ptrzasob = new Tovar * [aPocet];
	for (unsigned i = 0; i < aPocet; i++)
		ptrzasob[i] = &aZasoby[i];
}

Sklad& Sklad::GetSklad()
{
	if (aSklad == nullptr)
		aSklad = new Sklad();
	return *aSklad;
}

void Sklad::Pridaj(const char* nazov, double cena, unsigned pocet)
{
	if (nazov && *nazov)
	{
		aZasoby = Realokuj();
		aZasoby[aPocet - 1].Nazov(nazov);
		aZasoby[aPocet - 1].Cena(cena);
		aZasoby[aPocet - 1].Pocet(pocet);
	}
}

void Sklad::ZobrazPodlaNazov()
{
	std::cout << "Podla NAZOV:\n-------------" << std::endl;
	Tovar::aSortTyp = eSortTyp::Nazov;
	Sort();
}

void Sklad::ZobrazPodlaCena()
{
	std::cout << "Podla CENA:\n-------------" << std::endl;
	Tovar::aSortTyp = eSortTyp::Cena;
	Sort();
}

void Sklad::ZobrazPodlaPocet()
{
	std::cout << "Podla POCET:\n-------------" << std::endl;
	Tovar::aSortTyp = eSortTyp::Pocet;
	Sort();
}

void Sklad::Sort()
{
	Tovar** ptr = nullptr;
	VytvorZasobyPtr(ptr);
	qsort(ptr, aPocet, sizeof(Tovar*), PorovnajFun);
	Vypis(ptr);
	delete[] ptr;
}
