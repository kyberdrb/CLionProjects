#include <cstring>

#include "Tovar.h"

eSortTyp Tovar::aSortTyp = eSortTyp::Nazov;

char* Skopiruj(const char* zdroj)
{
	char* ciel = nullptr;
	if (zdroj && *zdroj)
	{
		int dlzka = strlen(zdroj);
		ciel = new char[dlzka + 1];
		strcpy(ciel, zdroj);
	}
	return ciel;
}

std::ostream& operator<<(std::ostream& os, Tovar& tovar)
{
	switch (Tovar::aSortTyp)
	{
	case eSortTyp::Nazov:
		os << "Nazov: " << tovar.aNazov << std::endl;
		os << "Cena : " << tovar.aCena << std::endl;
		os << "Pocet: " << tovar.aPocet << std::endl;
		break;
	case eSortTyp::Cena:
		os << "Cena : " << tovar.aCena << std::endl;
		os << "Nazov: " << tovar.aNazov << std::endl;
		os << "Pocet: " << tovar.aPocet << std::endl;
		break;
	case eSortTyp::Pocet:
		os << "Pocet: " << tovar.aPocet << std::endl;
		os << "Nazov: " << tovar.aNazov << std::endl;
		os << "Cena : " << tovar.aCena << std::endl;
		break;
	}
	return os;
}

bool operator<(Tovar& tovar1, Tovar& tovar2)
{
	bool ret = true;
	int retnazov = strcmp(tovar1.aNazov, tovar2.aNazov);
	int retcena = tovar1.aCena - tovar2.aCena;
	int retpocet = tovar1.aPocet - tovar2.aPocet;
	switch (Tovar::aSortTyp)
	{
	case eSortTyp::Nazov:
		ret = retnazov > 0;
		if (retnazov == 0)
		{
			ret = retcena > 0;
			if (retcena == 0)
				ret = retpocet > 0;
		}
		break;
	case eSortTyp::Cena:
		ret = retcena > 0;
		if (retcena == 0)
		{
			ret = retnazov > 0;
			if (retnazov == 0)
				ret = retpocet > 0;
		}
		break;
	case eSortTyp::Pocet:
		ret = retpocet > 0;
		if (retpocet == 0)
		{
			ret = retnazov > 0;
			if (retnazov == 0)
				ret = retcena > 0;
		}
		break;
	default:
		break;
	}
	return ret;
}

Tovar::Tovar(const Tovar& zdroj)
	: aNazov(Skopiruj(zdroj.aNazov)),
	aCena(zdroj.aCena),
	aPocet(zdroj.aPocet)
{
}

Tovar& Tovar::operator=(const Tovar& zdroj)
{
	if (this != &zdroj)
	{
		delete[] aNazov;
		aNazov = Skopiruj(zdroj.aNazov);
		aCena = zdroj.aCena;
		aPocet = zdroj.aPocet;
	}
	return *this;
}
