#pragma once
#include <iostream>

char* Skopiruj(const char* zdroj);

enum eSortTyp { Nazov, Cena, Pocet };

class Tovar
{
private:
	char* aNazov = nullptr;
	double aCena = 0;
	unsigned aPocet = 0;
public:
	static eSortTyp aSortTyp;

	Tovar() {}
	~Tovar() { delete[] aNazov; }
	Tovar(const Tovar& zdroj);
	Tovar& operator =(const Tovar& zdroj);

	char* Nazov() const { return aNazov; }
	double Cena() const { return aCena; }
	unsigned Pocet() const { return aPocet; }

	void Nazov(const char* nazov) { aNazov = Skopiruj(nazov); }
	void Cena(double cena) { aCena = cena; }
	void Pocet(unsigned pocet) { aPocet = pocet; }

	friend std::ostream& operator <<(std::ostream& os, Tovar& tovar);
	friend bool operator <(Tovar& tovar1, Tovar& tovar2);
};

