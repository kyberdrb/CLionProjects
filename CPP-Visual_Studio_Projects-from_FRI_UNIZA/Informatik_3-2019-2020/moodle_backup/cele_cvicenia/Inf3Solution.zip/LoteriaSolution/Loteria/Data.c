#include <malloc.h>

#include "Data.h"

struct Zreb* zreby;

void PripravZreby(MUINT pocetZrebov)
{
	//zreby = malloc(pocetZrebov * sizeof(struct Zreb));
	zreby = calloc(pocetZrebov, sizeof(struct Zreb));
	//if (zreby != NULL)
	if (zreby)
	{
		for (MUINT i = 0; i < pocetZrebov; i++)
		{
			zreby[i].cislo = i + 1;
			zreby[i].kod = 'A' + (i % 26);
		}
	}
}

void ZrusZreby()
{
	free(zreby);
}
