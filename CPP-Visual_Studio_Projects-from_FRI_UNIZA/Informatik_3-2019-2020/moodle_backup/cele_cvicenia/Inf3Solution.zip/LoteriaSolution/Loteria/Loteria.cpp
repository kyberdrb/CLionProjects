#include "Loteria.h"

void Tah(MUINT pocetZrebov, MUINT pocetVylosovanychZrebov)
{
	PripravZreby();
}
