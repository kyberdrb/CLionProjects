#pragma once

#ifdef WIN32
	#define MUINT unsigned long
#else
	#define MUINT unsigned int
#endif

void PripravZreby(MUINT pocetZrebov);
void ZrusZreby();

struct Zreb
{
	MUINT cislo;
	char kod;
};

extern struct Zreb* zreby;