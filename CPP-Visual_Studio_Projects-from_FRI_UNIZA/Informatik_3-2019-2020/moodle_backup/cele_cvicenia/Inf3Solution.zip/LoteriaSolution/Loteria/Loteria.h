#pragma once
#include "Data.h"

void Tah(MUINT pocetZrebov, MUINT pocetVylosovanychZrebov);