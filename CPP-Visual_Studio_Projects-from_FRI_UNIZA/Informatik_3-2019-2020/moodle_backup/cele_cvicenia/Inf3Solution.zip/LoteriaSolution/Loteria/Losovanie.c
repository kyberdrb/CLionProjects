#include <stdlib.h>
#include <time.h>

#include "Losovanie.h"

void Vymen(MUINT index, MUINT i);

void Losuj(MUINT pocetZrebov, MUINT pocetVylosovanychZrebov)
{
	srand((MUINT)time(NULL));
	for (MUINT i = 0; i < pocetVylosovanychZrebov; i++)
	{
		MUINT index = rand() % (pocetZrebov - i) + i;
		Vymen(index, i);
	}
}

void Vymen(MUINT index, MUINT i)
{
	struct Zreb pom = zreby[index];
	zreby[index] = zreby[i];
	zreby[i] = pom;
}