#include <stdlib.h>
#include "Loteria.h"

int main(int argc, char* argv[])
{
	if (argc > 2)
	{
		MUINT pocetZrebov = atoi(argv[1]);
		MUINT pocetVylosovanychZrebov = atoi(argv[2]);
		Tah(pocetZrebov, pocetVylosovanychZrebov);
	}
	return 0;
}