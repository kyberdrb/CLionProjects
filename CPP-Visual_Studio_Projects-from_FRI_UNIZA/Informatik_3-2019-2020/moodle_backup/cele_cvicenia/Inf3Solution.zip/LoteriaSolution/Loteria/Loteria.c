#include "Loteria.h"

void Tah(MUINT pocetZrebov, MUINT pocetVylosovanychZrebov)
{
	if (pocetZrebov != 0 && pocetVylosovanychZrebov != 0) 
	{
		if (pocetVylosovanychZrebov > pocetZrebov)
			pocetVylosovanychZrebov = pocetZrebov;
		PripravZreby(pocetZrebov);
		Losuj(pocetZrebov, pocetVylosovanychZrebov);
		Vypis(pocetVylosovanychZrebov);
		ZrusZreby();
	}
}
