#pragma once
#include "Data.h"

void Losuj(MUINT pocetZrebov, MUINT pocetVylosovanychZrebov);