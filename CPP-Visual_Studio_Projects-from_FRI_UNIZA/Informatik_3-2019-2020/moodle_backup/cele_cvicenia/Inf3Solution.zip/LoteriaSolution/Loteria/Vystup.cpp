#include <stdio.h>
#include "Vystup.h"

void Vypis(MUINT pocetVylosovanychZrebov)
{
	printf("\nVYSLEDOK ZREBOVANIA\n---------------------------\n);
	for (size_t i = 0; i < length; i++)
	{

	}
}
