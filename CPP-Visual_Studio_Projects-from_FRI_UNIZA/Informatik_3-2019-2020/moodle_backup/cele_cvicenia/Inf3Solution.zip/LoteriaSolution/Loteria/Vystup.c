#include <stdio.h>
#include "Vystup.h"

void Vypis(MUINT pocetVylosovanychZrebov)
{
	printf("\nVYSLEDOK ZREBOVANIA\n---------------------------\n");
	for (MUINT i = 0; i < pocetVylosovanychZrebov; i++)
	{
		printf("%3u. poradie:\t%c %10u\n", i + 1, zreby[i].kod, zreby[i].cislo);
	}
	printf("---------------------------\n");
}
