#pragma once
#include "ISystem.h"

struct SDL_Surface;

class SystemSDL : public ISystem
{
private:
	SDL_Surface* aPlocha{};
	static int aPocetObjektov;
public:
	SystemSDL(int sirka, int vyska);
	SystemSDL(SDL_Surface* obrazok) :aPlocha(obrazok) {}
	SystemSDL(const SystemSDL& zdroj) = delete;
	SystemSDL& operator= (const SystemSDL& zdroj) = delete;
	
	~SystemSDL();
		
	// Inherited via ISystem
	virtual int Sirka() override;

	virtual int Vyska() override;

	virtual int Cas() override;

	virtual ISystem* CitajBMP(const char* menosuboru) override;

	virtual void Uvolni(ISystem* grafickyobjekt) override;

	virtual void Zobraz(ISystem& grafickyobjekt, int x, int y) override;

	virtual bool Vstup(int& x, int& y) override;

	virtual void Zmaz() override;

	virtual void Update() override;

	virtual void ZobrazText(string stext) override;

};

