#include "SDL.h"

#include "SystemSDL.h"

int SystemSDL::aPocetObjektov = 0;

SystemSDL::SystemSDL(int sirka, int vyska)
{
	if (aPocetObjektov == 0)
		SDL_Init(SDL_INIT_EVERYTHING);
	aPocetObjektov++;
	aPlocha = SDL_SetVideoMode(sirka, vyska, 0, SDL_SWSURFACE);
}

SystemSDL::~SystemSDL()
{
}

int SystemSDL::Sirka()
{
	return 0;
}

int SystemSDL::Vyska()
{
	return 0;
}

int SystemSDL::Cas()
{
	return 0;
}

ISystem* SystemSDL::CitajBMP(const char* menosuboru)
{
	return nullptr;
}

void SystemSDL::Uvolni(ISystem* grafickyobjekt)
{
}

void SystemSDL::Zobraz(ISystem& grafickyobjekt, int x, int y)
{
}

bool SystemSDL::Vstup(int& x, int& y)
{
	return false;
}

void SystemSDL::Zmaz()
{
}

void SystemSDL::Update()
{
}

void SystemSDL::ZobrazText(string stext)
{
}
