#pragma once
#include "IObjekt.h"
class PohyblivyObjekt : public IObjekt
{
private:
	int aDeltaX, aDeltaY;
	int aSirkaPlochy, aVyskaPlochy;
	int aInterval, aCasPoslednejZmeny;
	int Generuj(int zaciatok, int koniec);
protected:
	int aX = 0, aY = 0;
	int aSirka = 0, aVyska = 0;
	virtual void Reset();
public:
	PohyblivyObjekt(int psirkaplochy, int pvyskaplochy);
	virtual ~PohyblivyObjekt();


	// Inherited via IObjekt
	virtual bool AktualizujSa(int pcas) override;
	virtual bool Zasah(int x, int y) override;

};

