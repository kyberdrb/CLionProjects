#pragma once
class ISystem;
class IObjekt;
class IEngine;

class HraLopta
{
	ISystem* aPlocha{};
	IObjekt* aLopta{};
	IEngine* aHra{};
public:
	HraLopta();
	~HraLopta();
	void Start();
};

