#include "HraLopta.h"
#include "SystemSDL.h"
#include "Lopta.h"
#include "Engine.h"

HraLopta::HraLopta()
	:aPlocha(new SystemSDL(800, 600)),
	aLopta(new Lopta(aPlocha)),
	aHra(new Engine(aPlocha, aLopta))
{
}

HraLopta::~HraLopta()
{
	delete aHra;
	delete aLopta;
	delete aPlocha;
}

void HraLopta::Start()
{
	aHra->Start();
}
