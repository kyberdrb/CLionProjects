#pragma once
#include "IEngine.h"
class IObjekt;
class ISystem;

class Engine : public IEngine
{
private:
	int aSkore{};
	ISystem* aHraciaPlocha{};
	IObjekt* aObjekt = nullptr;

	void ZobrazSkore();
	void Aktualizuj();
	void SpracujVstup(int x, int y);
public:
	Engine(ISystem* pHraciaPlocha, IObjekt* pObjekt);
	virtual ~Engine();

	// Inherited via IEngine
	virtual void Start() override;
};

