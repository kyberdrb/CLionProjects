#pragma once
#include "PohyblivyObjekt.h"

class ISystem;

class Lopta : public PohyblivyObjekt
{
private:
	ISystem* aHraciaPlocha;
	ISystem* aLopta;
public:
	Lopta(ISystem* pHraciaPlocha);
	virtual ~Lopta();

	// Inherited via PohyblivyObjekt
	virtual void ZobrazSa() override;
	virtual int DajBody() override;
};

