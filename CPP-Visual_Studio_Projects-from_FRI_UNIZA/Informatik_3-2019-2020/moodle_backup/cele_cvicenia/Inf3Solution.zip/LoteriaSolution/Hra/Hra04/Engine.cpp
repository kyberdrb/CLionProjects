#include <sstream>
#include "Engine.h"
#include "IObjekt.h"
#include "ISystem.h"

using namespace std;

void Engine::ZobrazSkore()
{
	if (aHraciaPlocha)
	{
		stringstream sts;
		sts << aSkore;
		aHraciaPlocha->ZobrazText(string("Skore: ") + sts.str());
	}
}

void Engine::Aktualizuj()
{
	if (aObjekt && aHraciaPlocha)
	{
		if (aObjekt->AktualizujSa(aHraciaPlocha->Cas()))
		{
			aHraciaPlocha->Zmaz();
			aObjekt->ZobrazSa();
			aHraciaPlocha->Update();
		}
	}
}

void Engine::SpracujVstup(int x, int y)
{
	if (aObjekt && x >= 0)
	{
		if (aObjekt->Zasah(x, y))
		{
			aSkore += aObjekt->DajBody();
			ZobrazSkore();
		}
	}
}

Engine::Engine(ISystem* pHraciaPlocha, IObjekt* pObjekt)
	:aHraciaPlocha(pHraciaPlocha), aObjekt(pObjekt)//,aSkore(0)
{
}

Engine::~Engine()
{
}

void Engine::Start()
{
	if (aHraciaPlocha)
	{
		int x(-1), y(-1);
		ZobrazSkore();
		do
		{
			Aktualizuj();
			SpracujVstup(x, y);
		} while (aHraciaPlocha->Vstup(x, y));
	}
}
