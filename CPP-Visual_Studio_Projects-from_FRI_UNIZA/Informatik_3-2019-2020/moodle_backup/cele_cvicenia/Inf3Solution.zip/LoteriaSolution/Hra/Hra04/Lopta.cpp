#include "Lopta.h"
#include "ISystem.h"

Lopta::Lopta(ISystem* pHraciaPlocha)
	:PohyblivyObjekt(pHraciaPlocha ? pHraciaPlocha->Sirka() : 0,
		pHraciaPlocha ? pHraciaPlocha->Vyska() : 0),
	aLopta(nullptr), aHraciaPlocha(pHraciaPlocha)
{
	if (aHraciaPlocha)
		aLopta = aHraciaPlocha->CitajBMP("ball.bmp");
	if (aLopta)
	{
		aSirka = aLopta->Sirka();
		aVyska = aLopta->Vyska();
		Reset();
	}
}

Lopta::~Lopta()
{
	if (aHraciaPlocha && aLopta) 
		aHraciaPlocha->Uvolni(aLopta);
}

void Lopta::ZobrazSa()
{
	if (aHraciaPlocha && aLopta)
		aHraciaPlocha->Zobraz(*aLopta, aX, aY);
}

int Lopta::DajBody()
{
	return 1;
}
