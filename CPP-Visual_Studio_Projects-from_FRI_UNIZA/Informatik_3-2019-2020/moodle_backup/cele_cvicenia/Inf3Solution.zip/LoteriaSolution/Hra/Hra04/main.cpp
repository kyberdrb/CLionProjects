#include "HraLopta.h"
int main()
{
	HraLopta hra;
	hra.Start();

	return 0;
}