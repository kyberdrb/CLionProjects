#include "Strom.h"

int main()
{
	Strom s;
	s.Vloz(8);
	s.Vloz(10);
	s.Vloz(7);
	s.Vloz(2);
	s.Vloz(5);
	s.Vloz(9);
	s.Vypis();
	return 0;
}