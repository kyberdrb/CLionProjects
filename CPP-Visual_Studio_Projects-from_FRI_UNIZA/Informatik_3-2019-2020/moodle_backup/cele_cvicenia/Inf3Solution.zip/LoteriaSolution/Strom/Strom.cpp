#include <iostream>
#include "Strom.h"

void Strom::Vypis(Uzol* uzol)
{
	if (uzol)
	{
		Vypis(uzol->Lavy());
		std::cout << uzol->Info() << std::endl;
		Vypis(uzol->Pravy());
	}
}

void Strom::ZrusStrom(Uzol* uzol)
{
	if (uzol)
	{
		ZrusStrom(uzol->Lavy());
		ZrusStrom(uzol->Pravy());
		delete[] uzol;
	}
}

void Strom::Vloz(int data, Uzol* uzol)
{
	// Lava vetva
	if (data < uzol->Info())
	{
		if (uzol->Lavy())
			Vloz(data, uzol->Lavy());
		else
			uzol->Lavy(new Uzol(data));
	}
	// Prava vetva
	else
	{
		if (uzol->Pravy())
			Vloz(data, uzol->Pravy());
		else
			uzol->Pravy(new Uzol(data));
	}
}

void Strom::Vloz(int data)
{
	if (aKoren == nullptr)
		aKoren = new Uzol(data);
	else
		Vloz(data, aKoren);
}
