#pragma once
class Strom
{
private:
	class Uzol
	{
	private:
		int aInfo;
		Uzol* aLavy = nullptr;
		Uzol* aPravy = nullptr;
	public:
		Uzol(int data) : aInfo(data) {}
		//Gettery
		int Info() { return aInfo; }
		Uzol* Lavy() { return aLavy; }
		Uzol* Pravy() { return aPravy; }
		//Settery
		void Lavy(Uzol* uzol) { aLavy = uzol; }
		void Pravy(Uzol* uzol) { aPravy = uzol; }
	} *aKoren;

	void ZrusStrom(Uzol* uzol);
	void Vloz(int data, Uzol* uzol);
	void Vypis(Uzol* uzol);
	Strom(const Strom& zdroj) {}
	Strom& operator =(const Strom& zdroj) {}
public:
	Strom() {}
	virtual ~Strom() { ZrusStrom(aKoren); }
	void Vloz(int data);
	void Vypis() { Vypis(aKoren); }
};

