#define TESTY

#ifdef TESTY
  #include "Testy.h"
#endif

int main()
{
	bool OK = true;
#ifdef TESTY
	OK = Testy().Start();
#endif 
	if (OK)
		;
	return 0;
}