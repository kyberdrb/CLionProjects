#include "Testy.h"
#include "BinCislo.h"

bool Testy::Start()
{
	BinCislo a(25), b(-12), c("10011"), d;

	d = b - a;
	cout << "d = ";
	d.Vypis();

	d = a + 100;
	cout << "d = ";
	d.Vypis();

	d = 100 + a;
	cout << "d = "; 
	d.Vypis();

	return true;
}