#pragma once
#include <iostream>
using	namespace std;

class BinCislo
{
private:
	long long aCislo = 0;
	long long Bin2Dec(const char* bincislo);
	const char* Dec2Bin(long long decislo, char* cielbuf);
public:
	BinCislo(long long pcislo = 0) :aCislo(pcislo) {}
	BinCislo(const char* bincislo) :aCislo(Bin2Dec(bincislo)) {}

	void Vypis()
	{
		char buf[100];
		cout << Dec2Bin(aCislo, buf) << endl;
	}

	friend BinCislo operator +(BinCislo op1, BinCislo op2);
	friend BinCislo operator -(BinCislo op1, BinCislo op2);
	friend BinCislo operator /(BinCislo op1, BinCislo op2);
	friend BinCislo operator *(BinCislo op1, BinCislo op2);

	friend bool operator <(BinCislo op1, BinCislo op2);
	friend bool operator >(BinCislo op1, BinCislo op2);
	friend bool operator ==(BinCislo op1, BinCislo op2);
	friend bool operator !=(BinCislo op1, BinCislo op2);
	friend bool operator <=(BinCislo op1, BinCislo op2);
	friend bool operator >=(BinCislo op1, BinCislo op2);
};

inline bool operator <(BinCislo op1, BinCislo op2)
{
	return op1.aCislo < op2.aCislo;
}

inline bool operator >(BinCislo op1, BinCislo op2)
{
	return op1.aCislo > op2.aCislo;
}

inline bool operator ==(BinCislo op1, BinCislo op2)
{
	return op1.aCislo == op2.aCislo;
}

inline bool operator !=(BinCislo op1, BinCislo op2)
{
	return !(op1 == op2);
}

inline bool operator <=(BinCislo op1, BinCislo op2)
{
	return !(op1 > op2);
}

inline bool operator >=(BinCislo op1, BinCislo op2)
{
	return !(op1 < op2);
}

inline BinCislo operator +(BinCislo op1, BinCislo op2)
{
	return op1.aCislo + op2.aCislo;
}

inline BinCislo operator -(BinCislo op1, BinCislo op2)
{
	return op1.aCislo - op2.aCislo;
}

inline BinCislo operator *(BinCislo op1, BinCislo op2)
{
	return op1.aCislo * op2.aCislo;
}

inline BinCislo operator /(BinCislo op1, BinCislo op2)
{
	return op1.aCislo / op2.aCislo;
}
