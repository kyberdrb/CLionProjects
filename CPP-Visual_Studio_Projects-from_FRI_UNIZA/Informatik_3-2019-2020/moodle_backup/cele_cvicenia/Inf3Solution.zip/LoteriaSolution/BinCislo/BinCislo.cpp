#include <cstring>
#include <cstdlib>
#include "BinCislo.h"

long long BinCislo::Bin2Dec(const char* bincislo)
{
	long long deccislo = 0;
	if (bincislo && *bincislo)
	{
		char* pombincislo = new char[strlen(bincislo) + 1];
		strcpy(pombincislo, bincislo);
		strrev(pombincislo);
		int i = 0;
		while (pombincislo[i])
		{
			if (pombincislo[i] == '1')
				deccislo += (1 << i);
			i++;
		}
		if (bincislo[0] == '-')
			deccislo = -deccislo;
		delete[] pombincislo;
	}
	return deccislo;
}

const char* BinCislo::Dec2Bin(long long decislo, char* cielbuf)
{
	long long pomdeccislo = abs(decislo);
	int i = 0;
	do {
		cielbuf[i++] = pomdeccislo % 2 + '0';
		pomdeccislo >>= 1; // /= 2
	} while (pomdeccislo > 0);
	if (decislo < 0)
		cielbuf[i++] = '-';
	cielbuf[i] = '\0';
	return strrev(cielbuf);
}
