#pragma once

typedef int TYPHODNOTA;
const int NEPLATNA_HODNOTA = 0;

class Uzol
{
private:
	TYPHODNOTA aCislo;
	Uzol* paDalsi;
public:
	Uzol(TYPHODNOTA pCislo, Uzol* ppDalsi);

	TYPHODNOTA Cislo() { return aCislo; }
	
	TYPHODNOTA* CisloPtr() { return &aCislo; }

	Uzol* Dalsi() { return paDalsi; }
	void Dalsi(Uzol* ppDalsi) { paDalsi = ppDalsi; }
};

