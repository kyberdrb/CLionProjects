#include "Uzol.h"

Uzol::Uzol(TYPHODNOTA pCislo, Uzol* ppDalsi)
{
	aCislo = pCislo;
	paDalsi = ppDalsi;
}
