#pragma warning(disable : 4996)

#include "Vystup.h"

Vystup::Vystup(const char* pMenoSuboru)
{
	//if (pMenoSuboru != nullptr && pMenoSuboru[0] != '\0')
	if (pMenoSuboru && *pMenoSuboru)
	{
		fhandle = fopen(pMenoSuboru, "wt");
	}
}

Vystup::~Vystup()
{
	//if (fhandle != nullptr)
	if (fhandle)
		fclose(fhandle);
}

void Vystup::Zapis(TYPHODNOTA pCislo)
{
	//if (fhandle != nullptr)
	//if (fhandle)
	//	fprintf(fhandle, "%d\n", pCislo);
	//else
	//	printf("%d\n", pCislo);
	fhandle ? fprintf(fhandle, "%d\n", pCislo) : printf("%d\n", pCislo);
}

