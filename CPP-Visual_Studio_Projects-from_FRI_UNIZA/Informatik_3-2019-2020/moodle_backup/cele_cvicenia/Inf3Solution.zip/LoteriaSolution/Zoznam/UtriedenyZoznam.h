#pragma once
#include "Uzol.h"

class UtriedenyZoznam
{
private:
	Uzol* paStart = nullptr;
	void Spracuj(TYPHODNOTA pCislo);
	void ZaradCislo(TYPHODNOTA pCislo);
	void Vymaz(Uzol* uzolptr);
public:
	Uzol* GetStart() { return paStart; }
	~UtriedenyZoznam() { Vymaz(paStart); }
	void Sort(const char* ppMenoSuboru);
	void Uloz(const char* ppMenoSuboru);
};

