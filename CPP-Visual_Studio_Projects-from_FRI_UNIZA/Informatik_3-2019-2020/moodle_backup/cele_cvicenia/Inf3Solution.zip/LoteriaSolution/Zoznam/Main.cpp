#define TESTUJ
#include <iostream>

using namespace std;

//#ifdef _DEBUG
#ifdef TESTUJ
#include "Testy.h"
#endif

#include "UtriedenyZoznam.h"
#include "Vystup.h"

int main()
{
	bool OK(true);
	//#ifdef _DEBUG
#ifdef TESTUJ
	Testy test;
	OK = test.Start();
#endif

	if (OK)
	{
		//UtriedenyZoznam list;
		//list.Sort("VSTUP.txt");

		//list.Uloz("OUT.txt");
		//list.Uloz(nullptr);
	}
	else
		cout << "NEPRESLI TESTY\n";
	//printf("NEPRESLI TESTY\n");
	return 0;
}