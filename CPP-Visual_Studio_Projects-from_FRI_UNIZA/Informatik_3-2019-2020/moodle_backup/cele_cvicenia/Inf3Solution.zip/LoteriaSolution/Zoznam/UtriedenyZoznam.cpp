#include "UtriedenyZoznam.h"
#include "Vstup.h"
#include "Vystup.h"

int Porovnaj(const void* ph1, const void* ph2)
{
	TYPHODNOTA* pt1 = (TYPHODNOTA*)ph1;
	TYPHODNOTA* pt2 = (TYPHODNOTA*)ph2;
	return *pt1 - *pt2;
}

//int Porovnaj(TYPHODNOTA h1, TYPHODNOTA h2)
//{
//	return h1 - h2;
//}


void UtriedenyZoznam::Sort(const char* ppMenoSuboru)
{
	if (ppMenoSuboru && *ppMenoSuboru)
	{
		Vstup citac(ppMenoSuboru);
		TYPHODNOTA cislo = citac.Citaj();
		while (cislo != NEPLATNA_HODNOTA)
		{
			Spracuj(cislo);
			cislo = citac.Citaj();
		}
	}
}

void UtriedenyZoznam::Spracuj(TYPHODNOTA pCislo)
{
	//if (paStart == nullptr)
	if (!paStart)
		paStart = new Uzol(pCislo, nullptr);
	else
		ZaradCislo(pCislo);
}

void UtriedenyZoznam::ZaradCislo(TYPHODNOTA pCislo)
{
	Uzol* predchadzajuci(nullptr),
		* aktualny(paStart);
	while (aktualny != nullptr && Porovnaj(&pCislo, aktualny->CisloPtr()) > 0)
	{
		predchadzajuci = aktualny;
		aktualny = aktualny->Dalsi();
	}
	Uzol* novyUzol = new Uzol(pCislo, aktualny);
	if (predchadzajuci == nullptr)
		paStart = novyUzol;
	else
		predchadzajuci->Dalsi(novyUzol);
}

void UtriedenyZoznam::Vymaz(Uzol* uzolptr)
{
	//if (uzolptr->Dalsi() != nullptr)
	Uzol* dalsi = uzolptr->Dalsi();
	if (dalsi)
		Vymaz(dalsi);
	delete uzolptr;
}


void UtriedenyZoznam::Uloz(const char* ppMenoSuboru)
{
	Vystup zapis(ppMenoSuboru);
	Uzol* uzolptr = paStart;
	//while (uzolptr != nullptr)
	while (uzolptr)
	{
		zapis.Zapis(uzolptr->Cislo());
		uzolptr = uzolptr->Dalsi();
	}
}
