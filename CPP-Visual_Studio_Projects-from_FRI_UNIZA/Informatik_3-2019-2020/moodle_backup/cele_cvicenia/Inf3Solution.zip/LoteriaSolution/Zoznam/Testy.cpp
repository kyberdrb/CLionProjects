#include "Testy.h"
#include "Vstup.h"
#include "Vystup.h"
#include "UtriedenyZoznam.h"

bool Testy::Start()
{
	UtriedenyZoznam list;
	list.Sort("VSTUP.txt");

	Uzol* uzolptr = list.GetStart();
	TYPHODNOTA minimum = -999999999;
	while (uzolptr)
	{
		if (minimum > uzolptr->Cislo())
			return false;
		minimum = uzolptr->Cislo();
		uzolptr = uzolptr->Dalsi();
	}
	
	list.Uloz("OUT.txt");
	list.Uloz(nullptr);

	return true;
}
