#pragma warning(disable : 4996)
#pragma warning(disable : 6031)

#include "Vstup.h"

Vstup::Vstup(const char* pMenoSuboru)
{
	//if (pMenoSuboru != nullptr && pMenoSuboru[0] != '\0')
	if (pMenoSuboru && *pMenoSuboru)
	{
		fhandle = fopen(pMenoSuboru, "rt");
	}
}

Vstup::~Vstup()
{
	//if (fhandle != nullptr)
	if (fhandle)
		fclose(fhandle);
}

TYPHODNOTA Vstup::Citaj()
{
	//if (fhandle != nullptr) {
	if (fhandle)
	{
		int cislo;
		if (!feof(fhandle)) 
		{
			fscanf(fhandle, "%d", &cislo);
			return cislo;
		}
	}
	return NEPLATNA_HODNOTA;
}
