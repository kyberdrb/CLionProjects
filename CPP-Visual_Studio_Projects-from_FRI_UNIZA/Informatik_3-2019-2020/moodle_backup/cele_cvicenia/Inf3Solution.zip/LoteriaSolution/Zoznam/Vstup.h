#pragma once
#include <cstdio>

#include "Uzol.h"

class Vstup
{
private:
	FILE* fhandle = nullptr;

public:
	Vstup(const char* pMenoSuboru);
	~Vstup();

	TYPHODNOTA Citaj();
};

