#pragma once
#include <ostream>

using namespace std;

char* kopiruj(const char* text);

class Tovar
{
private:
	char* aNazov = nullptr;
	double aCena = 0;
	int aPocet = 0;
public:
	static int styp;

	//Tovar(){}
	Tovar() = default;
	Tovar(const Tovar &zdroj)
		:aNazov(kopiruj(zdroj.aNazov)), aCena(zdroj.aCena), aPocet(zdroj.aPocet)
	{}

	Tovar& operator =(const Tovar& zdroj)
	{
		if (this!=&zdroj)
		{
			delete[] aNazov;
			aNazov = kopiruj(zdroj.aNazov);
			aCena = zdroj.aCena;
			aPocet = zdroj.aPocet;
		}
		return *this;
	}

	~Tovar() { delete[] aNazov; }

	char* Nazov() { return aNazov; }
	double Cena() { return aCena; }
	int Pocet() { return aPocet; }

	void Nazov(const char* pnazov) { aNazov = kopiruj(pnazov); }
	void Cena(double cena) { aCena = cena; }
	void Pocet(int pocet) { aPocet = pocet; }

	friend bool operator <(Tovar& op1, Tovar& op2);
	friend ostream& operator <<(ostream& os, Tovar& t);
};

