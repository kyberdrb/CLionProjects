#include "Sklad.h"
int main()
{
	Sklad sklad;
	sklad.Pridaj("A", 11.40, 20);
	sklad.Pridaj("B", 100, 100);
	sklad.Pridaj("W", 20, 2);
	sklad.Pridaj("X", 20, 2);
	sklad.ZobrazPodlaNazov();
	sklad.ZobrazPodlaCena();
	sklad.ZobrazPodlaPocet();

	Sklad skladtest;
	//skladtest = sklad;
}