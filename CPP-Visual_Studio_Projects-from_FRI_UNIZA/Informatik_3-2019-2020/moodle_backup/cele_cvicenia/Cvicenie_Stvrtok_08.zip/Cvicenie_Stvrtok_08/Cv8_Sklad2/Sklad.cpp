#include "Sklad.h"
#include <iostream>
#include <cstdlib>

int PorovnajTovar(const void* p1, const void* p2)
{
	Tovar** ptrp1 = (Tovar**)p1;
	Tovar** ptrp2 = (Tovar**)p2;
	return **ptrp1 < **ptrp2;
}

Tovar* Sklad::Realokuj()
{
	Tovar* pom = new Tovar[aPocet + 1];
	if (aZasoby)
	{
		for (int i = 0; i < aPocet; i++)
			pom[i] = aZasoby[i];
		delete[] aZasoby;
	}
	aPocet++;
	return pom;
}

void Sklad::Vypis(Tovar** tovary)
{
	for (int i = 0; i < aPocet; i++)
		cout << *tovary[i] << endl;
}

void Sklad::ZobrazSort(PorovnajFunPtr fun)
{
	Tovar** tovary;
	VytvorPolePtr(tovary);
	qsort(tovary, aPocet, sizeof(Tovar*), fun);
	Vypis(tovary);
	delete[] tovary;
}

Sklad::~Sklad()
{
	delete[] aZasoby;
	aZasoby = nullptr;
}

void Sklad::Pridaj(const char* nazov, double cena, int pocet)
{
	if (nazov && *nazov)
	{
		aZasoby = Realokuj();
		aZasoby[aPocet - 1].Nazov(nazov);
		aZasoby[aPocet - 1].Cena(cena);
		aZasoby[aPocet - 1].Pocet(pocet);
	}
}

void Sklad::VytvorPolePtr(Tovar**& ptrzasob)
{
	ptrzasob = new Tovar * [aPocet];
	for (int i = 0; i < aPocet; i++)
		ptrzasob[i] = &aZasoby[i];
}

void Sklad::ZobrazPodlaNazov()
{
	cout << "Podla nazov:" << endl << "-----------------------" << endl;
	Tovar::styp = 0;
	ZobrazSort(PorovnajTovar);
}

void Sklad::ZobrazPodlaCena()
{
	cout << "Podla cena:" << endl << "-----------------------" << endl;
	Tovar::styp = 1;
	ZobrazSort(PorovnajTovar);
}

void Sklad::ZobrazPodlaPocet()
{
	cout << "Podla pocet:" << endl << "-----------------------" << endl;
	Tovar::styp = 2;
	ZobrazSort(PorovnajTovar);
}
