#pragma once
#include "Tovar.h"

typedef int(*PorovnajFunPtr)(const void* p1, const void* p2);

class Sklad
{
	Tovar* aZasoby = nullptr;
	int aPocet = 0;
	Tovar* Realokuj(); // pridanie prvku pola
	//Tovar* Realokuj(Tovar& t); // odobranie prvku pola
	void Vypis(Tovar** tovary);
	void ZobrazSort(PorovnajFunPtr fun);
public:
	Sklad() = default;
	Sklad(const Sklad& zdroj){/*dorobit*/}
	//Sklad& operator =(const Sklad& zdroj);
	~Sklad();

	void Pridaj(const char* nazov, double cena, int pocet);
	void VytvorPolePtr(Tovar**& ptrzasob);
	void ZobrazPodlaNazov();
	void ZobrazPodlaCena();
	void ZobrazPodlaPocet();

};

