#include <cstring>
#include "Tovar.h"

int Tovar::styp = 0;

char* kopiruj(const char* text)
{
	if (text && *text)
	{
		int dlzka = strlen(text);
		char* kopia = new char[dlzka + 1];
		strcpy_s(kopia, dlzka+1, text);
		return kopia;
	}
	return nullptr;
}

bool operator<(Tovar& op1, Tovar& op2)
{
	int ret = 0;
	int retnazov = strcmp(op1.aNazov, op2.aNazov);
	int retcena = (int)(op1.aCena - op2.aCena);
	int retpocet = op1.aPocet - op2.aPocet;
	switch (Tovar::styp)
	{
	case 0:
		ret = retnazov;
		if (ret == 0)
		{
			ret = retcena;
			if (ret == 0)
				ret = retpocet;
		}
		break;
	case 1:
		ret = retcena;
		if (ret == 0)
		{
			ret = retnazov;
			if (ret == 0)
				ret = retpocet;
		}
		break;
	case 2:
		ret = retpocet;
		if (ret == 0)
		{
			ret = retnazov;
			if (ret == 0)
				ret = retcena;
		}
		break;
	default:
		break;
	}
	return ret > 0;
}

ostream& operator<<(ostream& os, Tovar& t)
{
	switch (Tovar::styp)
	{
	case 0:
		os << "Nazov: " << t.aNazov << endl;
		os << "Cena:  " << t.aCena << endl;
		os << "Pocet: " << t.aPocet << endl;
		break;
	case 1:
		os << "Cena:  " << t.aCena << endl;
		os << "Nazov: " << t.aNazov << endl;
		os << "Pocet: " << t.aPocet << endl;
		break;
	case 2:
		os << "Pocet: " << t.aPocet << endl;
		os << "Nazov: " << t.aNazov << endl;
		os << "Cena:  " << t.aCena << endl;
		break;
	default:
		break;
	}
	return os;
}
