#pragma once

enum {FALSE, TRUE};

typedef unsigned int MUINT;
typedef unsigned short BOOL;

struct Zreb {
	MUINT cislo;
	char kod;
};

extern MUINT CelkovyPocetZrebov; // !!! musi byt deklaracia

extern struct Zreb *Zreby; // !!! musi byt deklaracia

void PripravZreby();
void ZrusZreby();