#include <time.h>
#include <stdlib.h>

#include "Losovanie.h"

void Vymen(MUINT index, MUINT i);

void Losuj(MUINT pocetLosovanychZrebov)
{
	srand((MUINT)time(NULL));
	for (MUINT i = 0; i < pocetLosovanychZrebov; i++)
	{
		MUINT index = rand() % (CelkovyPocetZrebov - i) + i;
		Vymen(index, i);
	}
}

void Vymen(MUINT index, MUINT i)
{
	struct Zreb pom;
	pom = Zreby[index];
	Zreby[index] = Zreby[i];
	Zreby[i] = pom;
}