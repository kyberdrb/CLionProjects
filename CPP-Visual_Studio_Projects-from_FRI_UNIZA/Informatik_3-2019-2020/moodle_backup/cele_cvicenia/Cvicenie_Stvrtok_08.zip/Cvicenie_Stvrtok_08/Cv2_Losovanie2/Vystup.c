#include <stdio.h>
#include "Vystup.h"

void Vypis(MUINT pocetLosovanychZrebov)
{
	printf("\nVYSLEDOK ZREBOVANIA\n-------------------\n");
	for (MUINT i = 0; i < pocetLosovanychZrebov && i < CelkovyPocetZrebov; i++)
	{
		printf("%3u. poradie:\t%c %010u\n", i + 1, Zreby[i].kod, Zreby[i].cislo);
	}
	printf("------------------------------\nKONIEC\n");
}
