#pragma once
#include "Data.h"

BOOL Testuj();
