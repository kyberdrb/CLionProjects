#include "Testy.h"

BOOL Testuj()
{
	PripravZreby();
	if (Zreby[5].cislo == 6)
	{
		return TRUE;
	}
	return FALSE;
}
