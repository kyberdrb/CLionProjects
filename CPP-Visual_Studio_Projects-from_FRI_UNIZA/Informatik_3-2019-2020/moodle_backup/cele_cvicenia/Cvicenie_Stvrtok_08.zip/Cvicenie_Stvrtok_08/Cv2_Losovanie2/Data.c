#include <malloc.h>

#include "Data.h"

struct Zreb* Zreby;
MUINT CelkovyPocetZrebov;

void PripravZreby()
{
	if (CelkovyPocetZrebov > 0)
	{
		Zreby = malloc(CelkovyPocetZrebov * sizeof(struct Zreb));
		if (Zreby != NULL)
		{
			for (MUINT i = 0; i < CelkovyPocetZrebov; i++)
			{
				Zreby[i].cislo = i + 1;
				Zreby[i].kod = 'A' + (i % 26);
			}
		}
	}
}

void ZrusZreby()
{
	if (Zreby != NULL)
		free(Zreby);
	Zreby = NULL;
}