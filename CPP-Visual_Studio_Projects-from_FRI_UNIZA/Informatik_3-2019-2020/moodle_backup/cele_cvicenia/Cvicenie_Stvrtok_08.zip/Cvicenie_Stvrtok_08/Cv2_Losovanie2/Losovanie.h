#pragma once
#include "Data.h"

// vybera nahodne dany pocet zrebov
void Losuj(MUINT pocetLosovanychZrebov);