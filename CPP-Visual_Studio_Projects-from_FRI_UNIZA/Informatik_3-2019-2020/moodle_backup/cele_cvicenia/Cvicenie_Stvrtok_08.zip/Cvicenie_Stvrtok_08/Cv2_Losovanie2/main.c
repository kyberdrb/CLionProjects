#include <stdlib.h>
#include <stdio.h>
#include "Data.h"
#include "Testy.h"
#include "Loteria.h"

int main(int argc, char* argv[])
{
	//CelkovyPocetZrebov = 10;
	//BOOL res = Testuj();
	if (argc == 3)
	{
		CelkovyPocetZrebov = atoi(argv[2]);
		Tah(atoi(argv[1]));
	}
	printf("stlac klavesu pre koniec\n");
	getchar();
	return 0;
}
