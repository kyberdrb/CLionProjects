#include "Loteria.h"
#include "Data.h"
#include "Losovanie.h"
#include "Vystup.h"

void Tah(MUINT pocetLosovanychZrebov)
{
	if (pocetLosovanychZrebov > CelkovyPocetZrebov)
		pocetLosovanychZrebov = CelkovyPocetZrebov;
	PripravZreby();
	Losuj(pocetLosovanychZrebov);
	Vypis(pocetLosovanychZrebov);
	ZrusZreby();
}
