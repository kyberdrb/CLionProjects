#include "Sifrator.h"
#include "helper.h"
#include "Vstup.h"
#include "Koder.h"
#include "Vystup.h"

void Sifrator::VypisHelp()
{
	// doplnit
	Vystup help(nullptr);
	help.Zapis((unsigned char*)
		"Cv4_Sifrator2 CINNOST HESLO VSTUP_SUBOR [TYP_VYSTUPU VYSTUP_SUBOR]\n"
		"   CINNOST:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...help\n"
		"   TYP_VYSTUPU:\n"
		"      s...subor\n"
		"      c...konzola\n\n");
}

void Sifrator::Init(char cinnost, const char* heslo, bool konzola, const char* vstupSubor,
	const char* vystupSubor)
{
	aCinnost = cinnost;
	aHeslo = AlokujKopiruj(heslo);
	aKonzola = konzola;
	aVstupSubor = AlokujKopiruj(vstupSubor);
	aVystupSubor = aKonzola ? nullptr : AlokujKopiruj(vystupSubor);
}

void Sifrator::Zmaz()
{
	delete[] aHeslo;
	delete[] aVstupSubor;
	delete[] aVystupSubor;
}

Sifrator::Sifrator(char cinnost, const char* heslo, bool konzola, const char* vstupSubor,
	const char* vystupSubor)
{
	Init(cinnost, heslo, konzola, vstupSubor, vystupSubor);
}

Sifrator::Sifrator(const Sifrator& zdroj)
{
	Init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aKonzola, zdroj.aVstupSubor, zdroj.aVystupSubor);
}

Sifrator& Sifrator::operator=(const Sifrator& zdroj)
{
	if (this != &zdroj)
	{
		Zmaz();
		Init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aKonzola, zdroj.aVstupSubor, zdroj.aVystupSubor);
	}
	return *this;
}

Sifrator::~Sifrator()
{
	Zmaz();
}

void Sifrator::Start()
{
	if (aCinnost == 'h')
		VypisHelp();
	else
	{
		Vstup zdroj(aVstupSubor);
		unsigned char* zdrojText = zdroj.Citaj();
		if (zdrojText)
		{
			char* cielText;
			Koder koder;
			if (aCinnost == 's')
				cielText = koder.Koduj(aHeslo, zdrojText);
			else
				cielText = (char*)koder.Dekoduj(aHeslo, (char*)zdrojText);
			if (cielText)
			{
				Vystup vystup(aVystupSubor);
				vystup.Zapis((unsigned char*)cielText);
				delete[] cielText;
			}
			delete[] zdrojText;
		}
	}
}
