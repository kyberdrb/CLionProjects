//#include <cstring>
#include "Vstup.h"
#include "helper.h"
#include <cstdio>
#

int Vstup::DlzkaSuboru()
{
	FILE* f(fopen(aMenoSuboru, "rb")); //otvor ako binarny subor
	if (f)
	{
		fseek(f, 0, SEEK_END);
		int dlzka = ftell(f);
		fclose(f);
		return dlzka;
	}
	return 0;
}

Vstup::Vstup(const char* menoSuboru)
{
	aMenoSuboru = AlokujKopiruj(menoSuboru);
}

Vstup::Vstup(const Vstup& zdroj)
{
	aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
}

Vstup& Vstup::operator=(const Vstup& zdroj)
{
	if (this != &zdroj)
	{
		delete[] aMenoSuboru;
		aMenoSuboru = AlokujKopiruj(zdroj.aMenoSuboru);
	}
	return *this;
}

Vstup::~Vstup()
{
	delete[] aMenoSuboru;
}

unsigned char* Vstup::Citaj()
{
	FILE* f;
	int dlzka = DlzkaSuboru();
	if (dlzka > 0)
	{
		unsigned char* text = new unsigned char[dlzka + 1];
		f = fopen(aMenoSuboru, "rb");
		fread(text, dlzka, 1, f);
		text[dlzka] = '\0';
		fclose(f);
		return text;
	}
	return nullptr;
}
