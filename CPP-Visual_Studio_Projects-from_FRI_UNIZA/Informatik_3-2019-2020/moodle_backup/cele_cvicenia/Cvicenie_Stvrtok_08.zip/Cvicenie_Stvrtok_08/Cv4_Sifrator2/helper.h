#pragma once

char *AlokujKopiruj(const char* zdroj);
