#pragma once
#include <cstring>

char *AlokujKopiruj(const char* zdroj)
{
	char* ciel = nullptr;
	if (zdroj && *zdroj)
	{
		int dlzka = strlen(zdroj);
		ciel = new char[dlzka + 1];
		strcpy(ciel, zdroj);
	}
	return ciel;
}
