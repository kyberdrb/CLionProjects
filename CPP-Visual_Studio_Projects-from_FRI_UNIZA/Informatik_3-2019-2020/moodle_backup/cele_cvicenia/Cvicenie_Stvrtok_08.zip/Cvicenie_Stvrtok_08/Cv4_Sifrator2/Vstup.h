#pragma once
class Vstup
{
private:
	char* aMenoSuboru = nullptr;
	int DlzkaSuboru();
public:
	Vstup(const char* menoSuboru);
	Vstup(const Vstup& zdroj);
	Vstup &operator =(const Vstup& zdroj);

	~Vstup();
	// nacitanie suboru
	unsigned char* Citaj();
};

