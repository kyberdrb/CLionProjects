#include <cstdio>
#include "Koder.h"

char* Koder::Koduj(const char* pheslo, const unsigned char* ptext)
{
	if (ptext && *ptext)
	{
		PripravTabulku(pheslo);
		int dlzkaTextu = strlen((char*)ptext);
		unsigned char* kodText = new unsigned char[dlzkaTextu]; //pole znakov, nie retazec
		if (kodText)
		{
			for (int i = 0; i < dlzkaTextu; i++)
				kodText[i] = aKodTabulka[ptext[i]];
			char* sifrText = new char[3 * dlzkaTextu + 1]; // retazec
			if (sifrText)
			{
				int k = 0;
				for (int i = 0; i < dlzkaTextu; i++)
				{
					char ciskod[4];
					sprintf(ciskod, "%03u", kodText[i]);
					memmove(&sifrText[k], ciskod, 3);
					k += 3;
				}
				sifrText[k] = '\0';
				delete[] kodText;
				return sifrText;
			}
		}
	}
	return nullptr;
}

unsigned char* Koder::Dekoduj(const char* pheslo, const char* psifrtext)
{
	PripravTabulku(pheslo);
	DekodujTabulku();
	if (psifrtext && *psifrtext)
	{
		int dlzkaTextu = strlen(psifrtext);
		unsigned char* kodText = new unsigned char[dlzkaTextu / 3];
		if (kodText)
		{
			char ciskod[4]{};
			int k(0), i(0);
			while (k < dlzkaTextu)
			{
				memmove(ciskod, &psifrtext[k], 3);
				kodText[i++] = (unsigned char)atoi(ciskod);
				k += 3;
			}
			unsigned char* desifrovanyText = new unsigned char[dlzkaTextu / 3 + 1];
			if (desifrovanyText)
			{
				for (int k = 0; k < i; k++)
					desifrovanyText[k] = aKodTabulka[kodText[k]];
				desifrovanyText[i] = 0;
				delete[] kodText;
				return desifrovanyText;
			}
		}
	}
	return nullptr;
}
