#pragma once
class Sifrator
{
private:
	char aCinnost;
	char* aHeslo;
	bool aKonzola;
	char* aVstupSubor;
	char* aVystupSubor;
	void VypisHelp();
	void Init(char cinnost, const char* heslo, bool konzola, const char* vstupSubor, 
		const char* vystupSubor);
	void Zmaz();
public:
	Sifrator(char cinnost, const char* heslo, bool konzola, const char* vstupSubor,
		const char* vystupSubor);
	Sifrator(const Sifrator& zdroj);
	Sifrator &operator =(const Sifrator& zdroj);
	~Sifrator();

	void Start();
};

