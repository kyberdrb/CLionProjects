//#include "Koder.h"
#include "Sifrator.h"

int main(int argc, char *argv[])
{
	char cinnost{ 'h' };
	char* heslo{};
	char* vstupSubor{};
	bool konzola{ true };
	char* vystupSubor{};
	if (argc > 1)
		cinnost = argv[1][0];
	if (argc > 2)
		heslo = argv[2];
	if (argc > 3)
		vstupSubor = argv[3];
	if (argc > 4)
		konzola = argv[4][0] == 'c' || argv[4][0] == 'C';
	if (argc > 5)
		vystupSubor = argv[5];

	Sifrator sifrator(cinnost, heslo, konzola, vstupSubor, vystupSubor);
	sifrator.Start();
	
	//Koder k;

	//char* kodovanyText = k.Koduj("abcd", (unsigned char *)"stvrtok 8:00");
	//unsigned char* dekodovanyText = k.Dekoduj("abcd", kodovanyText);
	//delete[] dekodovanyText;
	//delete[] kodovanyText;

	return 0;
}