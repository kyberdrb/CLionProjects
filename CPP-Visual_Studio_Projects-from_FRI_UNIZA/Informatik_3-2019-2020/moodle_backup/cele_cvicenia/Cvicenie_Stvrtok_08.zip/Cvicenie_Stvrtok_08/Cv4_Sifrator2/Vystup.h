#pragma once
class Vystup
{
private:
	char* aMenoSuboru = nullptr;
public:
	Vystup(const char* menoSuboru);
	Vystup(const Vystup& zdroj);
	Vystup& operator =(const Vystup& zdroj);

	~Vystup();
	// nacitanie suboru
	void Zapis(const unsigned char *text);
};

