#pragma once
#include <cstdio>

class Vystup
{
private:
	FILE* handle = nullptr; // popisovac suboru
public:
	Vystup(const char* menosuboru); //konstruktor, parametricky

	~Vystup(); // destruktor

	void ZapisCislo(int cislo);
};

