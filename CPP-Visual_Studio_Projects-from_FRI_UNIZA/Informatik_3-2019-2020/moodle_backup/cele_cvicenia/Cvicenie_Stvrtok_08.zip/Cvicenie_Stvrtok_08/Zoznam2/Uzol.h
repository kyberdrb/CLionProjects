#pragma once

typedef int TYPHODNOTA;
const TYPHODNOTA NEPLATNA_HODNOTA = 0;

int porovnaj(void* cislo1ptr, void* cislo2ptr);

class Uzol
{
private:
	TYPHODNOTA aHodnota = 0;
	Uzol* aDalsi = nullptr;
public:
	Uzol(TYPHODNOTA pHodnota, Uzol* pDalsi);

	// gettery, inline
	TYPHODNOTA* Hodnota() { return &aHodnota; }
	Uzol* Dalsi() const { return aDalsi; }
	// setter, inline
	void Dalsi(Uzol* pdalsi) { aDalsi = pdalsi; }
};

