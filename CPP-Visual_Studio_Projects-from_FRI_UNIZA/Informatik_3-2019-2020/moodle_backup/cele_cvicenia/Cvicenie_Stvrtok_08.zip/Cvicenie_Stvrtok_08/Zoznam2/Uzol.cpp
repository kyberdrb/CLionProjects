#include "Uzol.h"

int porovnaj(void* cislo1ptr, void* cislo2ptr)
{
	TYPHODNOTA* p1 = (TYPHODNOTA*)cislo1ptr;
	auto p2 = (TYPHODNOTA*)cislo2ptr;

	return *p1 - *p2;
}

Uzol::Uzol(TYPHODNOTA pHodnota, Uzol* pDalsi)
{
	aHodnota = pHodnota;
	aDalsi = pDalsi;
}

