#pragma once
#include <cstdio>

class Vstup
{
private:
	FILE* handle; // popisovac suboru
public:
	Vstup(const char* menosuboru); //konstruktor, parametricky

	~Vstup(); // destruktor

	int citajCislo();
};

