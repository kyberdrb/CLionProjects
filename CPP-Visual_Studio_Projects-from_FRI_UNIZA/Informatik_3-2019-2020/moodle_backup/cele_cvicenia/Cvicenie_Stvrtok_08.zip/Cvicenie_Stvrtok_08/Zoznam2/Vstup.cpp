#include "Vstup.h"

Vstup::Vstup(const char* menosuboru)
{
	handle = nullptr;
	if (menosuboru != nullptr && *menosuboru != 0)
		handle = fopen(menosuboru, "rt"); // mod: otvor textak pre citanie
}

Vstup::~Vstup()
{
	if (handle != nullptr)
		fclose(handle);
}

int Vstup::citajCislo()
{
	if (handle)
	{
		int cislo=0;
		fscanf(handle, "%d", &cislo);
		return cislo;
	}
	return 0;
}
