#include "Testy.h"
#include "Zoznam.h"

bool Testy::Testuj()
{
	Zoznam zoznam;

	zoznam.Sort("vstup.txt", porovnaj);
	zoznam.Uloz("utriedeny.txt");
	zoznam.Uloz(nullptr);
	return true;
}
