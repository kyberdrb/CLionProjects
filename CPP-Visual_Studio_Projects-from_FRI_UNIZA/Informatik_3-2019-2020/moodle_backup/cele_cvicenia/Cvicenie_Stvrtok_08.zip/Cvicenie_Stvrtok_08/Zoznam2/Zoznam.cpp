#include "Zoznam.h"
#include "Vstup.h"
#include "Vystup.h"

Zoznam::~Zoznam()
{
	Vymaz(aStart);
}

void Zoznam::Sort(const char* menosuboru, PorovnajPtr compareFun)
{
	Vstup citac(menosuboru);

	int cislo = citac.citajCislo();
	while (cislo != NEPLATNA_HODNOTA)
	{
		if (aStart == nullptr) //!aStart
		{
			aStart = new Uzol(cislo, nullptr);
		}
		else
		{
			Uzol* predchadzajuci = nullptr;
			Uzol* uzol = aStart;
			while (uzol != nullptr && compareFun(&cislo, uzol->Hodnota()) < 0)
			{
				predchadzajuci = uzol;
				uzol = uzol->Dalsi();
			}
			uzol = new Uzol(cislo, uzol);
			if (predchadzajuci == nullptr)
				aStart = uzol;
			else
				predchadzajuci->Dalsi(uzol);
		}
		cislo = citac.citajCislo();
	}
}

void Zoznam::Uloz(const char* menosuboru)
{
	Uzol* uzol = aStart;
	Vystup vystup(menosuboru);
	while (uzol != nullptr)
	{
		vystup.ZapisCislo(*uzol->Hodnota());
		uzol = uzol->Dalsi();
	}
}

void Zoznam::Vymaz(Uzol* uzol)
{
	if (uzol->Dalsi() != nullptr)
		Vymaz(uzol->Dalsi());
	delete uzol;
}
