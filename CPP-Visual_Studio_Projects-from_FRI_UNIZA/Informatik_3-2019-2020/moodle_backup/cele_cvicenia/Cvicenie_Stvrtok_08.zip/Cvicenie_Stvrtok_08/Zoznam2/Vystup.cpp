#include "Vystup.h"

Vystup::Vystup(const char* menosuboru)
{
	if (menosuboru != nullptr && *menosuboru != 0)
		handle = fopen(menosuboru, "wt"); // mod: otvor textak pre zapis
}

Vystup::~Vystup()
{
	if (handle != nullptr)
		fclose(handle);
}

void Vystup::ZapisCislo(int cislo)
{
	if (handle)
		fprintf(handle, "%d\n", cislo);
	else
		printf("%d\n", cislo);
}
