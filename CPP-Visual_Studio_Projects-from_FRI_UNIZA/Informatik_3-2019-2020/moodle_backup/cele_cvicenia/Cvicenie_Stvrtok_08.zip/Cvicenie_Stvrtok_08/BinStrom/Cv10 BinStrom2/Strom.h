#pragma once
class Strom
{
	class Uzol
	{
	public:
		Uzol() = default;
		Uzol(int data, Uzol* lavy = nullptr, Uzol* pravy = nullptr)
			: aData(data), aLavy(lavy), aPravy(pravy) {}
		~Uzol() = default;
		int Data() { return aData; }
		inline Uzol* Lavy();
		inline Uzol* Pravy();
		void Data(int data) { aData = data; }
		void Lavy(Uzol* lavy) { aLavy = lavy; }
		void Pravy(Uzol* pravy) { aPravy = pravy; }

	private:
		int aData;
		Uzol* aLavy = nullptr;
		Uzol* aPravy = nullptr;
	} *aKoren = nullptr;

	void ZrusStrom(Uzol* uzol);
	void Vloz(int data, Uzol* uzol);
	void Vypis(Uzol* uzol);
public:
	Strom(){}
	~Strom() { ZrusStrom(aKoren); }
	void ZrusStrom();
	void Vloz(int data);
	void Vypis();
};

inline Strom::Uzol* Strom::Uzol::Lavy() { return aLavy; }
inline Strom::Uzol* Strom::Uzol::Pravy() { return aPravy; }

