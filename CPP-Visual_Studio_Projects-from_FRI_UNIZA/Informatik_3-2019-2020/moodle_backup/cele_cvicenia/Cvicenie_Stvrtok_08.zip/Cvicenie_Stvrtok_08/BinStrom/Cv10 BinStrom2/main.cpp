#include "Strom.h"
int main()
{
	Strom* strom = new Strom();

	strom->Vloz(100);
	strom->Vloz(-100);
	strom->Vloz(1);
	strom->Vloz(10);
	strom->Vloz(0);
	strom->Vloz(-20);
	strom->Vloz(0);
	strom->Vloz(0);
	strom->Vloz(500);
	strom->Vypis();

	delete strom;
	return 0;
}