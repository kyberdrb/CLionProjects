#pragma once
class Testy
{
public:
	// Start testov programu
	bool Start();
};

