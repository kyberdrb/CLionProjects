#pragma once

//#define TYPHODNOTA int 
typedef int TYPHODNOTA;
// #define NEPLATNA_HODNOTA 0

const TYPHODNOTA NEPLATNA_HODNOTA = 0;

class Uzol
{
private:
	TYPHODNOTA aHodnota;
	Uzol* aDalsi;
public:
	Uzol(TYPHODNOTA pHodnota, Uzol* pDalsi)
	{
		aHodnota = pHodnota;
		aDalsi = pDalsi;
	}
	TYPHODNOTA* HodnotaPtr() { return &aHodnota; }
	Uzol* Dalsi() { return aDalsi; }
	void  Dalsi(Uzol* puzol) { aDalsi = puzol; }
};


