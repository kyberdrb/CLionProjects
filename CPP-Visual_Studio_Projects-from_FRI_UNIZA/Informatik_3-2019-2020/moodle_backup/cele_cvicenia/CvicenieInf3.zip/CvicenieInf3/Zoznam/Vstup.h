#pragma once
#include <cstdio>
#include "Uzol.h"

class Vstup
{
private:
	FILE* fhandle = nullptr;
public:
	Vstup(const char* menosuboru);
	~Vstup();
	TYPHODNOTA CitajCislo();
};

