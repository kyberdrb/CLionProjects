#pragma once
#include <cstdio>
#include "Uzol.h"

class Vystup
{
private:
	FILE* fhandle = nullptr;
public:
	Vystup(const char* menosuboru);
	~Vystup();

	void ZapisCislo(TYPHODNOTA cislo);
};

