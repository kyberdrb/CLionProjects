#include "Zoznam.h"
#include "Testy.h"

Zoznam x;

int main()
{
	Testy test;
	bool ok = test.Start();
	if (ok) 
	{
		Zoznam* list = &x;
		list->Sort(".\\vstup.txt");
		list->Uloz(".\\UTRIEDENY.TXT");
		list->Uloz(nullptr); // list.Uloz("");
		//delete list;
	}
	return 0;
}