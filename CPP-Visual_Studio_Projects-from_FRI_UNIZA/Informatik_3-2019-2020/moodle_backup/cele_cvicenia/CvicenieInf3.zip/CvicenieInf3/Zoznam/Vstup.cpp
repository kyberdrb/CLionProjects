#include "Vstup.h"

Vstup::Vstup(const char* menosuboru)
{
	//fhandle = nullptr; // Nulovanie priamo v triede
//	if (menosuboru != nullptr && menosuboru[0] != '\0')
	if (menosuboru && *menosuboru)
		fhandle = fopen(menosuboru, "rt");
}

Vstup::~Vstup()
{
	//if (fhandle != nullptr)
	if (fhandle)
		fclose(fhandle);
}

TYPHODNOTA Vstup::CitajCislo()
{
	if (fhandle != nullptr)
	{
		if (!feof(fhandle))
		{
			TYPHODNOTA cislo;
			fscanf(fhandle, "%d", &cislo);
			return cislo;
		}
	}
	return NEPLATNA_HODNOTA;
}

