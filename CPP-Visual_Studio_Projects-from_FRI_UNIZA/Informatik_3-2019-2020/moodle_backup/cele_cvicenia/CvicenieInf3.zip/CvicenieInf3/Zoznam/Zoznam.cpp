#include "Zoznam.h"
#include "Vstup.h"
#include "Vystup.h"

int Porovnaj(void* prvok1ptr, void* prvok2ptr)
{
	TYPHODNOTA* val1 = (TYPHODNOTA *)prvok1ptr;
	TYPHODNOTA* val2 = (TYPHODNOTA *)prvok2ptr;
	return *val1 - *val2;
}

// menosuboru "sorted.txt"
void Zoznam::Sort(const char* menosuboru)
{
	//char* p = (char*)menosuboru;
	//p[1] = 'F';
	//menosuboru[1] = 'F'; //"sFrted.txt"

	// ALGORITMUS
	// CITAJ PRVOK
	// WHILE(PRVOK!=NEPLATNAHODNOTA) {
	//if (PRVY)
	//	start = prvok;
	//else
	//	ZARAD PRVOK NA SPRAVNE MIESTO;
	//CITAJ DALSI PRVOK;
	//	}
	if (menosuboru && *menosuboru)
	{
		Vstup citac(menosuboru);
		TYPHODNOTA cislo = citac.CitajCislo();
		while (cislo != NEPLATNA_HODNOTA)
		{
			if (aStart == nullptr)
				aStart = new Uzol(cislo, nullptr);
			else
			{
				Uzol* predchadzajuci = nullptr;
				Uzol* aktualny = aStart;
				Uzol* novy;
				while (aktualny != nullptr && Porovnaj(&cislo, aktualny->HodnotaPtr()) > 0)
				{
					predchadzajuci = aktualny;
					aktualny = aktualny->Dalsi();
				}
				novy = new Uzol(cislo, aktualny);
				if (predchadzajuci == nullptr)
					aStart = novy;
				else
					predchadzajuci->Dalsi(novy);
			}
			cislo = citac.CitajCislo();
		}
	}
}

void Zoznam::Uloz(const char* menosuboru)
{
	Vystup zapisovac(menosuboru);
	
	Uzol* aktualny = aStart;
	while (aktualny != nullptr)
	{
		zapisovac.ZapisCislo(*(aktualny->HodnotaPtr()));
		aktualny = aktualny->Dalsi();
	}
}

Zoznam::~Zoznam()
{
	Zmaz(aStart);
}

void Zoznam::Zmaz(Uzol* puzol)
{
	if (puzol->Dalsi() != nullptr)
		Zmaz(puzol->Dalsi());
	delete puzol;
}

