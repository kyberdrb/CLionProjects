#pragma once
#include "Uzol.h"

class Zoznam
{
private:
	Uzol* aStart = nullptr;
	void Zmaz(Uzol* puzol);
public:
	void Sort(const char* menosuboru);
	void Uloz(const char* menosuboru);
	~Zoznam();
};

