#include "Testy.h"
#include "Zoznam.h"

// Start testov programu
bool Testy::Start()
{
	// TODO: Add your implementation code here.
	return true;
}
