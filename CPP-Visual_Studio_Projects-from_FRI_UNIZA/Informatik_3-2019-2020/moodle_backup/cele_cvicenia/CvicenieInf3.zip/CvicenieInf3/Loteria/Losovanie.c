#include <stdlib.h>
#include <time.h>

#include "Losovanie.h"

void Vymen(MUINT index, MUINT i);

void Losuj(MUINT pocet, MUINT pocetLosovanych)
{
	srand(time(0));
	for (MUINT i = 0; i < pocetLosovanych; i++)
	{
		MUINT index = rand() % (pocet - i) + i;
		Vymen(index, i);
	}
}

void Vymen(MUINT index, MUINT i)
{
	struct Zreb pom;
	pom = losy[i];
	losy[i] = losy[index];
	losy[index] = pom;
}
