#pragma once
#include "Data.h"

void Tah(MUINT pocet, MUINT pocetLosovanych);
