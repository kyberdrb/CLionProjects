#include <malloc.h>

#include "Data.h"

struct Zreb* losy;

void PripravZreby(MUINT pocet)
{
	if (pocet != 0) 
	{
		losy = calloc(pocet, sizeof(struct Zreb));
		for (MUINT i = 0; i < pocet; i++)
		{
			losy[i].cislo = i + 1;
			losy[i].nazov = 'A' + (i % 26);
		}
	}
}

void UvolniZreby()
{
	free(losy);
}
