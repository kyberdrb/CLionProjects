#include <stdio.h>

#include "Vystup.h"

void Vypis(MUINT pocetLosovanych)
{
	printf("\nVYSLEDOK ZREBOVANIA\n------------------------------\n");
	for (MUINT i = 0; i < pocetLosovanych; i++)
	{
		printf("%3u. poradie:\t%c %10u\n",
			i + 1,
			losy[i].nazov,
			losy[i].cislo);
	}
	printf("------------------------------\nKONIEC\n");
}
