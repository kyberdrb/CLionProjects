#include "Loteria.h"
#include "VystupFile.h"
#include "Losovanie.h"

void Tah(MUINT pocet, MUINT pocetLosovanych)
{
	PripravZreby(pocet);
	Losuj(pocet, pocetLosovanych);
	Vypis(pocetLosovanych);
	UvolniZreby();
}
