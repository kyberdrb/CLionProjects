#pragma once
#include "Data.h"

void Losuj(MUINT pocet, MUINT pocetLosovanych);
