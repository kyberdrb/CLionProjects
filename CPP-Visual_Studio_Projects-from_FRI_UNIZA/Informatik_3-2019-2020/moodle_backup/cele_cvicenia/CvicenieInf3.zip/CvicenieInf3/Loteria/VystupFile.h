#pragma once

#include "Data.h"

void Vypis(MUINT pocetLosovanych);
