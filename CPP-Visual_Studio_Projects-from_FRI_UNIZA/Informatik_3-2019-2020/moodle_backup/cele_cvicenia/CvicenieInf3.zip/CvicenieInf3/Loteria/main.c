//#define TESTY

#include <stdlib.h>
#include <stdio.h>
#include "Data.h"
#include "Loteria.h"
	

#ifdef TESTY
#include "Test.h"
#endif

int main(int argc, char* argv[])
{
	int ok = 1;
#ifdef TESTY
	ok = Start();
#endif
	if (ok)
	{
		MUINT pocet = (MUINT)atoi(argv[1]);
		MUINT pocetLosovanych = (MUINT)atoi(argv[2]);
		if (pocet != 0)
			Tah(pocet, pocetLosovanych);
		getchar();
	}
	return 0;
}