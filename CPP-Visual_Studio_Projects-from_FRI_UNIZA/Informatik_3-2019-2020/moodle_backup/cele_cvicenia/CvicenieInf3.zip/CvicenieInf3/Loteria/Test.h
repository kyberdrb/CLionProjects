#pragma once
#include "Data.h"
#include "Loteria.h"
#include "Losovanie.h"
#include "Vystup.h"

int Start();
