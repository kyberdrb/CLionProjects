#include "Test.h"

enum { false, true };

int Start()
{
	PripravZreby(10);
	if (losy[9].cislo != 10)
		return false;
	return true;
}
