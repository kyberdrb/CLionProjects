#include <stdio.h>
#include "Data.h"

void Vypis(MUINT pocetLosovanych)
{
	FILE* fd = fopen(".\\VYSLEDOK.TXT", "wt");
	fprintf(fd, "\nVYSLEDOK ZREBOVANIA\n------------------------------\n");
	for (MUINT i = 0; i < pocetLosovanych; i++)
	{
		fprintf(fd, "%3u. poradie:\t%c %10u\n",
			i + 1,
			losy[i].nazov,
			losy[i].cislo);
	}
	fprintf(fd, "------------------------------\nKONIEC\n");
	fclose(fd);
}