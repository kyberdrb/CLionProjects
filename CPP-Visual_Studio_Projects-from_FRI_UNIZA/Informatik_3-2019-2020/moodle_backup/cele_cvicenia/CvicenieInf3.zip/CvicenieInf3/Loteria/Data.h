#pragma once

#ifdef WIN32
	#define MUINT unsigned long
#else
	#define MUINT unsigned int
#endif

struct Zreb
{
	MUINT cislo;
	char nazov;
};

extern struct Zreb* losy;

void PripravZreby(MUINT pocet);
void UvolniZreby();
