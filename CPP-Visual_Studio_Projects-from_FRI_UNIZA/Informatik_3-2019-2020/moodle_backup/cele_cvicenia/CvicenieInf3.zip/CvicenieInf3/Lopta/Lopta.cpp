#include "Lopta.h"

Lopta::Lopta(ISDLSystem* plocha)
	: PohyblivyObjekt(plocha ? plocha->Sirka() : 0, plocha ? plocha->Vyska() : 0),
	hraciaPlocha(plocha)
{
	if (hraciaPlocha)
		lopta = hraciaPlocha->CitajObrazok("ball.bmp");
	if (lopta)
	{
		SetSirka(lopta->Sirka());
		SetVyska(lopta->Vyska());
		Reset();
	}
}

Lopta::~Lopta()
{
	if (hraciaPlocha && lopta)
		hraciaPlocha->Uvolni(lopta);
}

void Lopta::ZobrazSa()
{
	if (hraciaPlocha && lopta)
	{
		hraciaPlocha->Zobraz(*lopta, GetX(), GetY());
	}
}

int Lopta::GetBody()
{
	return 1;
}
