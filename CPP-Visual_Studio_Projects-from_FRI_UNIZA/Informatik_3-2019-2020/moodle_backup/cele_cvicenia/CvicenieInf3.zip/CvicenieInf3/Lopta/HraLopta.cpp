#include "HraLopta.h"
#include "Lopta.h"
#include "Engine.h"
#include "SDLSystem.h"

HraLopta::HraLopta()
	: plocha(new SDLSystem(800,800)),
	lopta(new Lopta(plocha)),
	hra(new Engine(plocha, lopta))
{
}

HraLopta::~HraLopta()
{
	delete hra;
	delete lopta;
	delete plocha;
}

void HraLopta::Start()
{
	if (hra)
		hra->Start();
}
