#include <string>
#include <sstream>

#include "Engine.h"

using namespace std;

void Engine::ZobrazSkore()
{
	if (hraciaPlocha)
	{
		stringstream sts;
		sts << skore;
		hraciaPlocha->ZobrazText(string("Pocet bodov: ") + sts.str());
	}
}

void Engine::Aktualizuj()
{
	if (objekt && hraciaPlocha)
	{
		if (objekt->AktualizujSa(hraciaPlocha->Cas()))
		{
			hraciaPlocha->Zmaz();
			objekt->ZobrazSa();
			hraciaPlocha->AktualizujSa();
		}
	}
}

void Engine::SpracujVstup(int x, int y)
{
	if (objekt && x >= 0)
	{
		if (objekt->Zasah(x, y))
		{
			skore += objekt->GetBody();
			ZobrazSkore();
		}
	}
}

void Engine::Start()
{
	if (hraciaPlocha)
	{
		int x(-1), y(-1);
		ZobrazSkore();
		do {
			Aktualizuj();
			SpracujVstup(x, y);
		} while (hraciaPlocha->DajXY(x, y));
	}
}

Engine::Engine(ISDLSystem* pHraciaPlocha, IObjekt* pobjekt) :
	hraciaPlocha(pHraciaPlocha), objekt(pobjekt)
{
}

Engine::~Engine()
{
}
