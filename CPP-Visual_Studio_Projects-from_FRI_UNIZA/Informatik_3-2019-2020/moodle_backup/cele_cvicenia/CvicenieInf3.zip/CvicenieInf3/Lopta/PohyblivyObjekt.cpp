#include <cstdlib>
#include "PohyblivyObjekt.h"

const int INTERVAL_AKTUALIZACIE = 20;
const int DELTA = 10;

void PohyblivyObjekt::Reset()
{
	x = Generuj(0, sirkaPlochy);
	y = Generuj(0, vyskaPlochy);
	intervalAktualizacie = Generuj(INTERVAL_AKTUALIZACIE, 6 * INTERVAL_AKTUALIZACIE);
	deltaX = Generuj(-DELTA / 2, DELTA / 2);
	deltaY = Generuj(-DELTA / 2, DELTA / 2);
}

void PohyblivyObjekt::SetSirka(int psirka)
{
	sirka = psirka;
}

void PohyblivyObjekt::SetVyska(int pvyska)
{
	vyska = pvyska;
}


int PohyblivyObjekt::Generuj(int zaciatok, int koniec)
{
	if (zaciatok == koniec)
		koniec++;
	if (zaciatok > koniec)
	{
		int pom = zaciatok;
		zaciatok = koniec;
		koniec = pom;
	}
	return rand() % (koniec - zaciatok) + zaciatok;
}

PohyblivyObjekt::PohyblivyObjekt(int pSirkaPlochy, int pVyskaPlochy)
	:x(0), y(0),
	sirka(0), vyska(0),
	casPoslednejAktualizacie(0),
	intervalAktualizacie(0),
	deltaX(0), deltaY(0)
{
}

int PohyblivyObjekt::GetX()
{
	return x;
}

int PohyblivyObjekt::GetY()
{
	return y;
}

int PohyblivyObjekt::GetSirka()
{
	return sirka;
}

int PohyblivyObjekt::GetVyska()
{
	return vyska;
}

bool PohyblivyObjekt::Zasah(int px, int py)
{
	return (px >= x && px <= x + sirka && py >= y && py <= y + vyska);
}


bool PohyblivyObjekt::AktualizujSa(int cas)
{
	if ((cas - casPoslednejAktualizacie) > intervalAktualizacie)
	{
		x += deltaX;
		if (x < 0 || x >= sirkaPlochy - sirka)
		{
			deltaX = -deltaX;
			x += deltaX;
		}

		y += deltaY;
		if (y < 0 || y >= vyskaPlochy - vyska)
		{
			deltaY = -deltaY;
			y += deltaY;
		}
		casPoslednejAktualizacie = cas;
		return true;
	}
	return false;
}

