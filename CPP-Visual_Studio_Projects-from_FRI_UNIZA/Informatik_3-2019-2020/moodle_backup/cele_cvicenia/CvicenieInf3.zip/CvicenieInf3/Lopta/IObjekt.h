#pragma once
class IObjekt
{
public:
	virtual ~IObjekt() {}
	virtual int GetX() = 0;
	virtual int GetY() = 0;
	virtual int GetSirka() = 0;
	virtual int GetVyska() = 0;
	virtual void SetSirka(int psirka) = 0;
	virtual void SetVyska(int pvyska) = 0;

	virtual int GetBody() = 0;

	virtual bool Zasah(int x, int y) = 0;
	virtual void ZobrazSa() = 0;
	virtual bool AktualizujSa(int cas) = 0;
};

