#pragma once
#include "IEngine.h"
#include "ISDLSystem.h"
#include "IObjekt.h"

class Engine : public IEngine
{
private:
	int skore = 0;
	ISDLSystem* hraciaPlocha;
	IObjekt* objekt;

	void ZobrazSkore();
	void Aktualizuj();
	void SpracujVstup(int x, int y);
public:
	// Inherited via IEngine
	virtual void Start() override;

	Engine(ISDLSystem* pHraciaPlocha, IObjekt* pobjekt);
	~Engine();
};

