#pragma once
class ISDLSystem;
class Lopta;
class Engine;

class HraLopta
{
private:
	ISDLSystem* plocha;
	Lopta* lopta;
	Engine* hra;
public:
	HraLopta();
	~HraLopta();
	void Start();
};

