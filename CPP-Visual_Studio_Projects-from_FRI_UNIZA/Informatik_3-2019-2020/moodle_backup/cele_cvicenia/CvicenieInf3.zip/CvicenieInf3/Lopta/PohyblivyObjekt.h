#pragma once
#include "IObjekt.h"
class PohyblivyObjekt : public IObjekt
{
private:
	int x, y;
	int sirka, vyska;
	int casPoslednejAktualizacie; // cas poslednej zmeny polohy objektu
	int intervalAktualizacie; // pocet milisekund, ktore musia uplynyt aby sa objekt pohol
	int deltaX, deltaY;
	int sirkaPlochy, vyskaPlochy;
	int Generuj(int zaciatok, int koniec);
public:
	PohyblivyObjekt(int pSirkaPlochy, int pVyskaPlochy);
	// Inherited via IObjekt
	virtual int GetX() override;
	virtual int GetY() override;
	virtual int GetSirka() override;
	virtual int GetVyska() override;

	virtual bool Zasah(int px, int py) override;
	virtual bool AktualizujSa(int cas) override;

	void Reset();

	// Inherited via IObjekt
	virtual void SetSirka(int psirka) override;
	virtual void SetVyska(int pvyska) override;
};

