#pragma once
#include "PohyblivyObjekt.h"
#include "ISDLSystem.h"

class Lopta : public PohyblivyObjekt
{
private:
	ISDLSystem* hraciaPlocha = nullptr;
	ISDLSystem* lopta = nullptr;
public:
	Lopta(ISDLSystem* plocha);
	~Lopta();
	// Inherited via PohyblivyObjekt
	virtual void ZobrazSa() override;

	// Inherited via PohyblivyObjekt
	virtual int GetBody() override;
};

