#pragma once
class BinCislo
{
private:
	long long aCislo;
	long long Bin2Dec(const char* pCislo);
	const char* Dec2Bin(char* ciel, long long pCislo);
public:
	BinCislo(long long pCislo = 0) : aCislo(pCislo) {}
	BinCislo(const char* pCislo) : aCislo(Bin2Dec(pCislo)) {}
	void VypisKonzola();
	friend BinCislo operator +(BinCislo op1, BinCislo op2);
	friend BinCislo operator -(BinCislo op1, BinCislo op2);
	friend BinCislo operator /(BinCislo op1, BinCislo op2);
	friend BinCislo operator *(BinCislo op1, BinCislo op2);
	friend bool operator <(BinCislo op1, BinCislo op2);
	friend bool operator >(BinCislo op1, BinCislo op2);
	friend bool operator ==(BinCislo op1, BinCislo op2);
	friend bool operator <=(BinCislo op1, BinCislo op2);
	friend bool operator >=(BinCislo op1, BinCislo op2);
	friend bool operator !=(BinCislo op1, BinCislo op2);
};


inline BinCislo operator+(BinCislo op1, BinCislo op2)
{
	return op1.aCislo + op2.aCislo;
}
inline BinCislo operator-(BinCislo op1, BinCislo op2)
{
	return op1.aCislo - op2.aCislo;
}
inline BinCislo operator/(BinCislo op1, BinCislo op2)
{
	return op1.aCislo / op2.aCislo;
}

inline BinCislo operator*(BinCislo op1, BinCislo op2)
{
	return op1.aCislo * op2.aCislo;
}

inline bool operator<(BinCislo op1, BinCislo op2)
{
	return op1.aCislo < op2.aCislo;
}

inline bool operator>(BinCislo op1, BinCislo op2)
{
	return op1.aCislo > op2.aCislo;
}

inline bool operator==(BinCislo op1, BinCislo op2)
{
	return op1.aCislo == op2.aCislo;
}

inline bool operator<=(BinCislo op1, BinCislo op2)
{
	return !(op1 > op2);
}

inline bool operator>=(BinCislo op1, BinCislo op2)
{
	return !(operator<(op1, op2));
	//return !(op1  < op2);
}

inline bool operator!=(BinCislo op1, BinCislo op2)
{
	return !(op1 == op2);
}
