#include "Testy.h"
#include "BinCislo.h"

// Start testov programu
bool Testy::Start()
{
	BinCislo a(-25), b("-111011"), c,d,e;
	a.VypisKonzola();
	b.VypisKonzola();
	c.VypisKonzola();
	c = a + b;
	c.VypisKonzola();
	d = a + 24;
	d.VypisKonzola();
	e = 24 + a;
	e.VypisKonzola();
	return true;
}

