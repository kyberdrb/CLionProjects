#include <cstring>
#include <cstdlib>
#include <iostream>

#include "BinCislo.h"

using namespace std;

long long BinCislo::Bin2Dec(const char* pCislo)
{
	long long vysledok{ 0 };
	if (pCislo && *pCislo)
	{
		char* pomcislo = new char[strlen(pCislo) + 1];
		strcpy(pomcislo, pCislo);
		strrev(pomcislo);

		int i(0);
		while (pomcislo[i])
		{
			if (pomcislo[i] == '1')
				vysledok += (1 << i);
			i++;
		}
		if (pCislo[0] == '-')
			vysledok = -vysledok;

		delete[] pomcislo;
	}
	return vysledok;
}

const char* BinCislo::Dec2Bin(char* ciel, long long pCislo)
{
	if (ciel)
	{
		long long pomcislo = abs(pCislo);
		int i(0);
		do
		{
			ciel[i++] = pomcislo % 2 + '0';
			pomcislo >>= 1; //pomcislo /= 2;
		} while (pomcislo > 0);
		
		if (pCislo < 0)
			ciel[i++] = '-';
		ciel[i] = '\0';
		strrev(ciel);
	}
	return ciel;
}

void BinCislo::VypisKonzola()
{
	char *pombuf = new char[66];
	cout << Dec2Bin(pombuf, aCislo) << endl;
	delete[] pombuf;

	//char *pombuf = new char[66];
	//Dec2Bin(pombuf, aCislo);
	//cout << pombuf << endl;
	//delete[] pombuf;

	//char pombuf[66];
	//Dec2Bin(pombuf, aCislo);
	//cout << pombuf << endl;
}

