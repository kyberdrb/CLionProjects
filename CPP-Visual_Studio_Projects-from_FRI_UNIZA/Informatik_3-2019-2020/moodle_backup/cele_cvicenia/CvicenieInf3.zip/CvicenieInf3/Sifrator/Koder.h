#pragma once
#include "Heslo.h"

const unsigned /*int*/ DLZKA_TABULKY = 256;

class Koder
{
private:
	unsigned char aKodovaciaTabulka[DLZKA_TABULKY];

private:
	void ZakodujTabulku(UCHPTR heslo);
	unsigned int DajNasadu(UCHPTR heslo);
	void Vymen(unsigned char& prvok1, unsigned char& prvok2);
	void VymenKodovaciuTabulku();
public:
	Koder();
	~Koder() {}

	//unsigned char* Koduj(const unsigned char* heslo, const unsigned char* text4kodovanie);
	//unsigned char* Dekoduj(const unsigned char* heslo, const unsigned char* text4dekodovanie);
	unsigned char* Koduj(UCHPTR heslo, UCHPTR text4kodovanie);
	unsigned char* Dekoduj(UCHPTR heslo, UCHPTR text4dekodovanie);
};

