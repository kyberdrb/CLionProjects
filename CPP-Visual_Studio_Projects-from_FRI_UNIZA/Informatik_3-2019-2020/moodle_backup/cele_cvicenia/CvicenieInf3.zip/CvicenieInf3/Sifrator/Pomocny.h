#pragma once

char* SkopirujRetazec(const char* src);
