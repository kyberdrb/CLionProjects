#pragma once
#include "Subor.h"
#include "Heslo.h"

class Vstup : public Subor
{
private:
	int DajDlzkuSuboru();
public:
	Vstup(const char* pMenoSuboru) : Subor(pMenoSuboru) {}
	Vstup(const Vstup& src) : Subor(src) {};

	UCHPTR Citaj();
};

