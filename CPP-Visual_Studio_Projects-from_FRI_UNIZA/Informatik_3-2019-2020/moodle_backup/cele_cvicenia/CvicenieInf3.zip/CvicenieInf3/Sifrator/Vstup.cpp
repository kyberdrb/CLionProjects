#include <cstdio>
#include "Vstup.h"

int Vstup::DajDlzkuSuboru()
{
	int dlzka{ 0 };
	if (aMenoSuboru)
	{
		FILE* f = fopen(aMenoSuboru, "rb");
		if (f)
		{
			fseek(f, 0, SEEK_END);
			dlzka = ftell(f);
			fclose(f);
		}
	}
	return dlzka;
}

UCHPTR Vstup::Citaj()
{
	if (aMenoSuboru)
	{
		int dlzka = DajDlzkuSuboru();
		if (dlzka > 0)
		{
			unsigned char* text = new unsigned char[dlzka + 1];
			if (text)
			{
				FILE* f = fopen(aMenoSuboru, "rb");
				if (f)
				{
					fread((char*)text, dlzka, 1, f);
					text[dlzka] = '\0';
					fclose(f);
					return text;
				}
			}
		}
	}
	return nullptr;
}
