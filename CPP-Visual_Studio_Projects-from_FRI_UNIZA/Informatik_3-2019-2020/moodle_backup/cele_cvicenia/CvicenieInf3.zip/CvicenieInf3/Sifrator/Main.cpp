//#define TESTY
#include <iostream>
#include "Sifrator.h"

#ifdef TESTY
#include "Testy.h"
#endif

using namespace std;

int main(int argc, char** argv)
{
	bool OK = true;
#ifdef TESTY
	//Testy test;
	//OK = test.Start();
	OK = Testy().Start();
#endif
	if (OK)
	{
		char cinnost('h');
		char* heslo = nullptr;
		char* menoInSubor = nullptr;
		bool konzola(true);
		char* menoOutSubor = nullptr;

		if (argc > 1)
			cinnost = argv[1][0];
		if (argc > 2)
			heslo = argv[2];
		if (argc > 3)
			menoInSubor = argv[3];
		if (argc > 4)
			konzola = argv[4][0] == 's' ? false : true;
		if (argc > 5)
			menoOutSubor = argv[5];

		Sifrator(cinnost, (UCHPTR)heslo, (UCHPTR)menoInSubor, konzola, (UCHPTR)menoOutSubor).Start();
	}
	else
		cout << "NEPRESLI TESTY" << endl;
}