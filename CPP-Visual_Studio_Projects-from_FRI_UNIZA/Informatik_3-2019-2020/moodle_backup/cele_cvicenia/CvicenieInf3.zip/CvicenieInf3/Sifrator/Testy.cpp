#include "Testy.h"
#include "Koder.h"
#include "Vstup.h"
#include "Vystup.h"

void Fun(const Subor& subor)
{

}
// Start testov programu
bool Testy::Start()
{
	Koder koder, dekoder;
	//Vstup citac("main.cpp"); // , citac2("Koder.cpp"), x("a.txt"); // , citac2(citac);
	UCHPTR zdrojtext = Vstup("main.cpp").Citaj();
	Vystup subor("main.kod"), displej;
	unsigned char* zakodovanytext = koder.Koduj((UCHPTR)"viliam", zdrojtext);
	subor.Zapis(zakodovanytext);
	displej.Zapis(zakodovanytext);
	unsigned char* dekodovanytext = dekoder.Dekoduj((UCHPTR)"viliam", (UCHPTR)zakodovanytext);
	Vystup deksubor("main.cpp.copy");
	
	deksubor.Zapis(dekodovanytext);

	delete[] dekodovanytext;
	delete[] zakodovanytext;
	delete[] zdrojtext;
	return true;
}
