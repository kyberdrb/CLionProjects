#include "Help.h"
#include "Vystup.h"

void Help::Vypis()
{
	Vystup().Zapis((unsigned char*)
		"Sifrator CINNOST HESLO VSTUP_SUBOR [TYP_VYSTUPU] [VYST_SUBOR]\n"
		"   CINNOST:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...help\n"
		"   HESLO: max. 8 znakov\n"
		"   VSTUP_SUBOR: nazov vstupneho suboru\n"
		"   TYP_VYSTUPU:\n"
		"      s...subor\n"
		"      c...konzola\n"
		"   VYSTUP_SUBOR: nazov vystupneho suboru\n\n"
	);
}
