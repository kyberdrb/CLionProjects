#include <cstring>
#include "Subor.h"
#include "Pomocny.h"

Subor::Subor(const char* pMenoSuboru)
{
	aMenoSuboru = SkopirujRetazec(pMenoSuboru);
}

Subor::Subor(const Subor& src)
{
	aMenoSuboru = SkopirujRetazec(src.aMenoSuboru);
}

Subor& Subor::operator=(const Subor& src)
{
	if (this != &src)
	{
		delete[] this->aMenoSuboru;
		aMenoSuboru = SkopirujRetazec(src.aMenoSuboru);
	}
	return *this;
}

Subor::~Subor()
{
	delete[] aMenoSuboru;
}
