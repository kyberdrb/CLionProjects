#include <random>
#include "Koder.h"
#include <cstring>

using namespace std;
// 1. Ziskaj nasadu generatora nahodnych cisel prostrednictvom hesla
// 2. Nastav asadu
// 3. Premiesaj kodovaciu tabulku
void Koder::ZakodujTabulku(UCHPTR heslo)
{
	//unsigned int nasada = DajNasadu(heslo);
	//default_random_engine generator;
	//generator.seed(nasada);

	default_random_engine generator;
	generator.seed(DajNasadu(heslo));
	for (int i = 0; i < DLZKA_TABULKY; i++)
	{
		uniform_int_distribution<int> distribution(0, DLZKA_TABULKY - i);
		int index = distribution(generator);
		Vymen(aKodovaciaTabulka[index], aKodovaciaTabulka[DLZKA_TABULKY - i - 1]);
	}
}

unsigned int Koder::DajNasadu(UCHPTR heslo)
{
	return Heslo(heslo).DajNasadu();
}

void Koder::Vymen(unsigned char& prvok1, unsigned char& prvok2)
{
	unsigned char c(prvok1);
	prvok1 = prvok2;
	prvok2 = c;
}

Koder::Koder()
{
	for (size_t i = 0; i < DLZKA_TABULKY; i++)
		aKodovaciaTabulka[i] = i;
}

// 1. Zakoduj kodovaciu tabulku (aKodovaciaTabulka)
// 2. Zakoduj text
// 3. Zasifruj text
unsigned char* Koder::Koduj(UCHPTR heslo, UCHPTR text4kodovanie)
{
	unsigned char* retval = nullptr;
	if (heslo && text4kodovanie && *text4kodovanie)
	{
		ZakodujTabulku(heslo);
		int dlzka = strlen((char*)text4kodovanie);
		unsigned char* pomText4kodovanie = new unsigned char[dlzka];
		if (pomText4kodovanie)
		{
			for (int i = 0; i < dlzka; i++)
				pomText4kodovanie[i] = aKodovaciaTabulka[text4kodovanie[i]];
			unsigned char* zasifrovanyText = new unsigned char[3 * dlzka + 1];
			if (zasifrovanyText)
			{
				unsigned char* ptr = zasifrovanyText;
				for (int i = 0; i < dlzka; i++)
				{
					char pombuf[4];
					sprintf(pombuf, "%03u", pomText4kodovanie[i]);
					memmove(ptr, pombuf, 3);
					ptr += 3;
				}
				*ptr = '\0';
				retval = zasifrovanyText;
			}
			delete[] pomText4kodovanie;
		}
	}
	return retval;
}

unsigned char* Koder::Dekoduj(UCHPTR heslo, UCHPTR text4dekodovanie)
{
	unsigned char* retval = nullptr;
	if (heslo && text4dekodovanie && *text4dekodovanie)
	{
		ZakodujTabulku(heslo);
		VymenKodovaciuTabulku();
		int dlzka = strlen((char *)text4dekodovanie);
		unsigned char* desifrovanyText = new unsigned char[dlzka / 3 + 1];
		if (desifrovanyText)
		{
			int k = 0;
			char bufcislo[4]{};
			for (int i = 0; i < dlzka; i+=3)
			{
				memmove(bufcislo, &text4dekodovanie[i], 3);
				desifrovanyText[k++] = aKodovaciaTabulka[atoi(bufcislo)];
			}
			desifrovanyText[k] = '\0';
			return desifrovanyText;
		}
	}
	return nullptr;
}

void Koder::VymenKodovaciuTabulku()
{
	unsigned char pomtabulka[DLZKA_TABULKY];
	for (int i = 0; i < DLZKA_TABULKY; i++)
		pomtabulka[aKodovaciaTabulka[i]] = i;
	memmove(aKodovaciaTabulka, pomtabulka, DLZKA_TABULKY * sizeof(unsigned char));
}

