#pragma once
#include <cstring>

typedef const unsigned char* UCHPTR;
const int DLZKA_HESLA = 8;

class Heslo
{
private:
	union
	{
		UCHPTR aHeslo[DLZKA_HESLA];
		long long aNasada = 0;
	};
public:
	Heslo(UCHPTR heslo)
	{
		if (heslo && *heslo)
		{
			int dlzka = strlen((char*)heslo);

			dlzka = dlzka > 8 ? 8 : dlzka;
			memmove(aHeslo, heslo, dlzka);
		}
	}
	unsigned DajNasadu()
	{
		unsigned int nasadaLO = aNasada & 0x00000000ffffffff;
		unsigned int nasadaHI = (aNasada >> 32) & 0x00000000ffffffff;
		return nasadaLO + nasadaHI;
	}
};

