#include <cctype>
#include "Sifrator.h"
#include "Pomocny.h"
#include "Vstup.h"
#include "Vystup.h"
#include "Koder.h"
#include "Help.h"

void Sifrator::VypisHelp()
{
	Help().Vypis();
}

void Sifrator::Kopiruj(const Sifrator& zdroj)
{
	aCinnost = zdroj.aCinnost;
	aHeslo = (unsigned char*)SkopirujRetazec((const char*)zdroj.aHeslo);
	aMenoInSubor = (unsigned char*)SkopirujRetazec((const char*)zdroj.aMenoInSubor);
	aKonzola = zdroj.aKonzola;
	aMenoOutSubor = (unsigned char*)SkopirujRetazec((const char*)zdroj.aMenoOutSubor);
}

Sifrator::Sifrator(char cinnost, UCHPTR heslo, UCHPTR menoInSubor, bool konzola, UCHPTR menoOutSubor)
{
	aCinnost = tolower(cinnost);
	aCinnost = (aCinnost != 's' && aCinnost != 'd' && aCinnost != 'h') ? 'h' : aCinnost;
	aHeslo = (unsigned char*)SkopirujRetazec((const char*)heslo);
	if (!aHeslo)
		aCinnost = 'h';
	aMenoInSubor = (unsigned char*)SkopirujRetazec((const char*)menoInSubor);
	if (!aMenoInSubor)
		aCinnost = 'h';
	aKonzola = konzola;
	aMenoOutSubor = (unsigned char*)SkopirujRetazec((const char*)menoOutSubor);
	if (!aMenoOutSubor)
		aKonzola = true;
}

Sifrator::Sifrator(const Sifrator& zdroj)
{
	Kopiruj(zdroj);
}

Sifrator& Sifrator::operator=(const Sifrator& zdroj)
{
	if (this != &zdroj)
	{
		Sifrator::~Sifrator();	// Zmazem povodny obsah

		Kopiruj(zdroj);			// Nakopirujem novy obsah zo zdroja
	}
	return *this;
}

void Sifrator::Start()
{
	if (aCinnost == 'h')
		VypisHelp();
	else
	{
		UCHPTR zdrojtext = Vstup((const char*)aMenoInSubor).Citaj();
		if (zdrojtext)
		{
			UCHPTR cieltext = (aCinnost == 's') ?
				Koder().Koduj(aHeslo, zdrojtext) :
				Koder().Dekoduj(aHeslo, zdrojtext);
			if (cieltext)
			{
				Vystup((const char*)aMenoOutSubor).Zapis((unsigned char*)cieltext);
				delete[] cieltext;
			}
			delete[] zdrojtext;
		}
	}
}
