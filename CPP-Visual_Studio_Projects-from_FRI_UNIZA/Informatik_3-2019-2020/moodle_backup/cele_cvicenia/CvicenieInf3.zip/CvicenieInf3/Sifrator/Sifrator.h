#pragma once
#include "Heslo.h"

class Sifrator
{
private:
	char aCinnost = 'h';
	unsigned char* aHeslo = nullptr;
	unsigned char* aMenoInSubor = nullptr;
	bool aKonzola = true;
	unsigned char* aMenoOutSubor = nullptr;
	void VypisHelp();
	void Kopiruj(const Sifrator& zdroj);
public:
	Sifrator(char cinnost, UCHPTR heslo, UCHPTR menoInSubor, bool konzola, UCHPTR menoOutSubor);
	Sifrator(const Sifrator& zdroj);
	Sifrator& operator =(const Sifrator& zdroj);
	void Start();

	~Sifrator()
	{
		delete[] aMenoOutSubor;
		delete[] aMenoInSubor;
		delete[] aHeslo;
	}
};

