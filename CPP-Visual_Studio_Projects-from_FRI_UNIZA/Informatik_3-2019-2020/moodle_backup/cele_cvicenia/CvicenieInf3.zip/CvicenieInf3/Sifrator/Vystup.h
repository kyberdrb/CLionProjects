#pragma once
#include "Subor.h"
#include "Heslo.h"

class Vystup : public Subor
{
public:
	Vystup(const char* pMenoSuboru = nullptr) : Subor(pMenoSuboru) {}
	Vystup(const Vystup& src) : Subor(src) {};

	void Zapis(unsigned char* text);
};

