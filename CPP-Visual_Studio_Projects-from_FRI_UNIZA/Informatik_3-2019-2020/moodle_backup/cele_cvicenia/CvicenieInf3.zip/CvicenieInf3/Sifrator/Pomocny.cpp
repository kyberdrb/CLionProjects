#include <cstring>

#include "Pomocny.h"

char* SkopirujRetazec(const char* src)
{
	char* result = nullptr;
	if (src && *src)
	{
		int dlzka = strlen(src);
		result = new char[dlzka + 1];
		strcpy(result, src);
	}
	return result;
}
