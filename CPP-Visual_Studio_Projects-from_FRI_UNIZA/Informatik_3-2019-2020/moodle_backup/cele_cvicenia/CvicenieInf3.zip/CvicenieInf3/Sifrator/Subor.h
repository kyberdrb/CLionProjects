#pragma once
class Subor
{
protected:
	char* aMenoSuboru = nullptr;
public:
	Subor(const char* pMenoSuboru);
	Subor(const Subor& src);
	Subor& operator = (const Subor& src);

	~Subor();
};

