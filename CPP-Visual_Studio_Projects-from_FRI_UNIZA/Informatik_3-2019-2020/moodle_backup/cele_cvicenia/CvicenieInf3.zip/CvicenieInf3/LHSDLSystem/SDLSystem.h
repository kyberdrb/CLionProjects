#pragma once
#include "ISDLSystem.h"
class SDLSystem : public ISDLSystem
{
public:
	SDLSystem(int sirka, int vyska);
	// Inherited via ISDLSystem
	virtual int Sirka() override;
	virtual int Vyska() override;
	virtual ISDLSystem* CitajObrazok(const char* menoSuboru) override;
	virtual void Uvolni(ISDLSystem* obj) override;
	virtual void Zobraz(ISDLSystem& obj, int x, int y) override;
	virtual bool DajXY(int& x, int& y) override;
	virtual void ZobrazText(string text) override;
	virtual int Cas() override;
	virtual void Zmaz() override;
	virtual void AktualizujSa() override;
};

