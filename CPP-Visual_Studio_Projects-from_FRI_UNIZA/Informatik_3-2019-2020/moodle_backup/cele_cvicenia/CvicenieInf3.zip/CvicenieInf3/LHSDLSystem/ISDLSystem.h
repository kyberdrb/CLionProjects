#pragma once
#include <string>

using namespace std;

class ISDLSystem
{
public:
	virtual ~ISDLSystem() {};
	virtual int Sirka() = 0;
	virtual int Vyska() = 0;
	virtual ISDLSystem* CitajObrazok(const char* menoSuboru) = 0;
	virtual void Uvolni(ISDLSystem* obj) = 0;
	virtual void Zobraz(ISDLSystem& obj, int x, int y) = 0;
	virtual bool DajXY(int& x, int& y) = 0;
	virtual void ZobrazText(string text) = 0;
	virtual int Cas() = 0;
	virtual void Zmaz() = 0;
	virtual void AktualizujSa() = 0;
};
