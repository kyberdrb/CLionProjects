#include "SDLSystem.h"

SDLSystem::SDLSystem(int sirka, int vyska)
{
}

int SDLSystem::Sirka()
{
	return 0;
}

int SDLSystem::Vyska()
{
	return 0;
}

ISDLSystem* SDLSystem::CitajObrazok(const char* menoSuboru)
{
	return nullptr;
}

void SDLSystem::Uvolni(ISDLSystem* obj)
{
}

void SDLSystem::Zobraz(ISDLSystem& obj, int x, int y)
{
}

bool SDLSystem::DajXY(int& x, int& y)
{
	return false;
}

void SDLSystem::ZobrazText(string text)
{
}

int SDLSystem::Cas()
{
	return 0;
}

void SDLSystem::Zmaz()
{
}

void SDLSystem::AktualizujSa()
{
}
