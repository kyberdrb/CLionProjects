#include "Strom.h"

int main()
{
	Strom strom;

	strom.Vloz(6);
	strom.Vloz(2);
	strom.Vloz(8);
	strom.Vloz(4);
	strom.Vypis();

	return 0;
}