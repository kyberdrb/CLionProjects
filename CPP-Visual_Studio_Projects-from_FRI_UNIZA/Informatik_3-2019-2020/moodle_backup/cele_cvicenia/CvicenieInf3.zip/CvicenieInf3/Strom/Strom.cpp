#include <iostream>

#include "Strom.h"

void Strom::ZrusStrom(Uzol* uzol)
{
	if (uzol != nullptr)
	{
		ZrusStrom(uzol->Lavy());
		ZrusStrom(uzol->Pravy());
		delete uzol;
	}
}

void Strom::Vloz(int data, Uzol* uzol)
{
	if (data < uzol->Data())
	{
		if (uzol->Lavy() != nullptr)
			Vloz(data, uzol->Lavy());
		else
			uzol->Lavy(new Uzol(data));
	}
	else
	{
		if (uzol->Pravy() != nullptr)
			Vloz(data, uzol->Pravy());
		else
			uzol->Pravy(new Uzol(data));
	}

}

void Strom::Vypis()
{
	Vypis(aKoren);
}

void Strom::Vypis(Uzol* uzol)
{
	if (uzol != nullptr)
	{
		Vypis(uzol->Lavy());
		std::cout << uzol->Data() << std::endl;
		Vypis(uzol->Pravy());
	}
}

void Strom::Vloz(int data)
{
	if (aKoren == nullptr)
		aKoren = new Uzol(data);
	else
		Vloz(data, aKoren);
}

