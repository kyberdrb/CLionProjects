#pragma once
class Strom
{
private:
	class Uzol {
		int aData;
		Uzol* aLavy = nullptr;
		Uzol* aPravy = nullptr;
	public:
		Uzol(int data, Uzol* lavy = nullptr, Uzol* pravy = nullptr)
			: aData(data), aLavy(lavy), aPravy(pravy) { }

		int Data() { return aData; }
		inline Uzol* Lavy();
		inline Uzol* Pravy();
		void Data(int pdata) { aData = pdata; }
		void Lavy(Uzol* puzol) { aLavy = puzol; }
		void Pravy(Uzol* puzol) { aPravy = puzol; }

	} *aKoren = nullptr;
	void ZrusStrom(Uzol* uzol);
	void Vloz(int data, Uzol* uzol);
	void Vypis(Uzol* uzol);
public:
	Strom() {}
	~Strom() { ZrusStrom(aKoren); }
	void Vloz(int data);
	void Vypis();
};

inline Strom::Uzol* Strom::Uzol::Lavy()
{
	return aLavy;
}

inline Strom::Uzol* Strom::Uzol::Pravy()
{
	return aPravy;
}
