#pragma once
#include "Tovar.h"

const unsigned int KAPACITA_SKLADU = 100;

class Sklad
{
private:
	static Sklad* SkladJedinacik;

	Tovar* aZasoby = nullptr;
	int aPocet = 0;
	Tovar* Realokuj();
	void Sort(PorovnajPtr compareFun);
	void VytvorPolePtr(Tovar**& ptrzasob);
	void Vypis(Tovar** zasoby);
	Sklad() {}
	Sklad(const Sklad &zdroj) {}

public:
	virtual ~Sklad() { 
		delete[] aZasoby; 
	}
	bool Pridaj(const char* pNazov, int pCena, int pPocet = 1);
	void ZobrazPodlaNazov();
	void ZobrazPodlaCena();
	void ZobrazPodlaPocet();
	static Sklad& GetSklad();
	static void ZrusSklad() { delete SkladJedinacik; }
};

