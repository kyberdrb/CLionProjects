#include <cstring>
#include "Tovar.h"

using namespace std;

eTypSort Tovar::Typ{ eTypSort::Nazov };

char* Copy(const char* zdroj)
{
	char* ciel = nullptr;
	if (zdroj && *zdroj)
	{
		int dlzka = strlen(zdroj);
		ciel = new char[dlzka + 1];
		strcpy(ciel, zdroj);
	}
	return ciel;
}


Tovar& Tovar::operator=(const Tovar& zdroj)
{
	if (&zdroj != this)
	{
		Tovar::~Tovar();
		Cena(zdroj.Cena());
		Regal(zdroj.Regal());
		Pocet(zdroj.Pocet());
		Nazov(zdroj.Nazov());
	}
	return *this;
}

bool operator<(Tovar& tovar1, Tovar& tovar2)
{
	int ret = 0;
	int retnazov = strcmp(tovar1.Nazov(), tovar2.Nazov());
	int retcena = tovar1.Cena() - tovar2.Cena();
	int retpocet = tovar1.Pocet() - tovar2.Pocet();
	switch (Tovar::Typ)
	{
	case eTypSort::Nazov:
		ret = retnazov;
		if (ret == 0)
		{
			ret = retcena;
			if (ret == 0)
				ret = retpocet;
		}
		break;
	case eTypSort::Cena:
		ret = retcena;
		if (ret == 0)
		{
			ret = retnazov;
			if (ret == 0)
				ret = retpocet;
		}
		break;
	case eTypSort::Pocet:
		ret = retpocet;
		if (ret == 0)
		{
			ret = retnazov;
			if (ret == 0)
				ret = retcena;
		}
		break;
	}
	return ret > 0;
}

std::ostream& operator<<(std::ostream& os, Tovar& tovar)
{
	switch (Tovar::Typ)
	{
	case eTypSort::Nazov:
		os << "Nazov: " << tovar.Nazov() << endl;
		os << "Cena : " << tovar.Cena() << endl;
		os << "Pocet: " << tovar.Pocet() << endl;
		break;
	case eTypSort::Cena:
		os << "Cena : " << tovar.Cena() << endl;
		os << "Nazov: " << tovar.Nazov() << endl;
		os << "Pocet: " << tovar.Pocet() << endl;
		break;
	case eTypSort::Pocet:
		os << "Pocet: " << tovar.Pocet() << endl;
		os << "Nazov: " << tovar.Nazov() << endl;
		os << "Cena : " << tovar.Cena() << endl;
		break;
	}
	return os;
}
