#include "Sklad.h"

int main()
{
	Sklad& sklad = Sklad::GetSklad();
	Sklad &sklad2 = Sklad::GetSklad();

	sklad.Pridaj("Jablko", 10, 100);
	sklad.Pridaj("Hruska", 20, 30);
	sklad.Pridaj("Slivka", 120, 130);
	sklad.Pridaj("Marhula", 110, 60);
	sklad.Pridaj("Ananas", 210, 5);
	sklad.Pridaj("Kiwi", 150, 65);
	sklad.Pridaj("Mandarinka", 150, 65);
	sklad.Pridaj("Pomaranc", 350, 465);
	sklad2.Pridaj("Banan", 51, 46);
	sklad.ZobrazPodlaNazov();
	sklad.ZobrazPodlaCena();
	sklad.ZobrazPodlaPocet();
	Sklad::ZrusSklad();
	return 0;
}