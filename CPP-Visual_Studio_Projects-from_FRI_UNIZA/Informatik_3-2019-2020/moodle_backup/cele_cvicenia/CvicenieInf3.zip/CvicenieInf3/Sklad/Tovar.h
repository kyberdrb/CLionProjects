#pragma once
#include <iostream>

typedef int (*PorovnajPtr)(const void* parameter1, const void* parameter2);

char* Copy(const char* zdroj);

enum eTypSort { Nazov, Cena, Pocet };

class Tovar
{
public:
	static eTypSort Typ;

private:
	int aPocet = 0;
	char* aNazov = nullptr;
	double aCena = 0;
	int aRegal = 0;
public:
	Tovar() {}
	Tovar(const Tovar& zdroj)
		: aPocet(zdroj.aPocet), aNazov(Copy(zdroj.aNazov)), aCena(zdroj.aCena), aRegal(zdroj.aRegal)
	{}
	Tovar& operator =(const Tovar& zdroj);
	virtual ~Tovar() { delete[] aNazov; }
	int Pocet() const { return aPocet; }
	const char* Nazov() const { return aNazov; }
	double Cena() const { return aCena; }
	int Regal() const { return aRegal; }

	void Pocet(int pPocet) { aPocet = pPocet; }
	void Nazov(const char* pNazov) { aNazov = Copy(pNazov); }
	void Cena(double pCena) { aCena = pCena; }
	void Regal(int pRegal) { aRegal = pRegal; }
	friend bool operator <(Tovar& tovar1, Tovar& tovar2);
	friend std::ostream& operator <<(std::ostream& os, Tovar& tovar);
};



