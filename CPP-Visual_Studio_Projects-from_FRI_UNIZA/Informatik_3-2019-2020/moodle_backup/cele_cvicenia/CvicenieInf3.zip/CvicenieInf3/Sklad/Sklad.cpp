#include <cstdlib>
#include <iostream>
#include "Sklad.h"

Sklad* Sklad::SkladJedinacik = nullptr;

int PorovnajFun(const void* parameter1, const void* parameter2);

Tovar* Sklad::Realokuj()
{
	Tovar* pomZasoby = new Tovar[aPocet + 1];
	if (aZasoby)
	{
		for (unsigned i = 0; i < aPocet; i++)
			pomZasoby[i] = aZasoby[i];
		delete[] aZasoby;
	}
	aPocet++;
	return pomZasoby;
}

bool Sklad::Pridaj(const char* pNazov, int pCena, int pPocet)
{
	if (aPocet < KAPACITA_SKLADU)
	{
		aZasoby = Realokuj();
		aZasoby[aPocet - 1].Nazov(pNazov);
		aZasoby[aPocet - 1].Cena(pCena);
		aZasoby[aPocet - 1].Pocet(pPocet);
		aZasoby[aPocet - 1].Regal(aPocet / 10);
	}
	return false;
}

void Sklad::Sort(PorovnajPtr compareFun)
{
	Tovar** ptrZasob;
	VytvorPolePtr(ptrZasob);
	qsort(ptrZasob, aPocet, sizeof(Tovar*), compareFun);
	Vypis(ptrZasob);
	delete[] ptrZasob;
}

void Sklad::VytvorPolePtr(Tovar**& ptrzasob)
{
	ptrzasob = new Tovar * [aPocet];
	for (int i = 0; i < aPocet; i++)
		ptrzasob[i] = &aZasoby[i];
}

void Sklad::Vypis(Tovar** zasoby)
{
	for (int i = 0; i < aPocet; i++)
		std::cout << *zasoby[i] << std::endl;
}

void Sklad::ZobrazPodlaNazov()
{
	std::cout << "Podla nazov:\n------------" << std::endl;
	Tovar::Typ = eTypSort::Nazov;
	Sort(PorovnajFun);
}

void Sklad::ZobrazPodlaCena()
{
	std::cout << "Podla cena:\n------------" << std::endl;
	Tovar::Typ = eTypSort::Cena;
	Sort(PorovnajFun);
}

void Sklad::ZobrazPodlaPocet()
{
	std::cout << "Podla pocet:\n------------" << std::endl;
	Tovar::Typ = eTypSort::Pocet;
	Sort(PorovnajFun);
}

Sklad& Sklad::GetSklad()
{
	if (SkladJedinacik == nullptr)
		SkladJedinacik = new Sklad();
	return *SkladJedinacik;
}

int PorovnajFun(const void* parameter1, const void* parameter2)
{
	Tovar** tovar1ptr = (Tovar * *)parameter1;
	Tovar** tovar2ptr = (Tovar * *)parameter2;
	return *(*tovar1ptr) < *(*tovar2ptr);
}