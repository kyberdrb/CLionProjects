#include "Strom.h"
#include <iostream>

int main()
{
	Strom s;
	s.Vloz(10);
	s.Vloz(8);
	s.Vloz(5);
	s.Vloz(12);
	s.Vloz(9);
	s.Vloz(11);
	s.Vloz(10);
	s.Vloz(9);
	s.Vloz(8);
	for (int i = 0; i < 1000000; i++) {
		s.Vloz(rand());
	}
	std::cout << s.velkost << std::endl;
	//s.Vypis();
	//std::cout << "nasiel = " << s.Najdi(100) << std::endl;
	return 0;
}