#include <iostream>
#include "Strom.h"

Strom::Uzol::Uzol(int pdata, Uzol* plavy, Uzol* ppravy)
	: data(pdata), lavy(plavy), pravy(ppravy)
{
}

void Strom::ZrusStrom()
{
	ZrusStrom(koren);
}


void Strom::Vloz(int pdata, Uzol* uzol)
{
	if (pdata == uzol->Data()) return;
	if (pdata < uzol->Data())
	{
		// Idem vlavo
		if (uzol->Lavy() != nullptr)
			Vloz(pdata, uzol->Lavy());
		else {
			uzol->Lavy(new Uzol(pdata));
			velkost++;
		}
			
	}
	else
	{
		// Idem vpravo
		if (uzol->Pravy() != nullptr)
			Vloz(pdata, uzol->Pravy());
		else {
			uzol->Pravy(new Uzol(pdata));
			velkost++;
		}
			
	}
}

void Strom::Vypis(Uzol* uzol)
{
	if (uzol != nullptr)
	{
		Vypis(uzol->Lavy());
		std::cout << uzol->Data() << std::endl;
		Vypis(uzol->Pravy());
	}
}

void Strom::ZrusStrom(Uzol* uzol)
{
	if (uzol != nullptr) {
		ZrusStrom(uzol->Lavy());
		ZrusStrom(uzol->Pravy());
		//std::cout << "rusim hodnotu " << uzol->Data() << std::endl;
		delete uzol;
	}
}

bool Strom::Najdi(int pdata, Uzol* uzol)
{
	if (uzol == nullptr) return false;
	std::cout << "hladam v " << uzol->Data() << std::endl;
	if (pdata == uzol->Data()) return true;
	if (pdata < uzol->Data()) return Najdi(pdata, uzol->Lavy());
	else return Najdi(pdata, uzol->Pravy());
}

void Strom::Vloz(int pdata)
{
	if (koren)
		Vloz(pdata, koren);
	else {
		koren = new Uzol(pdata);
		velkost++;
	}
}

bool Strom::Najdi(int pdata)
{
	return Najdi(pdata, koren);
}
