#include <cstring>
#include <cmath>
#include "Binary.h"
#include "Vystup.h"

long long Binary::Bin2Dec(const char* bcislo)
{
	long long cislo(0);
	if (bcislo && *bcislo)
	{
		int dlzka = strlen(bcislo);
		char* pomcislo = new char[dlzka + 1];
		strcpy(pomcislo, bcislo);
		strrev(pomcislo);
		for (int i = 0; i < dlzka; i++)
		{
			if (pomcislo[i] == '1')
				cislo += (1 << i); // dva na i
		}
		if (bcislo[0] == '-') // *bcislo == '-'
			cislo = -cislo;
		delete[] pomcislo;
	}
	return cislo;
}

char* Binary::Dec2Bin(const long long dcislo)
{
	long long pomcislo = llabs(dcislo);
	char* bcislo = new char[66];

	int i(0);
	do
	{
		bcislo[i++] = pomcislo % 2 + '0'; // +0x30
		pomcislo >>= 1; // /=2;
	} while (pomcislo > 0);
	if (dcislo < 0)
		bcislo[i++] = '-';
	bcislo[i] = '\0';
	strrev(bcislo);
	return bcislo;
}

void Binary::Vypis(Vystup& v)
{
	char* bcislo = Dec2Bin(aCislo);
	v.Zapis((unsigned char *)bcislo);
	delete[] bcislo;
}
