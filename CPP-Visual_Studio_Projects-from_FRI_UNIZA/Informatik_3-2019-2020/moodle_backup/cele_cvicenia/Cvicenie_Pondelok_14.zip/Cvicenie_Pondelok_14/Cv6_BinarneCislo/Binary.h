#pragma once

class Vystup;

class Binary
{
private:
	long long aCislo;

	long long Bin2Dec(const char* bcislo);
	char* Dec2Bin(const long long dcislo);
public:
	Binary(long long cislo = 0) :aCislo(cislo)
	{}
	Binary(const char *bcislo):aCislo(Bin2Dec(bcislo))
	{}

	void Vypis(Vystup& v);
	friend Binary operator +(Binary op1, Binary op2);
	friend Binary operator /(Binary op1, Binary op2);
	// todo: dorobit operator -, operator *
	friend bool operator ==(Binary op1, Binary op2);
	friend bool operator !=(Binary op1, Binary op2);
	// todo: dorobit operator <, operator <=, operator >, operator >=
};

inline Binary operator+(Binary op1, Binary op2)
{
	return op1.aCislo + op2.aCislo;
}
inline Binary operator/(Binary op1, Binary op2)
{
	return op1.aCislo / op2.aCislo;
}

inline bool operator==(Binary op1, Binary op2)
{
	return op1.aCislo == op2.aCislo;
}
inline bool operator!=(Binary op1, Binary op2)
{
	return !(op1 == op2);
}