#include "Binary.h"
#include "Vystup.h"

int main()
{
	Binary a("1101"), b("111101"), c("-1x32c0"), d(8), e, f, g;
	e = a + d;
	f = a + 1000;
	g = 10 + b;
	Vystup v(nullptr);
	e.Vypis(v);
	f.Vypis(v);
	g.Vypis(v);
	g = f / e;
	Vystup subor("binary.txt");
	g.Vypis(subor);

}