#pragma once

void Vypis(unsigned int pocetLosovanychZrebov);
