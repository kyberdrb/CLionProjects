#pragma once

// vylosuje dany pocer zrebov
void Losuj(int pocetLosovanychZrebov);