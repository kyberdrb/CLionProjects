#include <stdio.h>

#include "Vystup.h"
#include "Data.h"

void Vypis(unsigned int pocetLosovanychZrebov)
{
	printf("\nVYSLEDOK ZREBOVANIA\n-------------------\n");
	for (unsigned i = 0; i < pocetLosovanychZrebov && i < pocetZrebov; i++)
	{
		printf("%3u. poradie:\t%c %010u\n", i + 1, zreby[i].kod, zreby[i].cislo);
	}
	printf("---------------------------------\nKONIEC\n");
}
