#include <stdlib.h>
#include <stdio.h>
#include "Loteria.h"

int main(int argc, char* argv[])
{
	pocetZrebov = atoi(argv[2]);
	Tah(atoi(argv[1]));
	printf("stlac klavesu pre koniec\n");
	getchar();
	return 0;
}