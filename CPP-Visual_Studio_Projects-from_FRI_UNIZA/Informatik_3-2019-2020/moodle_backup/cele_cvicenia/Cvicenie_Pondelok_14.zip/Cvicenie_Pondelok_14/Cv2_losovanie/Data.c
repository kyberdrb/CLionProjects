#include <malloc.h>
#include "Data.h"

struct Zreb* zreby;
int pocetZrebov;

void PripravZreby()
{
	if (pocetZrebov > 0)
	{
		zreby = malloc(pocetZrebov * sizeof(struct Zreb));
		if (zreby != NULL)
		{
			for (int i = 0; i < pocetZrebov; i++)
			{
				zreby[i].cislo = i + 1;
				//int ccc = (i % 26);
				zreby[i].kod = 'A' + (i % 26);
			}
		}
	}
}

void ZrusZreby()
{
	if (zreby != NULL)
		free(zreby);
	zreby = NULL;
}
