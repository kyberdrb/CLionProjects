#include <stdlib.h>
#include <time.h>
#include "Losovanie.h"
#include "Data.h"

void Vymen(int index, int i);

void Losuj(int pocetLosovanychZrebov)
{
	srand((unsigned)time(NULL));
	for (int i = 0; i < pocetLosovanychZrebov && i < pocetZrebov; i++)
	{
		int index = rand() % (pocetZrebov - i) + 1;
		Vymen(index, i);
	}
}

void Vymen(int index, int i)
{
	struct Zreb pom;
	pom = zreby[index];
	zreby[index] = zreby[i];
	zreby[i] = pom;
}
