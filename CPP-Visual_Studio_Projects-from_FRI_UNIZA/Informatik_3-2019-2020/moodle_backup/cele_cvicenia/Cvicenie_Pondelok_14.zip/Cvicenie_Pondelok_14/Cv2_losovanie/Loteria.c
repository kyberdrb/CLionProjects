#include "Loteria.h"
#include "Data.h"
#include "Losovanie.h"
#include "Vystup.h"

void Tah(unsigned pocetLosovanychZrebov)
{
	if (pocetLosovanychZrebov > (unsigned)pocetZrebov)
		pocetLosovanychZrebov = pocetZrebov;
	PripravZreby();
	Losuj(pocetLosovanychZrebov);
	Vypis(pocetLosovanychZrebov);
	ZrusZreby();
}
