#pragma once
#include "Data.h"

void Tah(unsigned pocetLosovanychZrebov);
