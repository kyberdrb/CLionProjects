#pragma once

struct Zreb
{
	unsigned int cislo;
	char kod;
};

extern int pocetZrebov;

extern struct Zreb* zreby;

void PripravZreby();
void ZrusZreby();