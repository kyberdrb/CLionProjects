#pragma once
#include "IObjekt.h"
class PohyblivyObjekt : public IObjekt
{
private:
	int aSirkaPlochy, aVyskaPlochy;
	int deltaX, deltaY;
	int aInterval, casPoslednejZmeny;
	int Generuj(int zaciatok, int koniec);
protected:
	int x, y;
	int sirka, vyska;
	virtual void Reset();
public:
	PohyblivyObjekt(int sirkaPlochy, int vyskaPlochy);
	virtual ~PohyblivyObjekt();
	
	// Inherited via IObjekt
	virtual bool AktualizujSa(int pcas) override;
	virtual bool Zasah(int px, int py) override;

};

