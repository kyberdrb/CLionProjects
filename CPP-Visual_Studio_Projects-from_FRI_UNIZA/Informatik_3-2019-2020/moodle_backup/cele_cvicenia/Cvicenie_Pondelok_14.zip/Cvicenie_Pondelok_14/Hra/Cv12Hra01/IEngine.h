#pragma once
class IEngine
{
public:
virtual ~IEngine(){}
virtual void Start() = 0;

};

