#include <cstdlib>
#include "PohyblivyObjekt.h"

const int DELTA = 10;
const int INTERVAL = 20;

int PohyblivyObjekt::Generuj(int zaciatok, int koniec)
{
	if (koniec == zaciatok) koniec++;
	if (zaciatok > koniec)
	{
		int pom = zaciatok;
		zaciatok = koniec;
		koniec = pom;
	}
	return rand() % (koniec - zaciatok) + zaciatok;
}

void PohyblivyObjekt::Reset()
{
	x = Generuj(0, aSirkaPlochy - sirka);
	y = Generuj(0, aVyskaPlochy - vyska);
	deltaX = Generuj(-DELTA / 2, DELTA / 2);
	deltaY = Generuj(-DELTA / 2, DELTA / 2);
	aInterval = Generuj(INTERVAL, 5 * INTERVAL);
}

PohyblivyObjekt::PohyblivyObjekt(int sirkaPlochy, int vyskaPlochy)
	:aSirkaPlochy(sirkaPlochy), aVyskaPlochy(vyskaPlochy),
	x(0), y(0), deltaX(0), deltaY(0),
	sirka(0), vyska(0),
	aInterval(0), casPoslednejZmeny(0)
{
}

PohyblivyObjekt::~PohyblivyObjekt() = default;

bool PohyblivyObjekt::AktualizujSa(int pcas)
{
	if (pcas - casPoslednejZmeny > aInterval)
	{
		x += deltaX;
		if (x <= 0 || x >= (aSirkaPlochy - sirka))
		{
			deltaX = -deltaX;
			x += deltaX;
		}
		y += deltaY;
		if (y <= 0 || y >= (aVyskaPlochy - vyska))
		{
			deltaY = -deltaY;
			y += deltaY;
		}
		casPoslednejZmeny = pcas;
		return true;
	}
	return false;
}


bool PohyblivyObjekt::Zasah(int px, int py)
{
	bool trefa =
		px >= x && px <= (x + sirka) &&
		py >= y && py <= (y + vyska);
	if (trefa) Reset();
	return trefa;
}
