#pragma once
class ISystem;
class Lopta;
class Engine;

class HraLopta
{
private:
	ISystem* plocha;
	Lopta* lopta;
	Engine* hra;

public:
	HraLopta();
	~HraLopta();
	void Start();
};

