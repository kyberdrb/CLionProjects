#include "HraLopta.h"

HraLopta::HraLopta()
{
}

HraLopta::~HraLopta()
{
}

void HraLopta::Start()
{
}
