#include <string>
#include <sstream>

#include "Engine.h"
#include "ISystem.h"
#include "IObjekt.h"

void Engine::ZobrazSkore()
{
	if (aHraciaPlocha)
	{
		stringstream sts;
		sts << aSkore;
		aHraciaPlocha->ZobrazText(string("Skore: ") + sts.str());
	}
}

void Engine::Aktualizuj()
{
	if (aHraciaPlocha && aObjekt)
	{
		if (aObjekt->AktualizujSa(aHraciaPlocha->Cas()))
		{
			aHraciaPlocha->Zmaz();
			aObjekt->ZobrazSa();
			aHraciaPlocha->Update();
		}
	}
}

void Engine::SpracujVstup(int x, int y)
{
	if (aObjekt && x >= 0)
	{
		if (aObjekt->Zasah(x, y))
		{
			aSkore += aObjekt->DajBody();
			ZobrazSkore();
		}
	}
}


Engine::Engine(ISystem* pHraciaPlocha, IObjekt* pObjekt)
{
}

Engine::~Engine()
{
}

void Engine::Start()
{
}
