#include <cstring>
#include <ctype.h>
#include "Sifrator.h"
#include "helper.h"
#include "Vstup.h"
#include "Koder.h"
#include "Vystup.h"

void Sifrator::Init(char cinnost, char* heslo, bool konzola, const char* vstupSubor, const char* vystupSubor)
{
	aCinnost = tolower(cinnost);
	aHeslo = alokujKopiruj(heslo);
	aKonzola = konzola;
	aVstupSubor = alokujKopiruj(vstupSubor);
	aVystupSubor = alokujKopiruj(vystupSubor);
}

Sifrator::Sifrator(char cinnost, char* heslo, bool konzola, const char* vstupSubor, const char* vystupSubor)
{
	Init(cinnost, heslo, konzola, vstupSubor, vystupSubor);
}

Sifrator::Sifrator(const Sifrator& zdroj)
{
	Init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aKonzola, zdroj.aVstupSubor, zdroj.aVystupSubor);
}

void Sifrator::Zmaz()
{
	delete[] aHeslo;
	delete[] aVstupSubor;
	delete[] aVystupSubor;
}

void Sifrator::vypisHelp()
{
	Vystup konzola(nullptr);
	konzola.Zapis((unsigned char*)
		"Cv4_Sifrator1 CINNOST HESLO VSTUP_SUBOR [TYP_VYSTUPU VYSTUP_SUBOR]\n"
		"   CINNOST:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...help\n"
		"   TYP_VYSTUPU:\n"
		"      s...subor\n"
		"      c...konzola\n\n");
}

Sifrator& Sifrator::operator=(const Sifrator& zdroj)
{
	if (this!= &zdroj)
	{
		Zmaz();
		Init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aKonzola, zdroj.aVstupSubor, zdroj.aVystupSubor);
	}
	return *this;
}

Sifrator::~Sifrator()
{
	Zmaz();
}

void Sifrator::Start()
{
	if (aCinnost == 'h')
		vypisHelp();
	else
	{
		Vstup zdroj(aVstupSubor);
		char* zdrojText = (char *)zdroj.Citaj();
		if (zdrojText)
		{
			char* cielText;
			Koder koder;
			if (aCinnost == 's')
				cielText = koder.Koduj(aHeslo, (unsigned char*)zdrojText);
			else
				cielText = (char*)koder.Dekoduj(aHeslo, zdrojText);
			if (cielText)
			{
				Vystup vystup(aVystupSubor);
				vystup.Zapis((unsigned char*)cielText);
				delete[] cielText;
			}
			delete[] zdrojText;
		}
	}
}
