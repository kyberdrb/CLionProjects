#pragma once
	char* alokujKopiruj(const char* zdroj);
