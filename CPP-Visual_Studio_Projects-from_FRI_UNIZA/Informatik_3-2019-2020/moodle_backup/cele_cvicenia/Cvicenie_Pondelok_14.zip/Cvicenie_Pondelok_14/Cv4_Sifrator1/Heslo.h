#pragma once
#include <cstring>
const int DLZKA_HESLA = 8;

class Heslo
{
	union {
		char aHeslo[DLZKA_HESLA];
		long long aNasada;
	};

public:
	Heslo(const char* heslo)
	{
		memset(aHeslo, 0, DLZKA_HESLA);
		if (heslo)
		{
			int dlzka = strlen(heslo);
			dlzka = dlzka > DLZKA_HESLA ? DLZKA_HESLA : dlzka;
			memmove(aHeslo, heslo, dlzka);
		}
	}
	unsigned DajNasadu()
	{
		unsigned int* nasada1 = (unsigned int*)aHeslo;
		unsigned int* nasada2 = (unsigned int*)& aHeslo[4];
		return *nasada1 + *nasada2;
	}

	unsigned DajNasadu2()
	{
		unsigned nasada1 = aNasada & 0x00000000ffffffff;
		unsigned nasada2 = (aNasada >> 32) & 0x00000000ffffffff;
		return nasada1 + nasada2;
	}
};

