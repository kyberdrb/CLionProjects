#pragma once
class Sifrator
{
private:
	char aCinnost;
	char* aHeslo;
	bool aKonzola;
	char* aVstupSubor;
	char* aVystupSubor;
	void Init(char cinnost, char* heslo, bool konzola, const char* vstupSubor, const char* vystupSubor);
	void Zmaz();
	void vypisHelp();
public:
	Sifrator(char cinnost, char *heslo, bool konzola, const char *vstupSubor, const char *vystupSubor);
	Sifrator(const Sifrator& zdroj);
	Sifrator &operator =(const Sifrator& zdroj);
	~Sifrator();

	void Start();
};

