#include <cstdlib>
#include <cstdio>

#include "Koder.h"
#include "Heslo.h"

unsigned int Koder::DajNasadu(const char* heslo)
{
	Heslo h(heslo);
	unsigned int nasada = h.DajNasadu();
	return nasada;
}

void Koder::ZakodujTabulku(const char* heslo)
{
	unsigned int nasada = DajNasadu(heslo);
	srand(nasada);
	for (int i = 0; i < DLZKA_TABULKY; i++)
	{
		int index = rand() % (DLZKA_TABULKY - i);
		Vymen(aKodtabulka[index], aKodtabulka[DLZKA_TABULKY - 1 - i]);
	}
}

char* Koder::Koduj(const char* pheslo, const unsigned char* ptext)
{
	if (ptext && *ptext)
	{
		PripravTabulku(pheslo);

		int dlzkaTextu = strlen((const char*)ptext);
		unsigned char* kodText = new unsigned char[dlzkaTextu];
		if (kodText != nullptr)
		{
			for (int i = 0; i < dlzkaTextu; i++)
				kodText[i] = aKodtabulka[ptext[i]];
			char* sifrovanyText = new char[dlzkaTextu * 3 + 1];
			if (sifrovanyText)
			{
				int k = 0;
				for (int i = 0; i < dlzkaTextu; i++)
				{
					char ciskod[4];
					sprintf(ciskod, "%03u", kodText[i]);
					memmove(&sifrovanyText[k], ciskod, 3);
					k += 3;
				}
				sifrovanyText[k] = 0;
				delete[] kodText;
				return sifrovanyText;
			}
		}
	}
	return nullptr;
}

unsigned char* Koder::Dekoduj(const char* pheslo, const char* ptext)
{
	if (ptext && *ptext)
	{
		PripravTabulku(pheslo);
		DekodujTabulku();
		int dlzka = strlen(ptext);
		unsigned char* kodText = new unsigned char[dlzka / 3];
		if (kodText)
		{
			char ciskod[4]{};
			int i(0), k = 0;
			while (i<dlzka)
			{
				memmove(ciskod, &ptext[i], 3);
				kodText[k++] = (unsigned char)atoi(ciskod);
				i += 3;
			}
			unsigned char* desifrovanyText = new unsigned char[dlzka / 3 + 1];
			if (desifrovanyText)
			{
				for (int i = 0; i < k; i++)
					desifrovanyText[i] = aKodtabulka[kodText[i]];
				desifrovanyText[k] = '\0';
				delete[] kodText;
				return desifrovanyText;
			}
		}
	}
	return nullptr;
}
