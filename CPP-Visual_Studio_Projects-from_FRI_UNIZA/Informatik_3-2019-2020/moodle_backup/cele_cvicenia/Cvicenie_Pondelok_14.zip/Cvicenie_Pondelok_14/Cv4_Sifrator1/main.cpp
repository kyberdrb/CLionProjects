//#define TESTY
#include <cstdio>
#include "Sifrator.h"

#ifdef TESTY
#include "Testy.h"
#endif // TESTY

int main(int argc, char* argv[])
{
	bool ok(true);
#ifdef TESTY
	Testy testy;
	ok = testy.runTest();
#endif // TESTY

	if (ok)
	{
		// aktivacia sifratora
		char cinnost = 'h';
		char* heslo{};
		char* vstupSubor{};
		bool konzola{ true };
		char* vystupSubor{};
		if (argc > 1)
			cinnost = argv[1][0];
		if (argc > 2)
			heslo = argv[2];
		if (argc > 3)
			vstupSubor = argv[3];
		if (argc > 4)
			konzola = argv[4][0] == 'c' || argv[4][0] == 'C';
		if (argc > 5)
			vystupSubor = argv[5];

		Sifrator sifrator(cinnost, heslo, konzola, vstupSubor, vystupSubor);
		sifrator.Start();
	}
	else
	{
		printf("CHYBA!\n");
	}
	return 0;
}
