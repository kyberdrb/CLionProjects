#include "Vystup.h"
#include "helper.h"
#include <cstdio>
#include <cstring>

Vystup::Vystup(const char* menoSuboru)
{
	aMenoSuboru = alokujKopiruj(menoSuboru);
}

Vystup::Vystup(const Vystup& zdroj)
{
	aMenoSuboru = alokujKopiruj(zdroj.aMenoSuboru);
}

Vystup& Vystup::operator=(const Vystup& zdroj)
{
	if (this != &zdroj)
	{
		delete[] aMenoSuboru;
		aMenoSuboru = alokujKopiruj(zdroj.aMenoSuboru);
	}
	return *this;
}

Vystup::~Vystup()
{
	delete[] aMenoSuboru;
}

bool Vystup::Zapis(const unsigned char* text)
{
	if (aMenoSuboru && *aMenoSuboru)
	{
		FILE* f=fopen(aMenoSuboru, "wb");
		if (f)
		{
			int dlzka = strlen((char*)text);
			fwrite(text, dlzka, 1, f);
			fclose(f);
		}
	}
	else {
		printf("%s\n", text);
	}
	return true;
}
