#pragma once
#include <cstring>
#include "Koder.h"

class Testy
{
public:
	bool runTest()
	{
		auto ret{ true };
		Koder k;
		char* zakodovanyText = k.Koduj("abcde", (unsigned char *)"kontrola nasho sifratora");
		unsigned char* dekodovanyText = k.Dekoduj("abcd", zakodovanyText);
		if (strcmp("kontrola nasho sifratora", (char*)dekodovanyText)!=0)
			ret = false;

		delete[] dekodovanyText;
		delete[] zakodovanyText;
		return ret;
	}
};
