#include <cstring>
#include "helper.h"

char* alokujKopiruj(const char* zdroj)
{
	char* ciel = nullptr;
	if (zdroj && *zdroj)
	{
		int dlzka = strlen(zdroj);
		ciel = new char[dlzka + 1];
		strcpy(ciel, zdroj);
	}

	return ciel;
}
