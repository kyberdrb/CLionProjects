#pragma once

const int DLZKA_TABULKY = 256;

class Koder
{
private:
	unsigned char aKodtabulka[DLZKA_TABULKY];

	unsigned int DajNasadu(const char* heslo);

	void NaplnTabulku()
	{
		for (int i = 0; i < DLZKA_TABULKY; i++)
			aKodtabulka[i] = i;
	}

	void Vymen(unsigned char &a, unsigned char &b)
	{
		unsigned char c{ a };
		a = b;
		b = c;
	}

	void ZakodujTabulku(const char* heslo);

	void PripravTabulku(const char* heslo)
	{
		NaplnTabulku();
		ZakodujTabulku(heslo);
	}

	void DekodujTabulku()
	{
		unsigned char pom[DLZKA_TABULKY];
		for (int i = 0; i < DLZKA_TABULKY; i++)
			pom[aKodtabulka[i]] = i;
		for (int i = 0; i < DLZKA_TABULKY; i++)
			aKodtabulka[i] = pom[i];
	}

public:
	char* Koduj(const char* pheslo, const unsigned char* ptext);
	unsigned char* Dekoduj(const char* pheslo, const char* ptext);

};

