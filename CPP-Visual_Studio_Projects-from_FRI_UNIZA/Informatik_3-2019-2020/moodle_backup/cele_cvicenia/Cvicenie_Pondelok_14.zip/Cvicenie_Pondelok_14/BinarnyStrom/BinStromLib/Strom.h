#pragma once
//#include "Uzol.h"
class Strom
{
	class Uzol
	{
		int aData = 0;
		Uzol* aVlavo = nullptr;
		Uzol* aVpravo = nullptr;
	public:
		Uzol() = default;
		Uzol(int data, Uzol* vlavo = nullptr, Uzol* vpravo = nullptr)
			:aData(data), aVlavo(vlavo), aVpravo(vpravo) {}
		~Uzol() = default;
		int Data() { return aData; }
		inline Uzol* Vlavo();// { return aVlavo; }
		inline Uzol* Vpravo();// { return aVpravo; }

		void Data(int data) { aData = data; }
		void Vlavo(Uzol* uzol) { aVlavo = uzol; }
		void Vpravo(Uzol* uzol) { aVpravo = uzol; }
	}*aKoren;

	void ZrusStrom(Uzol* list);
	void Vloz(int data, Uzol* list);
	//	Uzol* Najdi(int data, Uzol* list);
	void Vypis(Uzol* list);

public:
	Strom() :aKoren(nullptr) {}
	~Strom() { ZrusStrom(); }

	void ZrusStrom();
	void Vloz(int data);
	//	Uzol* Najdi(int data);
	void Vypis();
};

inline Strom::Uzol* Strom::Uzol::Vlavo()
{
	return aVlavo;
}

inline Strom::Uzol* Strom::Uzol::Vpravo()
{
	return aVpravo;
}

