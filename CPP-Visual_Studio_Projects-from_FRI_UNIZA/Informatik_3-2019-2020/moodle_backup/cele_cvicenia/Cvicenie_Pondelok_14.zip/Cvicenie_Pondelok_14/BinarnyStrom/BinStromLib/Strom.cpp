#include "Strom.h"
#include <iostream>
using namespace std;

void Strom::ZrusStrom(Uzol* list)
{
	if (list!=nullptr)
	{
		ZrusStrom(list->Vlavo());
		ZrusStrom(list->Vpravo());
		delete list;
	}
}

void Strom::Vloz(int data, Uzol* list)
{
	if (data<list->Data())
	{
		if (list->Vlavo() != nullptr)
			Vloz(data, list->Vlavo());
		else
		{
			//list->Vlavo(new Uzol);
			//list->Vlavo()->Data(data);
			//list->Vlavo()->Vlavo(nullptr);
			//list->Vlavo()->Vpravo(nullptr);
			list->Vlavo(new Uzol(data));
		}
	}
	else if(data>=list->Data())
	{
		if (list->Vpravo() != nullptr)
			Vloz(data, list->Vpravo());
		else
		{
			//list->Vpravo(new Uzol);
			//list->Vpravo()->Data(data);
			//list->Vpravo()->Vlavo(nullptr);
			//list->Vpravo()->Vpravo(nullptr);
			list->Vpravo(new Uzol(data));
		}
	}
}

//Uzol* Strom::Najdi(int data, Uzol* list)
//{
//	return nullptr;
//}

void Strom::Vypis(Uzol* list)
{
	if (list!=nullptr)
	{
		Vypis(list->Vlavo());
		cout << list->Data() << endl;
		Vypis(list->Vpravo());
	}
}

void Strom::ZrusStrom()
{
	ZrusStrom(aKoren);
}

void Strom::Vloz(int data)
{
	if(aKoren!=nullptr)
			Vloz(data, aKoren);
	else
	{
		aKoren = new Uzol(data);
		//aKoren = new Uzol;
		//aKoren->Data(data);
		//aKoren->Vlavo(nullptr);
		//aKoren->Vpravo(nullptr);
	}
}

//Uzol* Strom::Najdi(int data)
//{
//	return nullptr;
//}

void Strom::Vypis()
{
	Vypis(aKoren);
}
