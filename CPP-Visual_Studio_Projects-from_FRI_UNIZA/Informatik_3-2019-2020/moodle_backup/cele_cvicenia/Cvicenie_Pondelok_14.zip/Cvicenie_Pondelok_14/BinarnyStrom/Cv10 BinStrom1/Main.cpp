#include "Strom.h"

int main()
{
	Strom strom;
	strom.Vloz(10);
	strom.Vloz(-10);
	strom.Vloz(100);
	strom.Vloz(3);
	strom.Vloz(-30);
	strom.Vloz(16);
	strom.Vloz(106);
	strom.Vloz(106);
	strom.Vloz(-100);
	 
	strom.Vypis();
	return 1;
}