//#pragma once
//class Uzol
//{
//	int aData = 0;
//	Uzol* aVlavo = nullptr;
//	Uzol* aVpravo = nullptr;
//public:
//	Uzol() = default;
//	~Uzol() = default;
//	int Data() { return aData; }
//	Uzol* Vlavo() { return aVlavo; }
//	Uzol* Vpravo() { return aVpravo; }
//
//	void Data(int data) { aData = data; }
//	void Vlavo(Uzol* uzol) { aVlavo = uzol; }
//	void Vpravo(Uzol* uzol) { aVpravo = uzol; }
//};
//
