#pragma once

typedef int TYPHODNOTA;
const TYPHODNOTA NEPLATNA_HODNOTA = 0;

int Porovnaj(void* cislo1ptr, void* cislo2ptr);

class Uzol
{
private:
	Uzol* aDalsi = nullptr;
	TYPHODNOTA aHodnota;
public:
	Uzol(TYPHODNOTA pHodnota, Uzol* pDalsi);

	Uzol* dalsi() const { return aDalsi; }
	TYPHODNOTA* hodnota() { return &aHodnota; }

	void dalsi(Uzol* pDalsi) { aDalsi = pDalsi; }
};

