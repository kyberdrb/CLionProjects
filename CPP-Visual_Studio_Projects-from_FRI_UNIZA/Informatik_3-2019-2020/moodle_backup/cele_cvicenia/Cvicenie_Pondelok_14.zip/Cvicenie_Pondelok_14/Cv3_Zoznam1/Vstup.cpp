#include "Vstup.h"

Vstup::Vstup(const char* menosuboru)
{
	fhandle = nullptr;
	if (menosuboru!=nullptr && *menosuboru!=0) // !='\0'
	{
		fhandle = fopen(menosuboru, "rt"); // textak pre citanie
	}
}

Vstup::~Vstup()
{
	if (fhandle != nullptr)
		fclose(fhandle);
	//fhandle = nullptr;
}

int Vstup::CitajCislo()
{	
	if (fhandle!=nullptr)
	{
		if (!feof(fhandle))
		{
			int cislo;
			fscanf(fhandle, "%d", &cislo);
			return cislo;
		}

	}
	return 0;
}
