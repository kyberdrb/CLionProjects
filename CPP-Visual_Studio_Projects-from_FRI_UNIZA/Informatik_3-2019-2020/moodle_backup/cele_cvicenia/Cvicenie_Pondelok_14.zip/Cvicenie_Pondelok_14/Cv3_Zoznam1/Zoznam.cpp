#include "Zoznam.h"
#include "Vstup.h"
#include "Vystup.h"

Zoznam::~Zoznam()
{
	Vymaz(aStart);
}

void Zoznam::Sort(const char* menosuboru, PorovnajPtr compareFun)
{
	if (menosuboru && *menosuboru)
	{
		Vstup citac(menosuboru);
		int cislo = citac.CitajCislo();
		while (cislo != NEPLATNA_HODNOTA)
		{
			if (aStart == nullptr)
			{
				aStart = new Uzol(cislo, nullptr);
			}
			else
			{
				Uzol* predchadzajuci = nullptr;
				Uzol* uzol = aStart;
				while (uzol != nullptr && compareFun(&cislo, uzol->hodnota()) > 0)
				{
					predchadzajuci = uzol;
					uzol = uzol->dalsi();
				}
				uzol = new Uzol(cislo, uzol);
				if (predchadzajuci == nullptr)
					aStart = uzol;
				else
					predchadzajuci->dalsi(uzol);
			}
			cislo = citac.CitajCislo();
		}

	}
}

void Zoznam::Uloz(const char* menosuboru)
{
	Vystup vystup(menosuboru);
	Uzol* uzol = aStart;
	while (uzol != nullptr)
	{
		vystup.ZapisCislo(*uzol->hodnota());
		uzol = uzol->dalsi();
	}
}

void Zoznam::Vymaz(Uzol* uzol)
{
	if (uzol->dalsi() != nullptr)
		Vymaz(uzol->dalsi());
	delete uzol;
}
