//#define TESTY
#include <cstdio>

#ifdef _DEBUG
#include "Testy.h"
#endif // TESTY

int main()
{
	bool ok = true;

#ifdef _DEBUG
	ok = Testy().Testuj();
#endif // TESTY

	if (ok)
		; // normalny chod programu
	else
		printf("CHYBA!!!\n");

	return 0;
}