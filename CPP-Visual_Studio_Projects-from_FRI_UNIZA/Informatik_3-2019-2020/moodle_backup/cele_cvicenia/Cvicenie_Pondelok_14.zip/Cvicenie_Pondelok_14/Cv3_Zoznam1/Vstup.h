#pragma once
#include <cstdio>

class Vstup
{
private:
	FILE* fhandle; // popisovac vstupneho suboru
public:
	Vstup(const char* menosuboru); // parametricky konstruktor

	~Vstup(); // destruktor
	
	int CitajCislo();
};

