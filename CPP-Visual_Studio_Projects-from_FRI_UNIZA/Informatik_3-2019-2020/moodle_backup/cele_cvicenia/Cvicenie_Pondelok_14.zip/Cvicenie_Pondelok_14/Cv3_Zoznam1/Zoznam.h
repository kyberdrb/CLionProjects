#pragma once
#include "Uzol.h"

typedef int(*PorovnajPtr)(void* uzol1, void* uzol2);

class Zoznam
{
private:
	Uzol* aStart = nullptr;
public:
	~Zoznam();

	void Sort(const char* menosuboru, PorovnajPtr compareFun);
	void Uloz(const char* menosuboru);

	void Vymaz(Uzol* uzol);
};

