#pragma once
#include <cstdio>

class Vystup
{
private:
	FILE* fhandle=nullptr;
public:
	Vystup(const char* menosuboru);
	~Vystup();

	void ZapisCislo(const int cislo);

};

