#include <malloc.h>
#include "Data.h"

struct Zreb *zreby;

#define POCET_PISMEN 26

void PripravZreby(UINT celkovyPocetZrebov)
{
	zreby = malloc(celkovyPocetZrebov * sizeof(struct Zreb));
	if (zreby != NULL)
	{
		for (UINT i = 0; i < celkovyPocetZrebov; i++)
		{
			zreby[i].cislo = i + 1;
			zreby[i].kod = 'A' + (i % POCET_PISMEN);
		}
	}
}

void ZrusZreby()
{
	if (zreby != NULL)
	{
		free(zreby);
		zreby = NULL;
	}
}
