#include <stdlib.h>
#include <time.h>
#include "Losovanie.h"

void Vymen(UINT index, UINT i);

void Losovanie(UINT celkovyPocetZrebov, UINT pocetLosovanychZrebov)
{
	srand(time(NULL));
	for (UINT i = 0; i < pocetLosovanychZrebov; i++)
	{
		UINT index = rand() % (celkovyPocetZrebov - i) + i;
		Vymen(index, i);
	}
}

void Vymen(UINT index, UINT i)
{
	struct Zreb pom;
	pom = zreby[index];
	zreby[index] = zreby[i];
	zreby[i] = pom;
}
