#pragma once
#include "Data.h"

void VypisVysledkov(UINT pocetLosovanychZrebov);
