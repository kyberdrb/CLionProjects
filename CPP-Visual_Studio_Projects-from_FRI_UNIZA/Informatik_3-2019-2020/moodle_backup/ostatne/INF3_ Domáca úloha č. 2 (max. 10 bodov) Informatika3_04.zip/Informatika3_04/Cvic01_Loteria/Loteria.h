#pragma once
#include "Data.h"

void Tah(UINT celkovyPocetZrebov, UINT pocetLosovanychZrebov);