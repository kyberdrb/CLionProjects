#include <stdio.h>

#include "Vystup.h"

void VypisVysledkov(UINT pocetLosovanychZrebov)
{
	printf("\nVYSLEDOK ZREBOVANIA\n------------------------------\n");
	for (UINT i = 0; i < pocetLosovanychZrebov; i++)
	{
		printf("%3u. poradie:\t%c %010u\n",
			i + 1,
			zreby[i].kod,
			zreby[i].cislo);
	}
	printf("------------------------------\n");
}
