#include "Loteria.h"
#include "Losovanie.h"
#include "Vystup.h"

void Tah(UINT celkovyPocetZrebov, UINT pocetLosovanychZrebov)
{
	if (celkovyPocetZrebov == 0 || pocetLosovanychZrebov == 0)
		return;
	if (pocetLosovanychZrebov > celkovyPocetZrebov)
		pocetLosovanychZrebov = celkovyPocetZrebov;
	PripravZreby(celkovyPocetZrebov);
	Losovanie(celkovyPocetZrebov, pocetLosovanychZrebov);
	VypisVysledkov(pocetLosovanychZrebov);
	ZrusZreby();
}
