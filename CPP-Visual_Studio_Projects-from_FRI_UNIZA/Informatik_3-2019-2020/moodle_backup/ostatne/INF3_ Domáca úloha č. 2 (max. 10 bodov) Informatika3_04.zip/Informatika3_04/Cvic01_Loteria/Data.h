#pragma once

//#ifdef WIN32
//	#define UINT unsigned int 
//#else
//	#define UINT unsigned short int 
//#endif

#ifdef WIN32
	typedef unsigned int UINT;
#else
	typedef unsigned short int UINT;
#endif

struct Zreb
{
	UINT cislo;
	char kod;
};

extern struct Zreb *zreby;

void PripravZreby(UINT celkovyPocetZrebov);
void ZrusZreby();

//#ifndef DATA_H
//	#define DATA_H
//
//
//#endif
