#include <stdlib.h>
#include "Loteria.h"

int main(int argc, char *argv[])
{
	UINT celkovyPocetZrebov = atoi(argv[1]);
	UINT pocetLosovanychZrebov = atoi(argv[2]);
	Tah(celkovyPocetZrebov, pocetLosovanychZrebov);
	return 0;
}