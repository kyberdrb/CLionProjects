#pragma once
#include "Data.h"

void Losovanie(UINT celkovyPocetZrebov, UINT pocetLosovanychZrebov);