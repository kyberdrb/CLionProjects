#define TESTY
#include <stdio.h>

#ifdef TESTY
	#include "Testy.h"
#endif


int main()
{
	bool ok = true;
#ifdef TESTY
	ok = Testuj();
#endif
	if (ok)
		;
	else
		printf("CHYBA!!!\n");
}