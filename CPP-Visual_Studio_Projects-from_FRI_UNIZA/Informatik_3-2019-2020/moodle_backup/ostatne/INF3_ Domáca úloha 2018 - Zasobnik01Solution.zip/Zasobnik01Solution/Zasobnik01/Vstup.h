#pragma once
#include "Data.h"

MUINT ZadajCislo(const char *oznam);