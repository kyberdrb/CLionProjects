#pragma once
#include "Data.h"

const MUINT NEPLATNA_HODNOTA = 0;

//#define NEPLATNA_HODNOTA 

struct Uzol
{
	MUINT info;
	Uzol *dalsi;
};

struct Zasobnik {
	Uzol *stackPointer;
	MUINT pocet;
};

void Init(Zasobnik *pzasobnik);

bool Push(Zasobnik *pzasobnik, MUINT hodnota);
MUINT Pop(Zasobnik *pzasobnik);
MUINT Peek(Zasobnik *pzasobnik);

void Kopiruj(Zasobnik *pciel, const Zasobnik *pzdroj);

void Zrus(Zasobnik *pzasobnik);
