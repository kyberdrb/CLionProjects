#include <stdlib.h>

#include "Zasobnik.h"

void Init(Zasobnik * pzasobnik)
{
	if (pzasobnik != nullptr)
	{
		pzasobnik->stackPointer = nullptr;
		pzasobnik->pocet = 0;
	}
}

//bool Push(Zasobnik * pzasobnik, MUINT hodnota)
//{
//	if (pzasobnik != nullptr)
//	{
//		if (pzasobnik->pocet == 0)
//		{
//			pzasobnik->stackPointer = (Uzol *)malloc(sizeof(Uzol));
//			if (pzasobnik->stackPointer != nullptr) 
//			{
//				//pzasobnik->stackPointer = new Uzol;
//				pzasobnik->stackPointer->info = hodnota;
//				pzasobnik->stackPointer->dalsi = nullptr;
//				pzasobnik->pocet++;
//				return true;
//			}
//		}
//		else
//		{
//			Uzol *novy = (Uzol *)malloc(sizeof(Uzol));
//			if (novy != nullptr)
//			{
//				novy->info = hodnota;
//				novy->dalsi = pzasobnik->stackPointer;
//				pzasobnik->stackPointer = novy;
//				pzasobnik->pocet++;
//				return true;
//			}
//		}
//	}
//	return false;
//}
//

bool Push(Zasobnik * pzasobnik, MUINT hodnota)
{
	if (pzasobnik != nullptr)
	{
		Uzol *novy = (Uzol *)malloc(sizeof(Uzol));
		if (novy != nullptr)
		{
			novy->info = hodnota;
			novy->dalsi = pzasobnik->stackPointer;

			pzasobnik->stackPointer = novy;
			pzasobnik->pocet++;
			return true;
		}
	}
	return false;
}

MUINT Pop(Zasobnik * pzasobnik)
{
	if (pzasobnik != nullptr && pzasobnik->pocet > 0)
	{
		// 1.krok: Odloz
		MUINT retHodnota = pzasobnik->stackPointer->info;
		Uzol *pomUzol = pzasobnik->stackPointer->dalsi;
		// 2.krok: Uvolni
		free(pzasobnik->stackPointer);
		//delete pzasobnik->stackPointer;

		// 3.krok: nastav novy vrchol zasobnika
		pzasobnik->stackPointer = pomUzol;
		pzasobnik->pocet--;

		return retHodnota;
	}
	return NEPLATNA_HODNOTA;
}

MUINT Peek(Zasobnik * pzasobnik)
{
	if (pzasobnik != nullptr && pzasobnik->pocet > 0)
		return pzasobnik->stackPointer->info;
	return NEPLATNA_HODNOTA;
}

void Kopiruj(Zasobnik * pciel, const Zasobnik * pzdroj)
{
	Zasobnik pom;
	Init(&pom);
	while (pzdroj->pocet > 0)
		Push(&pom, Pop((Zasobnik *)pzdroj));
	Zrus(pciel);
	while (pom.pocet)
	{
		MUINT hodnota = Pop(&pom);
		Push((Zasobnik *)pzdroj, hodnota);
		Push(pciel, hodnota);
	}
}

void Zrus(Zasobnik * pzasobnik)
{
	while (pzasobnik != nullptr && pzasobnik->pocet > 0)
		Pop(pzasobnik);
}

