#include "Testy.h"
#include "Zasobnik.h"

bool Testuj()
{
	Zasobnik z1;

	Init(&z1);
	Push(&z1, 10);
	Push(&z1, 20);
	Push(&z1, 30);
	
	Zasobnik z2;
	Init(&z2);
	Push(&z2, 50);
	Kopiruj(&z2, &z1);

	MUINT x1 = Pop(&z1);
	MUINT x2 = Pop(&z1);
	
	Zrus(&z2);
	Zrus(&z1);
	return true;
}
