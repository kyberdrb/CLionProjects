#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "Vstup.h"

MUINT ZadajCislo(const char *oznam)
{
	MUINT cislo = 0;
	char pombuf[301];
	//if (oznam != nullptr && oznam[0] != '\0')
	if (oznam && *oznam)
		printf("%s", oznam);
	scanf("%s", pombuf);
	for (MUINT i = 0; i < strlen(pombuf); i++)
	{
		if (!isdigit(pombuf[i]))
			return 0;
	}
	//sscanf(pombuf, "%u", &cislo);
	cislo = atoi(pombuf);

	return cislo;
}

